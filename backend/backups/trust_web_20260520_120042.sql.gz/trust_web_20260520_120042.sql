-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: trust_web
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AIMemberConfig`
--

DROP TABLE IF EXISTS `AIMemberConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AIMemberConfig` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeMemberId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maxConcurrentTasks` int NOT NULL DEFAULT '1',
  `autoClaimEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `allowedPhases` json DEFAULT NULL,
  `skillOverrides` json DEFAULT NULL,
  `autonomyLevel` enum('L1','L2','L3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'L1',
  `aiFailCount` int NOT NULL DEFAULT '0',
  `aiLastFailedAt` datetime(3) DEFAULT NULL,
  `aiRateLimitedUntil` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AIMemberConfig_treeMemberId_key` (`treeMemberId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AIMemberConfig`
--

LOCK TABLES `AIMemberConfig` WRITE;
/*!40000 ALTER TABLE `AIMemberConfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `AIMemberConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Agent`
--

DROP TABLE IF EXISTS `Agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Agent` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HERMES',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Agent_name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Agent`
--

LOCK TABLES `Agent` WRITE;
/*!40000 ALTER TABLE `Agent` DISABLE KEYS */;
INSERT INTO `Agent` VALUES ('0b537aff-0775-4de9-9538-707ed0f314fb','Alpha','External AI agent — ML, NLP, data science, MLOps','EXTERNAL','2026-05-16 18:55:04.885'),('2e2e0d1f-8fdb-4920-bd61-a752c18e908a','Gamma','External AI agent — cloud architecture, seguridad, DevSecOps','EXTERNAL','2026-05-16 18:55:04.909'),('3626ecf4-d5fb-44cb-830b-e780e66cf6bd','Hermes-Artemis','Security auditor agent — OWASP, pentesting, vulnerability scanning','HERMES','2026-05-16 18:55:04.808'),('6b615368-d4e1-41e4-a244-61ec8efad881','Hermes-Demeter','Research agent — agricultura regenerativa, energía solar, biotecnología','HERMES','2026-05-16 18:55:04.850'),('7d70ab25-175d-44e9-9f52-c051ca859b40','Beta','External AI agent — frontend, React, TypeScript, accesibilidad WCAG','EXTERNAL','2026-05-16 18:55:04.898'),('8441b383-9dd5-47d3-ac52-5232468d40a1','Hermes-Asclepius','Health UX reviewer agent — telemedicina, salud mental, protocolos clínicos','HERMES','2026-05-16 18:55:04.862'),('bb05ea7b-1b8b-48ae-b866-67f7cde4ff31','Hermes-Mnemosyne','Data engineer agent — anonimización, dashboards, EHR, spark','HERMES','2026-05-16 18:55:04.874'),('df9333a2-358c-4e0f-a2dd-a2ea696f3925','Hermes-Prometheus','DevOps + monitoring agent — Grafana, Prometheus, anomaly detection','HERMES','2026-05-16 18:55:04.833'),('ea1a4e77-2db6-462a-8253-076ee8f4fc77','Hermes-Nestor','Backend engineer agent — CI/CD, Docker, Kubernetes, AWS','HERMES','2026-05-16 18:55:04.787');
/*!40000 ALTER TABLE `Agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentIntervention`
--

DROP TABLE IF EXISTS `AgentIntervention`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AgentIntervention` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agentId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AgentIntervention_agentId_treeId_idx` (`agentId`,`treeId`),
  KEY `AgentIntervention_treeId_createdAt_idx` (`treeId`,`createdAt`),
  KEY `AgentIntervention_taskId_fkey` (`taskId`),
  CONSTRAINT `AgentIntervention_agentId_fkey` FOREIGN KEY (`agentId`) REFERENCES `Agent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AgentIntervention_taskId_fkey` FOREIGN KEY (`taskId`) REFERENCES `Task` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AgentIntervention_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentIntervention`
--

LOCK TABLES `AgentIntervention` WRITE;
/*!40000 ALTER TABLE `AgentIntervention` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentIntervention` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentInterventionRating`
--

DROP TABLE IF EXISTS `AgentInterventionRating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AgentInterventionRating` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interventionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `useful` tinyint(1) NOT NULL DEFAULT '0',
  `annoying` tinyint(1) NOT NULL DEFAULT '0',
  `correct` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AgentInterventionRating_interventionId_userId_key` (`interventionId`,`userId`),
  KEY `AgentInterventionRating_interventionId_idx` (`interventionId`),
  KEY `AgentInterventionRating_userId_fkey` (`userId`),
  CONSTRAINT `AgentInterventionRating_interventionId_fkey` FOREIGN KEY (`interventionId`) REFERENCES `AgentIntervention` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AgentInterventionRating_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentInterventionRating`
--

LOCK TABLES `AgentInterventionRating` WRITE;
/*!40000 ALTER TABLE `AgentInterventionRating` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentInterventionRating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentMembership`
--

DROP TABLE IF EXISTS `AgentMembership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AgentMembership` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agentId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `role` enum('SYSTEM','EXTERNAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EXTERNAL',
  `level` int NOT NULL DEFAULT '1',
  `xp` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AgentMembership_agentId_treeId_key` (`agentId`,`treeId`),
  KEY `AgentMembership_treeId_fkey` (`treeId`),
  CONSTRAINT `AgentMembership_agentId_fkey` FOREIGN KEY (`agentId`) REFERENCES `Agent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AgentMembership_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentMembership`
--

LOCK TABLES `AgentMembership` WRITE;
/*!40000 ALTER TABLE `AgentMembership` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentMembership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentPenaltyVote`
--

DROP TABLE IF EXISTS `AgentPenaltyVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AgentPenaltyVote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interventionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `penalty` enum('XP_LOSS','BEHAVIOR_REVIEW','NO_ACTION') COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AgentPenaltyVote_interventionId_userId_key` (`interventionId`,`userId`),
  KEY `AgentPenaltyVote_interventionId_idx` (`interventionId`),
  KEY `AgentPenaltyVote_userId_fkey` (`userId`),
  CONSTRAINT `AgentPenaltyVote_interventionId_fkey` FOREIGN KEY (`interventionId`) REFERENCES `AgentIntervention` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AgentPenaltyVote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentPenaltyVote`
--

LOCK TABLES `AgentPenaltyVote` WRITE;
/*!40000 ALTER TABLE `AgentPenaltyVote` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentPenaltyVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentProfile`
--

DROP TABLE IF EXISTS `AgentProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AgentProfile` (
  `agentId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `totalRatings` int NOT NULL DEFAULT '0',
  `avgStars` double NOT NULL DEFAULT '0',
  `xpByRole` json NOT NULL DEFAULT (_utf8mb4'{}'),
  `primaryRole` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondaryRole` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confidenceScore` double NOT NULL DEFAULT '0',
  `lastActiveAt` datetime(3) DEFAULT NULL,
  `explorationEligible` tinyint(1) NOT NULL DEFAULT '1',
  `currentTreeCount` int NOT NULL DEFAULT '0',
  `updatedAt` datetime(3) NOT NULL ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`agentId`),
  CONSTRAINT `AgentProfile_agentId_fkey` FOREIGN KEY (`agentId`) REFERENCES `Agent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentProfile`
--

LOCK TABLES `AgentProfile` WRITE;
/*!40000 ALTER TABLE `AgentProfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentProfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentRoleHistory`
--

DROP TABLE IF EXISTS `AgentRoleHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AgentRoleHistory` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agentId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assignedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `releasedAt` datetime(3) DEFAULT NULL,
  `assignmentReason` enum('EXPLORATION','EXPLOITATION','MANUAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `performanceScore` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `AgentRoleHistory_agentId_idx` (`agentId`),
  KEY `AgentRoleHistory_treeId_idx` (`treeId`),
  KEY `AgentRoleHistory_agentId_treeId_idx` (`agentId`,`treeId`),
  CONSTRAINT `AgentRoleHistory_agentId_fkey` FOREIGN KEY (`agentId`) REFERENCES `Agent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AgentRoleHistory_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentRoleHistory`
--

LOCK TABLES `AgentRoleHistory` WRITE;
/*!40000 ALTER TABLE `AgentRoleHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentRoleHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AiExecution`
--

DROP TABLE IF EXISTS `AiExecution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AiExecution` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aiMemberId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kanbanTaskId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PENDING','RUNNING','COMPLETED','FAILED','TIMED_OUT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `promptText` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `output` text COLLATE utf8mb4_unicode_ci,
  `attemptNumber` int NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `completedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `AiExecution_taskId_idx` (`taskId`),
  KEY `AiExecution_aiMemberId_idx` (`aiMemberId`),
  KEY `AiExecution_status_idx` (`status`),
  CONSTRAINT `AiExecution_aiMemberId_fkey` FOREIGN KEY (`aiMemberId`) REFERENCES `TreeMember` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AiExecution`
--

LOCK TABLES `AiExecution` WRITE;
/*!40000 ALTER TABLE `AiExecution` DISABLE KEYS */;
/*!40000 ALTER TABLE `AiExecution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AlertaZonal`
--

DROP TABLE IF EXISTS `AlertaZonal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AlertaZonal` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emisorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashtag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gravedad` int NOT NULL DEFAULT '1',
  `scope` enum('PAIS','CIUDAD','SECTOR') COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetLocation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expiresAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `AlertaZonal_scope_targetLocation_idx` (`scope`,`targetLocation`),
  KEY `AlertaZonal_expiresAt_idx` (`expiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AlertaZonal`
--

LOCK TABLES `AlertaZonal` WRITE;
/*!40000 ALTER TABLE `AlertaZonal` DISABLE KEYS */;
/*!40000 ALTER TABLE `AlertaZonal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ApiUsage`
--

DROP TABLE IF EXISTS `ApiUsage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ApiUsage` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` bigint NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'deepseek',
  `model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tokensIn` int NOT NULL DEFAULT '0',
  `tokensOut` int NOT NULL DEFAULT '0',
  `cost` double NOT NULL DEFAULT '0',
  `messagePreview` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `absorbedByPlatform` double NOT NULL DEFAULT '0',
  `isFreePeriod` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ApiUsage_userId_idx` (`userId`),
  KEY `ApiUsage_treeId_idx` (`treeId`),
  KEY `ApiUsage_createdAt_idx` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ApiUsage`
--

LOCK TABLES `ApiUsage` WRITE;
/*!40000 ALTER TABLE `ApiUsage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ApiUsage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssetFund`
--

DROP TABLE IF EXISTS `AssetFund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AssetFund` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` double NOT NULL DEFAULT '0',
  `type` enum('FIAT','PROPERTY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssetFund`
--

LOCK TABLES `AssetFund` WRITE;
/*!40000 ALTER TABLE `AssetFund` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssetFund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Auditoria`
--

DROP TABLE IF EXISTS `Auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Auditoria` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuarioId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notaSugerida` int NOT NULL,
  `fechaCreacion` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Auditoria_usuarioId_idx` (`usuarioId`),
  KEY `Auditoria_taskId_idx` (`taskId`),
  CONSTRAINT `Auditoria_taskId_fkey` FOREIGN KEY (`taskId`) REFERENCES `Task` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Auditoria`
--

LOCK TABLES `Auditoria` WRITE;
/*!40000 ALTER TABLE `Auditoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `Auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AutosustentoBranchConfig`
--

DROP TABLE IF EXISTS `AutosustentoBranchConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AutosustentoBranchConfig` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branchId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `businessName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productOrService` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetClient` text COLLATE utf8mb4_unicode_ci,
  `valueProposition` text COLLATE utf8mb4_unicode_ci,
  `status` enum('PROPOSED','UNDER_REVIEW','APPROVED','ACTIVE','PAUSED','REJECTED','CLOSED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROPOSED',
  `viabilitySummary` text COLLATE utf8mb4_unicode_ci,
  `requiredResources` text COLLATE utf8mb4_unicode_ci,
  `legalRisks` text COLLATE utf8mb4_unicode_ci,
  `operationalRisks` text COLLATE utf8mb4_unicode_ci,
  `startupCostFiat` double DEFAULT NULL,
  `expectedMonthlyIncomeFiat` double DEFAULT NULL,
  `expectedMonthlyCostFiat` double DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'CLP',
  `reviewPeriodDays` int DEFAULT '90',
  `nextReviewAt` datetime(3) DEFAULT NULL,
  `closureCriteria` text COLLATE utf8mb4_unicode_ci,
  `metadataJson` json DEFAULT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AutosustentoBranchConfig_branchId_key` (`branchId`),
  KEY `AutosustentoBranchConfig_treeId_idx` (`treeId`),
  KEY `AutosustentoBranchConfig_status_idx` (`status`),
  KEY `AutosustentoBranchConfig_createdById_idx` (`createdById`),
  CONSTRAINT `AutosustentoBranchConfig_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AutosustentoBranchConfig_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AutosustentoBranchConfig`
--

LOCK TABLES `AutosustentoBranchConfig` WRITE;
/*!40000 ALTER TABLE `AutosustentoBranchConfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `AutosustentoBranchConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BonusPool`
--

DROP TABLE IF EXISTS `BonusPool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BonusPool` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashtag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `puntosImportanciaTotal` double NOT NULL DEFAULT '0',
  `porcentajeActual` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BonusPool_treeId_hashtag_key` (`treeId`,`hashtag`),
  KEY `BonusPool_treeId_idx` (`treeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BonusPool`
--

LOCK TABLES `BonusPool` WRITE;
/*!40000 ALTER TABLE `BonusPool` DISABLE KEYS */;
/*!40000 ALTER TABLE `BonusPool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BonusVote`
--

DROP TABLE IF EXISTS `BonusVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BonusVote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bonusPoolId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL DEFAULT '5',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BonusVote_bonusPoolId_userId_key` (`bonusPoolId`,`userId`),
  KEY `BonusVote_bonusPoolId_idx` (`bonusPoolId`),
  KEY `BonusVote_userId_fkey` (`userId`),
  CONSTRAINT `BonusVote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BonusVote`
--

LOCK TABLES `BonusVote` WRITE;
/*!40000 ALTER TABLE `BonusVote` DISABLE KEYS */;
/*!40000 ALTER TABLE `BonusVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BotKanbanTask`
--

DROP TABLE IF EXISTS `BotKanbanTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BotKanbanTask` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kanbanTaskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chatId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastNotifiedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `BotKanbanTask_kanbanTaskId_idx` (`kanbanTaskId`),
  KEY `BotKanbanTask_chatId_idx` (`chatId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BotKanbanTask`
--

LOCK TABLES `BotKanbanTask` WRITE;
/*!40000 ALTER TABLE `BotKanbanTask` DISABLE KEYS */;
/*!40000 ALTER TABLE `BotKanbanTask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Branch`
--

DROP TABLE IF EXISTS `Branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Branch` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ideaId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('NORMAL','HASHTAG','AUTOSUSTENTO','EXTERNAL_CONTRACT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `xpPool` double NOT NULL DEFAULT '0',
  `isDesire` tinyint(1) NOT NULL DEFAULT '0',
  `isHashtag` tinyint(1) NOT NULL DEFAULT '0',
  `bayasFund` double NOT NULL DEFAULT '0',
  `esVotable` tinyint(1) NOT NULL DEFAULT '1',
  `valorSugerido` double DEFAULT NULL,
  `valorOficial` double NOT NULL DEFAULT '0',
  `phase` enum('INVESTIGATION','DEVELOPMENT','PRODUCTION','DISTRIBUTION','MAINTENANCE','RECYCLING') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INVESTIGATION',
  `activePhasesJson` text COLLATE utf8mb4_unicode_ci,
  `currentPhaseIndex` int NOT NULL DEFAULT '0',
  `expiresAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Branch_ideaId_key` (`ideaId`),
  KEY `Branch_treeId_idx` (`treeId`),
  KEY `Branch_type_idx` (`type`),
  KEY `Branch_userId_fkey` (`userId`),
  CONSTRAINT `Branch_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Branch_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Branch`
--

LOCK TABLES `Branch` WRITE;
/*!40000 ALTER TABLE `Branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `Branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BranchMember`
--

DROP TABLE IF EXISTS `BranchMember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BranchMember` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branchId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `joinedPhases` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `joinedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `BranchMember_userId_branchId_key` (`userId`,`branchId`),
  CONSTRAINT `BranchMember_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BranchMember`
--

LOCK TABLES `BranchMember` WRITE;
/*!40000 ALTER TABLE `BranchMember` DISABLE KEYS */;
/*!40000 ALTER TABLE `BranchMember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BranchNeedVote`
--

DROP TABLE IF EXISTS `BranchNeedVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BranchNeedVote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branchId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL DEFAULT '5',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `BranchNeedVote_branchId_userId_key` (`branchId`,`userId`),
  KEY `BranchNeedVote_userId_fkey` (`userId`),
  CONSTRAINT `BranchNeedVote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BranchNeedVote`
--

LOCK TABLES `BranchNeedVote` WRITE;
/*!40000 ALTER TABLE `BranchNeedVote` DISABLE KEYS */;
/*!40000 ALTER TABLE `BranchNeedVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BudgetAllocation`
--

DROP TABLE IF EXISTS `BudgetAllocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BudgetAllocation` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parentTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `childTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` double NOT NULL,
  `fixedAmount` double DEFAULT NULL,
  `effectiveFrom` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `effectiveUntil` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BudgetAllocation_childTreeId_key` (`childTreeId`),
  KEY `BudgetAllocation_parentTreeId_idx` (`parentTreeId`),
  CONSTRAINT `BudgetAllocation_childTreeId_fkey` FOREIGN KEY (`childTreeId`) REFERENCES `Tree` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `BudgetAllocation_parentTreeId_fkey` FOREIGN KEY (`parentTreeId`) REFERENCES `Tree` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BudgetAllocation`
--

LOCK TABLES `BudgetAllocation` WRITE;
/*!40000 ALTER TABLE `BudgetAllocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `BudgetAllocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BudgetLine`
--

DROP TABLE IF EXISTS `BudgetLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BudgetLine` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `solutionProposalId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` enum('LABOR','MATERIALS','INFRASTRUCTURE','TAXES','RESERVE','TREE_FUND','MAINTENANCE','EXTERNAL_SERVICE','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `estimatedFiat` double DEFAULT NULL,
  `estimatedBerries` int DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'CLP',
  `quantity` double DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitCostFiat` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `BudgetLine_solutionProposalId_idx` (`solutionProposalId`),
  KEY `BudgetLine_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BudgetLine`
--

LOCK TABLES `BudgetLine` WRITE;
/*!40000 ALTER TABLE `BudgetLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `BudgetLine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ByoApiKey`
--

DROP TABLE IF EXISTS `ByoApiKey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ByoApiKey` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'My Key',
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apiKey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `costPerToken` double NOT NULL DEFAULT '0',
  `maxParallel` int NOT NULL DEFAULT '5',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `ByoApiKey_userId_idx` (`userId`),
  KEY `ByoApiKey_userId_provider_idx` (`userId`,`provider`),
  CONSTRAINT `ByoApiKey_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ByoApiKey`
--

LOCK TABLES `ByoApiKey` WRITE;
/*!40000 ALTER TABLE `ByoApiKey` DISABLE KEYS */;
/*!40000 ALTER TABLE `ByoApiKey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CancelledPlan`
--

DROP TABLE IF EXISTS `CancelledPlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CancelledPlan` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `skills` json NOT NULL,
  `budget` int NOT NULL,
  `motivo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `CancelledPlan_treeId_idx` (`treeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CancelledPlan`
--

LOCK TABLES `CancelledPlan` WRITE;
/*!40000 ALTER TABLE `CancelledPlan` DISABLE KEYS */;
INSERT INTO `CancelledPlan` VALUES ('2f286203-8386-48fc-9f76-1b1959d2dc72','E2E Cancel Test 1779132223155','This task was cancelled due to budget constraints\n\n--- Alternativas propuestas ---\n\n1. Reducir scope\n2. Dividir en micro-tareas\n3. Posponer','[\"typescript\", \"nodejs\"]',50000,'Presupuesto insuficiente','ecaa3d3a-0889-4ab3-aad4-3a7669bcad01','2026-05-18 19:23:43.161'),('584f0f6b-b716-414a-b08c-82eb24cb17cd','E2E Cancel Test 1779132476765','This task was cancelled due to budget constraints\n\n--- Alternativas propuestas ---\n\n1. Reducir scope\n2. Dividir en micro-tareas\n3. Posponer','[\"typescript\", \"nodejs\"]',50000,'Presupuesto insuficiente','7f71975e-7332-4de1-9bcb-eaca7e11e62f','2026-05-18 19:27:56.767');
/*!40000 ALTER TABLE `CancelledPlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Candidate`
--

DROP TABLE IF EXISTS `Candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Candidate` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDING','ACCEPTED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Candidate_taskId_idx` (`taskId`),
  KEY `Candidate_treeId_idx` (`treeId`),
  KEY `Candidate_userId_taskId_idx` (`userId`,`taskId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Candidate`
--

LOCK TABLES `Candidate` WRITE;
/*!40000 ALTER TABLE `Candidate` DISABLE KEYS */;
INSERT INTO `Candidate` VALUES ('0de4ce94-860b-4300-acfa-6775e71885bc','09667281-c65a-464c-b895-6e21116964bb','t_e2e_v4_d_1779132476726','7f71975e-7332-4de1-9bcb-eaca7e11e62f','REJECTED','2026-05-18 19:27:56.733'),('27f780ce-41b7-4e67-b0c2-18d05ab8a925','08e75fbf-4a4b-4b80-8362-b96c60bacad7','t_e2e_v4_c_1779132223001','ecaa3d3a-0889-4ab3-aad4-3a7669bcad01','REJECTED','2026-05-18 19:23:43.011'),('28a230eb-0e4c-48e1-b693-515d76d87189','09667281-c65a-464c-b895-6e21116964bb','t_e2e_v4_1779132476434','7f71975e-7332-4de1-9bcb-eaca7e11e62f','ACCEPTED','2026-05-18 19:27:56.585'),('31f49f22-97f8-4351-9c47-d5afd9f4626c','08e75fbf-4a4b-4b80-8362-b96c60bacad7','t_e2e_v4_1779132476434','7f71975e-7332-4de1-9bcb-eaca7e11e62f','REJECTED','2026-05-18 19:27:56.606'),('32c07d93-6672-46d9-ab35-a7fcca98a875','08e75fbf-4a4b-4b80-8362-b96c60bacad7','t_e2e_v4_d_1779132223101','ecaa3d3a-0889-4ab3-aad4-3a7669bcad01','REJECTED','2026-05-18 19:23:43.112'),('4e70c27e-69c1-4062-a568-64b02d61c575','09667281-c65a-464c-b895-6e21116964bb','t_e2e_v4_1779132222733','ecaa3d3a-0889-4ab3-aad4-3a7669bcad01','REJECTED','2026-05-18 19:23:42.928'),('5a413dd0-2024-4765-a318-5475702101f7','08e75fbf-4a4b-4b80-8362-b96c60bacad7','t_e2e_v4_c_1779132476663','7f71975e-7332-4de1-9bcb-eaca7e11e62f','REJECTED','2026-05-18 19:27:56.685'),('76ed0f41-ad32-4f30-a176-43cd79083555','08e75fbf-4a4b-4b80-8362-b96c60bacad7','t_e2e_v4_1779132222733','ecaa3d3a-0889-4ab3-aad4-3a7669bcad01','ACCEPTED','2026-05-18 19:23:42.906'),('eb3c6281-2616-473f-8e18-934d54a0d4d0','09667281-c65a-464c-b895-6e21116964bb','t_e2e_v4_c_1779132476663','7f71975e-7332-4de1-9bcb-eaca7e11e62f','REJECTED','2026-05-18 19:27:56.669'),('f1ea5b3c-0a23-4b31-b6cd-d3adf0e9366d','09667281-c65a-464c-b895-6e21116964bb','t_e2e_v4_c_1779132223001','ecaa3d3a-0889-4ab3-aad4-3a7669bcad01','REJECTED','2026-05-18 19:23:43.041');
/*!40000 ALTER TABLE `Candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CandidateAnnouncement`
--

DROP TABLE IF EXISTS `CandidateAnnouncement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CandidateAnnouncement` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telegramChatId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `announcementMsgId` int NOT NULL,
  `deadline` datetime(3) NOT NULL,
  `reminderSentAt` datetime(3) DEFAULT NULL,
  `reminderMsgId` int DEFAULT NULL,
  `pollId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pollMessageId` int DEFAULT NULL,
  `pollClosed` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `CandidateAnnouncement_taskId_idx` (`taskId`),
  KEY `CandidateAnnouncement_treeId_idx` (`treeId`),
  KEY `CandidateAnnouncement_deadline_idx` (`deadline`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CandidateAnnouncement`
--

LOCK TABLES `CandidateAnnouncement` WRITE;
/*!40000 ALTER TABLE `CandidateAnnouncement` DISABLE KEYS */;
/*!40000 ALTER TABLE `CandidateAnnouncement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatMessage`
--

DROP TABLE IF EXISTS `ChatMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ChatMessage` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `agentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ChatMessage_userId_treeId_createdAt_idx` (`userId`,`treeId`,`createdAt`),
  KEY `ChatMessage_treeId_agentId_createdAt_idx` (`treeId`,`agentId`,`createdAt`),
  CONSTRAINT `chatmessage_tree_fk` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chatmessage_user_fk` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatMessage`
--

LOCK TABLES `ChatMessage` WRITE;
/*!40000 ALTER TABLE `ChatMessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatMessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ConnectionToken`
--

DROP TABLE IF EXISTS `ConnectionToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ConnectionToken` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `usedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ConnectionToken_token_key` (`token`),
  KEY `ConnectionToken_token_idx` (`token`),
  KEY `ConnectionToken_userId_idx` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ConnectionToken`
--

LOCK TABLES `ConnectionToken` WRITE;
/*!40000 ALTER TABLE `ConnectionToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `ConnectionToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DifficultyVote`
--

DROP TABLE IF EXISTS `DifficultyVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DifficultyVote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valido',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DifficultyVote_userId_taskId_key` (`userId`,`taskId`),
  CONSTRAINT `DifficultyVote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DifficultyVote`
--

LOCK TABLES `DifficultyVote` WRITE;
/*!40000 ALTER TABLE `DifficultyVote` DISABLE KEYS */;
/*!40000 ALTER TABLE `DifficultyVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DifficultyVoteLike`
--

DROP TABLE IF EXISTS `DifficultyVoteLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DifficultyVoteLike` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `voteId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `DifficultyVoteLike_voteId_userId_key` (`voteId`,`userId`),
  KEY `DifficultyVoteLike_userId_fkey` (`userId`),
  CONSTRAINT `DifficultyVoteLike_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DifficultyVoteLike`
--

LOCK TABLES `DifficultyVoteLike` WRITE;
/*!40000 ALTER TABLE `DifficultyVoteLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `DifficultyVoteLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EventLog`
--

DROP TABLE IF EXISTS `EventLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EventLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actorId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beforeJson` json DEFAULT NULL,
  `afterJson` json DEFAULT NULL,
  `metadataJson` json DEFAULT NULL,
  `ipAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userAgent` text COLLATE utf8mb4_unicode_ci,
  `severity` enum('INFO','WARNING','CRITICAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INFO',
  `source` enum('USER','SYSTEM','ADMIN','AUTOMATION') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USER',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `EventLog_treeId_idx` (`treeId`),
  KEY `EventLog_actorId_idx` (`actorId`),
  KEY `EventLog_entityType_entityId_idx` (`entityType`,`entityId`),
  KEY `EventLog_action_idx` (`action`),
  KEY `EventLog_createdAt_idx` (`createdAt`),
  KEY `EventLog_severity_idx` (`severity`),
  CONSTRAINT `EventLog_actorId_fkey` FOREIGN KEY (`actorId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `EventLog_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EventLog`
--

LOCK TABLES `EventLog` WRITE;
/*!40000 ALTER TABLE `EventLog` DISABLE KEYS */;
INSERT INTO `EventLog` VALUES ('00454e4b-a60c-494b-8e09-9cdc7437fbe7',NULL,'0a08c64a-3126-4492-8e00-9c4f44f43086','USER_REGISTERED','User','0a08c64a-3126-4492-8e00-9c4f44f43086',NULL,'{\"id\": \"0a08c64a-3126-4492-8e00-9c4f44f43086\", \"role\": \"USER\", \"email\": \"sqliso_1779201097161@test.com\", \"username\": \"sqliso_1779201097161\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:31:37.490'),('020e4c5a-c388-43c0-a5fc-b4e66b399edf',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 14:04:26.067'),('02207d75-81b0-400a-afae-4328afaaa170',NULL,'0876799c-fd21-4da0-8c6b-e1fa4eb22376','USER_REGISTERED','User','0876799c-fd21-4da0-8c6b-e1fa4eb22376',NULL,'{\"id\": \"0876799c-fd21-4da0-8c6b-e1fa4eb22376\", \"role\": \"USER\", \"email\": \"surveyvoter_1_1779200734132@test.com\", \"username\": \"surveyvoter_1_1779200734132\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:25:34.326'),('0292f0b6-826f-48ff-843d-83b1da03362d',NULL,'df7de8fb-e02c-4726-b896-0122cc86037c','USER_REGISTERED','User','df7de8fb-e02c-4726-b896-0122cc86037c',NULL,'{\"id\": \"df7de8fb-e02c-4726-b896-0122cc86037c\", \"role\": \"USER\", \"email\": \"pricing@test.com\", \"username\": \"pricingtest\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-15 00:33:18.536'),('02dd380d-dfab-448d-b7af-9e3c826864fc','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_READ','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:56:28.991'),('02e00fee-38e9-4e37-8a15-df72f5e85c88','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_READ','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:57:02.183'),('045b8d0c-1440-4f5d-95ca-6f5c464c6f3d',NULL,'68907da8-6eca-41aa-affa-e4710435daff','TREE_CREATED','Tree','3bec632f-d6ff-420f-ad68-e5abe47b524c',NULL,'{\"id\": \"3bec632f-d6ff-420f-ad68-e5abe47b524c\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:42:42.098'),('047bad70-e051-422d-8c03-7a567c468c82',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:41:26.060'),('050986e2-8f59-4492-a674-e8af42f9e97e',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','WARNING','USER','2026-05-13 18:43:16.046'),('054ad83b-936c-4234-97ec-89a127da0d9d',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_SUCCESS','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:25:08.411'),('05c52b9f-b7e4-4563-a177-52e7da46b593',NULL,NULL,'TREE_MEMBER_JOINED','TreeMember','051dda42-2061-45dc-bd72-f745d3bdbda8',NULL,NULL,'{\"via\": \"open_tree\", \"route\": \"/api/trees/join\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 15:23:11.404'),('066c8ce9-429f-4f55-a0ca-c0be98dfcabe',NULL,'5d47ff7a-b727-4fef-88bc-a04469384b5c','USER_REGISTERED','User','5d47ff7a-b727-4fef-88bc-a04469384b5c',NULL,'{\"id\": \"5d47ff7a-b727-4fef-88bc-a04469384b5c\", \"role\": \"USER\", \"email\": \"sqliso_1779201735972@test.com\", \"username\": \"sqliso_1779201735972\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:42:16.304'),('06b0d2e8-c7ae-4b87-b54b-bb2038e54617','7c02aba7-ef75-43dc-be8e-92f652b1ed68',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','7c02aba7-ef75-43dc-be8e-92f652b1ed68',NULL,NULL,'{\"query\": \"test\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:35:55.541'),('06b4fecc-73c1-4634-ad91-808998b924a6',NULL,'942125f0-2e1c-4c4c-a382-ebfb63f17f3d','TREE_CREATED','Tree','cc01e186-a9ec-4b02-a03f-af4cdd19432a',NULL,'{\"id\": \"cc01e186-a9ec-4b02-a03f-af4cdd19432a\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 11:41:57.377'),('06d2ce5f-046f-4eea-a292-6fa5d837b58a',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:33:41.953'),('06ddff89-24e7-4141-8940-6535abcae116','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 0}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:52:21.152'),('08393f63-2eb7-4538-8396-846665b0a79b',NULL,'ebf76fd4-281d-4ca6-ac52-0035556c259e','TREE_CREATED','Tree','f46abf18-ccaa-435f-ac3c-7b5e7a3a4622',NULL,'{\"id\": \"f46abf18-ccaa-435f-ac3c-7b5e7a3a4622\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:26:29.005'),('08de718a-d4f6-455b-b224-4ed320894817',NULL,NULL,'USER_LOGIN_SUCCESS','User','5e5cdf70-f348-424a-9391-b7f936f91374',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:20:17.093'),('093564b7-12c4-4fdd-abba-aadaddd0aa06',NULL,'86ab07ff-5932-46ea-ad89-a742815d4e8d','TREE_CREATED','Tree','be982170-e43b-40e0-8fc3-573a8ecb2b34',NULL,'{\"id\": \"be982170-e43b-40e0-8fc3-573a8ecb2b34\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:21:17.224'),('09846901-f684-410c-aa3f-2ba2da49d0bc','7c02aba7-ef75-43dc-be8e-92f652b1ed68',NULL,'SANDBOX_WRITE','TreeSandbox','7c02aba7-ef75-43dc-be8e-92f652b1ed68',NULL,NULL,NULL,'127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 04:39:28.357'),('0ab0f42a-20d6-4863-ba8e-9594bb5c7ddb','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_WRITE','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:35:48.522'),('0aba7ffb-11dd-4f13-bef7-d6e9e09b0e60',NULL,'68907da8-6eca-41aa-affa-e4710435daff','TREE_CREATED','Tree','8779e032-5b70-423f-9aa0-c49478705519',NULL,'{\"id\": \"8779e032-5b70-423f-9aa0-c49478705519\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:42:44.010'),('0c061b69-491b-4d90-95b7-b60ebf9e0d47',NULL,'14f24111-6c3d-4ddc-9669-73d0d3703cd0','USER_LOGIN_SUCCESS','User','14f24111-6c3d-4ddc-9669-73d0d3703cd0',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:22:31.248'),('0c085f05-ea69-4661-a0c8-664dd46560e0',NULL,NULL,'USER_LOGIN_SUCCESS','User','7b446ec1-1f1b-4efa-b2e3-c218632abc69',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 13:20:41.027'),('0c1748bf-ef5b-43e5-9f05-a51acf55aec9',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 13:10:31.152'),('0d114a6a-661e-4daf-8de8-f710e5a1bd1a','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'BOT_SEND_DOCUMENT','Tree','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"chatId\": \"-5066010052\", \"fileName\": \"[REDACTED]\", \"fileSize\": \"[REDACTED]\", \"messageId\": 583}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-17 03:21:54.202'),('0d54e6f4-caf6-4123-94fe-de3510ec8bef',NULL,'942125f0-2e1c-4c4c-a382-ebfb63f17f3d','TREE_CREATED','Tree','bbc13f70-1646-4fcc-bb9f-97f672e25f51',NULL,'{\"id\": \"bbc13f70-1646-4fcc-bb9f-97f672e25f51\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 11:41:58.100'),('104a6b6a-5825-4840-92cf-38bbc9b92f81',NULL,'1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','TREE_CREATED','Tree','fe646452-0da2-4de0-baa0-e709586f7278',NULL,'{\"id\": \"fe646452-0da2-4de0-baa0-e709586f7278\", \"name\": \"Integration Test N6 v3\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 11:31:45.311'),('10a5678f-cb55-445c-a568-df02306d9e58',NULL,'ebf76fd4-281d-4ca6-ac52-0035556c259e','TREE_CREATED','Tree','dd5c8954-adee-4e97-a9dd-a30c2696af9e',NULL,'{\"id\": \"dd5c8954-adee-4e97-a9dd-a30c2696af9e\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:26:27.093'),('1114e721-8ad5-4328-a7e1-a5478633fd80',NULL,NULL,'TASK_DISPUTED','Task','bbbbbbbb-2222-4ccc-8ddd-eeeeffff0002',NULL,'{\"disputedById\": \"db98f726-8ac4-4fd5-b560-1c6b92e1ab26\", \"disputeReason\": \"Evidencia insuficiente - no se ve el resultado final\", \"disputeEvidenceUrl\": \"[REDACTED]\"}',NULL,NULL,NULL,'WARNING','USER','2026-05-14 11:41:48.400'),('11941434-ec73-44aa-9fc0-5110e507e7a8',NULL,NULL,'USER_LOGIN_SUCCESS','User','5e5cdf70-f348-424a-9391-b7f936f91374',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:17:16.251'),('11d32c85-5366-4052-98d9-6f5994c4f725',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 14:02:03.355'),('13bd12c8-9a1e-4515-add1-3c7959618681','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_LIST','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:37:02.760'),('148785f5-ecca-4d56-ace1-e522e5f32206',NULL,'6fe69220-33e9-4c86-8e5d-b8ba924c5962','USER_LOGIN_SUCCESS','User','6fe69220-33e9-4c86-8e5d-b8ba924c5962',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 19:27:36.807'),('161ce1e2-0f2e-4522-9ed3-6588605e0143',NULL,'e8ea827e-1378-4ed1-85ce-4850ddc7221f','TREE_CREATED','Tree','b2f6ce37-4d2b-490b-b1ba-a6ce99040aea',NULL,'{\"id\": \"b2f6ce37-4d2b-490b-b1ba-a6ce99040aea\", \"name\": \"SQL Iso Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:39:59.543'),('179a91f2-68fa-4b36-b179-ce9b1f109b72',NULL,'a017be03-4b21-4477-992d-0da855531b8e','USER_LOGIN_SUCCESS','User','a017be03-4b21-4477-992d-0da855531b8e',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:22:10.973'),('17bb482a-956a-445c-919c-0422558db51e',NULL,'4ba12ced-0fad-4aeb-af79-490873802100','TREE_CREATED','Tree','6ba782ce-e489-4d4c-a257-eff9966962d1',NULL,'{\"id\": \"6ba782ce-e489-4d4c-a257-eff9966962d1\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-17 17:14:09.602'),('186e2bc4-3af7-4d05-9f08-9aa6dbb69cf8',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 14:01:36.524'),('1880199c-def3-41d3-951c-6464cb07240a',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 14:37:13.260'),('18c7aae1-11e4-4302-aa65-d2903795ee8f','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_WRITE','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:36:48.746'),('19933d17-a0e6-4770-b8af-c0f685c6eaa6','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_READ','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:57:34.717'),('199fa8e1-3c33-464a-bda0-00be6f6c71bd',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_SUCCESS','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:30:12.951'),('1a0bfdb4-43ba-4587-9ac6-d220de0a1d63',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 16:38:00.890'),('1a1dab3c-a372-49ff-824c-177ba220cc05',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:28:38.262'),('1a79a901-d379-4b44-a3cd-a13ca80f8fa3',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 11:29:35.323'),('1a851e48-0b69-4d72-abb6-3c22a8062e34',NULL,'87dad90d-cc5f-44df-8efa-9e76bfbfce0f','USER_LOGIN_FAILED','User','87dad90d-cc5f-44df-8efa-9e76bfbfce0f',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:22:10.349'),('1d2843f8-f262-4956-9d50-5ecfda7cff16',NULL,NULL,'USER_LOGIN_SUCCESS','User','5e5cdf70-f348-424a-9391-b7f936f91374',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:17:05.302'),('1ef845cf-7fad-4307-8d2e-6fd312c6d6ed',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 14:01:23.059'),('1f6b3eca-51ae-49c7-9ee2-0b7ea7507791',NULL,'87dad90d-cc5f-44df-8efa-9e76bfbfce0f','USER_REGISTERED','User','87dad90d-cc5f-44df-8efa-9e76bfbfce0f',NULL,'{\"id\": \"87dad90d-cc5f-44df-8efa-9e76bfbfce0f\", \"role\": \"USER\", \"email\": \"testv3@test.com\", \"username\": \"testv3\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 12:52:10.693'),('2022f85c-1609-4a99-b1ed-53a299db9458',NULL,'ari','TREE_CREATED','Tree','28340d40-7d36-485f-9690-8fbd12ad7b07',NULL,'{\"id\": \"28340d40-7d36-485f-9690-8fbd12ad7b07\", \"name\": \"Raíz-E2E-1779158982047\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:49:42.145'),('217be0fa-3ccf-48da-9c62-708e910c3f48',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_LOGIN_SUCCESS','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:37:02.464'),('21a6f14e-e8d5-4f59-a821-8ef630468fe5','7c02aba7-ef75-43dc-be8e-92f652b1ed68',NULL,'SANDBOX_WRITE','TreeSandbox','7c02aba7-ef75-43dc-be8e-92f652b1ed68',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:36:06.972'),('21a7bed3-4d43-4499-b0a0-ccccd0246e80',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_SUCCESS','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 18:55:13.232'),('22022296-e0bf-4550-84e6-1e90a244a1b1',NULL,NULL,'USER_LOGIN_SUCCESS','User','7b446ec1-1f1b-4efa-b2e3-c218632abc69',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 13:17:30.166'),('22070bc1-1275-4979-b8d7-a84f54100879',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:28:42.524'),('2240b051-2628-41c7-ab5c-5f51012e42e1',NULL,'3f174e8e-5d21-434b-9705-68413394d778','TREE_CREATED','Tree','e12a032b-0eae-4497-8ced-a24798b4445e',NULL,'{\"id\": \"e12a032b-0eae-4497-8ced-a24798b4445e\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:25:16.167'),('228d6c54-19c8-4204-aaf0-9f129ea811bd',NULL,'7d7465e7-e3b8-4f85-8e01-40b2d958392a','USER_LOGIN_SUCCESS','User','7d7465e7-e3b8-4f85-8e01-40b2d958392a',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:40:30.913'),('22e04f01-2d80-40f8-8ac0-43275d688a90',NULL,'4ba12ced-0fad-4aeb-af79-490873802100','TREE_CREATED','Tree','648977ac-d578-4f5f-975c-2dfe307acdfc',NULL,'{\"id\": \"648977ac-d578-4f5f-975c-2dfe307acdfc\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-17 17:14:08.345'),('249d075c-1fa0-4000-ab53-ed58ffc15c68',NULL,'614b8f42-4e90-4331-9cf9-2a0bb6589e16','TOOL_RECOMMENDATION_GENERATED','GroupTool','recommendation',NULL,NULL,'{\"groupType\": \"albañiles\", \"infraType\": \"owned\", \"fixedCount\": 1, \"poolAmount\": 30, \"totalTools\": 0, \"catalogSize\": 0, \"hasServerEstimate\": false}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:47:29.391'),('254b9c33-f334-49f5-9d08-40f0de3285e6',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:49:23.654'),('25e1b7ee-83d9-4991-98a7-af6ab9f4e4fb',NULL,'ari','TREE_CREATED','Tree','99140ca0-4535-4ad1-b156-04aab178d5b0',NULL,'{\"id\": \"99140ca0-4535-4ad1-b156-04aab178d5b0\", \"name\": \"Padre-E2E-1779167349525\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 1}','127.0.0.1','node','INFO','USER','2026-05-19 05:09:09.621'),('265b3390-eccd-4230-8a96-c8fdfa1a79da',NULL,NULL,'USER_REGISTERED','User','6e50f63e-040b-4477-b9bc-2d258f791be6',NULL,'{\"id\": \"6e50f63e-040b-4477-b9bc-2d258f791be6\", \"role\": \"USER\", \"email\": \"test_ci@test.com\", \"username\": \"testuser_ci\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:22:35.041'),('27233f8d-6e02-4a4a-8241-1cb95b6f758d',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-16 15:48:00.989'),('2733e1b4-65c2-434c-9a87-bf7dfd079a3c','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_READ','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:33:54.387'),('273486d5-cc59-457d-87ee-65c9c79c766a',NULL,'e0712bee-a5e5-4a4e-b8f3-41b115d8bda9','TREE_CREATED','Tree','ee15e86f-ce80-4749-8585-8585189f7ac1',NULL,'{\"id\": \"ee15e86f-ce80-4749-8585-8585189f7ac1\", \"name\": \"SurveyTest Tree 1779200699143\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:24:59.193'),('273db136-ff6a-4585-a1f2-c0af7842f953','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_READ','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:57:02.187'),('27864073-4dd0-4340-9026-2e7714a2a500',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 11:29:46.559'),('27f70332-9ab6-4475-8678-5c03ebd957ba',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 18:46:38.229'),('2853f5be-d8a3-4bfa-b7a7-3183e6a02384',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:27:59.814'),('286e7264-ca6a-4f83-9c91-eb77c8a18288','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:43:42.635'),('28eae60c-f285-42dd-a95f-5280a30dc549',NULL,'5d47ff7a-b727-4fef-88bc-a04469384b5c','TREE_CREATED','Tree','7569d083-f049-4985-addd-3c5bea843905',NULL,'{\"id\": \"7569d083-f049-4985-addd-3c5bea843905\", \"name\": \"SQL Iso Rate Limit\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:42:20.422'),('28ec7b7f-069c-4053-bac9-3cad464135d0',NULL,'ari','SUBTREE_CREATED','Tree','5ae25dcd-7f12-48b2-a28f-224688502a2b',NULL,'{\"id\": \"5ae25dcd-7f12-48b2-a28f-224688502a2b\", \"name\": \"Sub-API-E2E-1779166283844\", \"parentTreeId\": \"cc53a92e-8ec0-4877-a58e-10da1a272834\"}','{\"route\": \"/api/trees/cc53a92e-8ec0-4877-a58e-10da1a272834/subtree\", \"method\": \"POST\", \"result\": \"success\", \"parentTreeId\": \"cc53a92e-8ec0-4877-a58e-10da1a272834\"}','127.0.0.1','node','INFO','USER','2026-05-19 04:51:23.906'),('297df5f5-ddbe-4a53-96dd-f5e0f2064740',NULL,'8d93fc6c-f486-49a9-9849-b58bc9201167','USER_LOGIN_SUCCESS','User','8d93fc6c-f486-49a9-9849-b58bc9201167',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 14:02:13.565'),('2aba6266-5fbf-42d2-81bb-fede6cdaafa2',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 14:01:29.340'),('2abb5582-b0d1-4117-b755-f99d08938f3b',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 13:23:29.760'),('2abe6ebe-1215-4334-8bb2-304cd88a7d31',NULL,'4ba12ced-0fad-4aeb-af79-490873802100','TREE_CREATED','Tree','ce443b14-6a5e-4d18-a433-40134b56ef91',NULL,'{\"id\": \"ce443b14-6a5e-4d18-a433-40134b56ef91\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-17 17:14:07.600'),('2ce76939-5b45-437f-a68b-40ee1f8f9797',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:13:11.567'),('2d288330-9bf9-4217-86fc-002e3055dd56',NULL,'a103e261-4bbd-4dd9-a350-6cbad3f01a64','USER_REGISTERED','User','a103e261-4bbd-4dd9-a350-6cbad3f01a64',NULL,'{\"id\": \"a103e261-4bbd-4dd9-a350-6cbad3f01a64\", \"role\": \"USER\", \"email\": \"surveyvoter_2_1779200734364@test.com\", \"username\": \"surveyvoter_2_1779200734364\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:25:34.509'),('2d4440a1-9ddc-487d-9347-d62607844f50',NULL,NULL,'USER_LOGIN_SUCCESS','User','0451d945-17f8-4628-9e16-c0d8a1542a04',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:24:09.025'),('2d792dc1-52f6-4049-9a88-e5081ec1e75b',NULL,'14f24111-6c3d-4ddc-9669-73d0d3703cd0','USER_LOGIN_SUCCESS','User','14f24111-6c3d-4ddc-9669-73d0d3703cd0',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:16:56.494'),('2ed2807a-bf60-4ef0-9110-5ba5c1296054',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 00:27:05.141'),('2ffde688-aad9-4180-85ab-7e7a85e6ab04',NULL,'ebf76fd4-281d-4ca6-ac52-0035556c259e','TREE_CREATED','Tree','89479eb3-d30e-4a8d-9a4b-774df894c87d',NULL,'{\"id\": \"89479eb3-d30e-4a8d-9a4b-774df894c87d\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:26:29.594'),('30ce4c8e-5945-4f81-88d3-a9875d85b145',NULL,'7a3a01ae-7dcb-445d-942f-9996de05ddad','USER_REGISTERED','User','7a3a01ae-7dcb-445d-942f-9996de05ddad',NULL,'{\"id\": \"7a3a01ae-7dcb-445d-942f-9996de05ddad\", \"role\": \"USER\", \"email\": \"sandboxtest_1778855101922@test.com\", \"username\": \"sandboxtest_1778855101922\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 14:25:02.208'),('30d8e032-6f1a-4224-97bf-7c256625bbf9',NULL,'66c04512-b98e-48ef-b5ac-14386e21f0b8','TREE_CREATED','Tree','21e5404e-8b5b-455e-8441-4864a68166e0',NULL,'{\"id\": \"21e5404e-8b5b-455e-8441-4864a68166e0\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:50:32.608'),('31c01ed5-f195-4ee0-8a42-a530b3d57f8b',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 00:26:21.417'),('327752fb-81ce-4b33-84b6-ee7a683111d6',NULL,NULL,'BOT_SEND_DOCUMENT','Tree','e7082c9a-2e30-4546-bb24-db016dbb3f4b',NULL,NULL,'{\"chatId\": \"-5283959253\", \"fileName\": \"[REDACTED]\", \"fileSize\": \"[REDACTED]\", \"messageId\": 503}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-16 22:55:11.951'),('3325e6a8-3e54-4f19-add6-c5ae09b42f95','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:12:44.884'),('33a33f0d-b81e-403e-ae39-723b5dce851e',NULL,'e8ea827e-1378-4ed1-85ce-4850ddc7221f','USER_REGISTERED','User','e8ea827e-1378-4ed1-85ce-4850ddc7221f',NULL,'{\"id\": \"e8ea827e-1378-4ed1-85ce-4850ddc7221f\", \"role\": \"USER\", \"email\": \"sqliso_1779201599160@test.com\", \"username\": \"sqliso_1779201599160\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:39:59.492'),('34a950c7-c619-481b-ba50-5f44ac5405a2',NULL,NULL,'TREE_CREATED','Tree','ec8290bd-db4d-4f54-a95a-d0723881781c',NULL,'{\"id\": \"ec8290bd-db4d-4f54-a95a-d0723881781c\", \"name\": \"TestChat History\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:26:54.901'),('34e577d8-9b93-4597-924d-be710efb0fc0',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 12:52:03.677'),('34f2add9-367d-4f86-871e-66d25a0538bb',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_REGISTERED','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,'{\"id\": \"471a81d1-2a9b-4fdf-8f30-116178eaf85b\", \"role\": \"ADMIN\", \"email\": \"test@test.com\", \"username\": \"test\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 12:50:40.955'),('35268178-47dc-41f6-9f45-1129eb548df4',NULL,'1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','TREE_CREATED','Tree','cc9ebec1-5b64-43de-9a16-9366cddcd5d8',NULL,'{\"id\": \"cc9ebec1-5b64-43de-9a16-9366cddcd5d8\", \"name\": \"Integration Test N6\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 11:23:35.508'),('35e22c90-7080-4bc2-a378-334a551a1e45','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 0}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:16:19.523'),('36015d5b-3a3d-49f1-9d07-4c5c5b2879a3',NULL,'1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','USER_REGISTERED','User','1d776ba8-614e-4222-b1f5-c8e1f7e0c66e',NULL,'{\"id\": \"1d776ba8-614e-4222-b1f5-c8e1f7e0c66e\", \"role\": \"USER\", \"email\": \"n6-integration-test@trustmaker.dev\", \"username\": \"n6integration\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 11:22:35.144'),('3703c06b-49c6-42b4-bec4-71514dfe19af',NULL,'86a75cdd-221c-4ce0-8f07-7da08e21fdfb','USER_REGISTERED','User','86a75cdd-221c-4ce0-8f07-7da08e21fdfb',NULL,'{\"id\": \"86a75cdd-221c-4ce0-8f07-7da08e21fdfb\", \"role\": \"PERSON\", \"email\": \"cloudtest5@test.com\", \"username\": \"cloudtest5\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:48:04.745'),('381aa1f0-822b-427c-b633-4aa2eb2da60b',NULL,'f8be3975-34fb-422f-8746-2ebb436330b4','TREE_CREATED','Tree','d3251fe7-dd4a-4f6f-bbdc-71a698adc276',NULL,'{\"id\": \"d3251fe7-dd4a-4f6f-bbdc-71a698adc276\", \"name\": \"N6 Integration Test Tree\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees/\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 09:44:30.604'),('382189a2-c50e-47e4-9277-1490f93e988a',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 16:32:39.840'),('382d84e8-6207-476c-aedb-43909a881f27',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 13:25:47.490'),('38c0e48b-c310-408f-93f3-4167380139b2',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:52:04.556'),('39878752-13e8-475e-ba2e-0b31b278e33f',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 13:58:54.743'),('3a15de34-34f9-4236-be83-ff2c0d665204',NULL,'3f174e8e-5d21-434b-9705-68413394d778','TREE_CREATED','Tree','e1e15b07-7979-4471-9b9f-160c2d0e029e',NULL,'{\"id\": \"e1e15b07-7979-4471-9b9f-160c2d0e029e\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:25:17.998'),('3a4ffda7-e3c2-4267-b19f-7165083ae080',NULL,'4e230f5d-4b16-4082-b504-309106a90d34','USER_LOGIN_SUCCESS','User','4e230f5d-4b16-4082-b504-309106a90d34',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:28:59.212'),('3aa1a3b5-fc52-4607-8adb-852f892c416c','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_READ','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:57:34.732'),('3b3e68db-c930-49c2-adcb-453cd7eb06f6',NULL,'ari','TREE_CREATED','Tree','b3c86ef5-5019-4349-9c33-eff856105dad',NULL,'{\"id\": \"b3c86ef5-5019-4349-9c33-eff856105dad\", \"name\": \"Sub-E2E-1779158869137\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:47:49.181'),('3b65d2bb-b8e7-4f43-ac4c-49630f3ebb72',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-15 03:45:41.916'),('3d5a8979-11cb-4120-b910-5a38dbf4abd9','d48bd81b-3172-4687-8327-f6f743dac72d','8d93fc6c-f486-49a9-9849-b58bc9201167','TREE_CREATED','Tree','d48bd81b-3172-4687-8327-f6f743dac72d',NULL,'{\"id\": \"d48bd81b-3172-4687-8327-f6f743dac72d\", \"name\": \"Academia de IA Test\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 14:03:01.452'),('3da43b20-72b7-4d45-8217-d2de767615ec',NULL,'14f24111-6c3d-4ddc-9669-73d0d3703cd0','USER_LOGIN_SUCCESS','User','14f24111-6c3d-4ddc-9669-73d0d3703cd0',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:26:42.696'),('3e7d8c86-1194-43a7-a421-6b18e3ada2da',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 19:08:19.130'),('3ef2c5cb-55ec-4322-8744-3ebe514a0e76',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_FAILED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:18:56.000'),('3f7607d8-1705-4c5a-95b2-3ae67d4ae6c1',NULL,'ari','TREE_CREATED','Tree','cd4b675f-3ac5-450d-b2d3-3d5e067de1aa',NULL,'{\"id\": \"cd4b675f-3ac5-450d-b2d3-3d5e067de1aa\", \"name\": \"Sub-E2E-1779158982155\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:49:42.190'),('40e2a115-b638-4957-8734-6138d67b25c4',NULL,'66c04512-b98e-48ef-b5ac-14386e21f0b8','TREE_CREATED','Tree','945b1c38-084d-4751-a0bd-482a5a8dab79',NULL,'{\"id\": \"945b1c38-084d-4751-a0bd-482a5a8dab79\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:50:31.365'),('40f86117-4304-4955-b4c9-5f8b0e43c92c',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','TOKEN_REFRESHED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/refresh\", \"method\": \"POST\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 22:39:29.391'),('4233e11c-207c-4abd-89b5-df37ef54726c','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_WRITE','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:57:34.822'),('424edaba-79fe-449e-b4b4-78ee15328e99',NULL,'ari','TREE_CREATED','Tree','110fb8e4-4e00-43bb-b5f1-10d76d9165ad',NULL,'{\"id\": \"110fb8e4-4e00-43bb-b5f1-10d76d9165ad\", \"name\": \"Raíz-E2E-1779159487216\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:58:07.321'),('4265a9e9-3614-4092-81c5-a5e4ba9b0adb',NULL,'ari','SUBTREE_CREATED','Tree','e295ab9f-f0c0-47e3-893f-a66f8c11d54d',NULL,'{\"id\": \"e295ab9f-f0c0-47e3-893f-a66f8c11d54d\", \"name\": \"Sub-API-E2E-1779167082072\", \"parentTreeId\": \"f5648ec2-eb99-4183-af35-e61a11c82249\"}','{\"route\": \"/api/trees/f5648ec2-eb99-4183-af35-e61a11c82249/subtree\", \"method\": \"POST\", \"result\": \"success\", \"parentTreeId\": \"f5648ec2-eb99-4183-af35-e61a11c82249\"}','127.0.0.1','node','INFO','USER','2026-05-19 05:04:42.117'),('4266e5c4-b986-41d8-9a0e-f5c475dd702b',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_REGISTERED','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,'{\"id\": \"caf27a62-1a0f-4615-9e18-c07d43813883\", \"role\": \"USER\", \"email\": \"test@exttask.dev\", \"username\": \"exttask_tester\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:34:51.120'),('429c9800-b5cc-4e7c-b87e-a038677853d9',NULL,'4c3108db-7d9e-4443-8f3a-6dac1d17be9b','USER_REGISTERED','User','4c3108db-7d9e-4443-8f3a-6dac1d17be9b',NULL,'{\"id\": \"4c3108db-7d9e-4443-8f3a-6dac1d17be9b\", \"role\": \"USER\", \"email\": \"testhist@test.com\", \"username\": \"testhist\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:28:14.655'),('42fb8c23-b139-475b-bd82-ba571f0ea45c',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 16:46:55.944'),('4353741b-d8b3-457f-a6f2-e84ee7572488',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:27:16.160'),('435d6d11-23e4-45b1-81c7-95c1d19e684c',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_SUCCESS','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:19:25.516'),('44405b75-76f7-4000-a599-725dced9dac8',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','TOKEN_REFRESHED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/refresh\", \"method\": \"POST\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 22:18:46.159'),('4449fe72-fa3f-43c0-9d10-dfe4810eaa51',NULL,'ebf76fd4-281d-4ca6-ac52-0035556c259e','TREE_CREATED','Tree','9839a956-f6a8-4c22-ae90-291b3374c129',NULL,'{\"id\": \"9839a956-f6a8-4c22-ae90-291b3374c129\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:26:27.764'),('445f178e-86b7-4ea8-a639-bfc9f12b67be','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_WRITE','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:40:48.152'),('4554a992-d197-4fa7-84bf-5cb6ff565fb5','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"bitcoin price\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:55:50.538'),('45b1dfed-956f-4e5e-817d-021a9affefae','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:15:03.592'),('45e95f65-63c0-427f-a01e-551d322620a6',NULL,'ca933a62-0228-412c-be01-9cfe4262c2d6','TREE_CREATED','Tree','96a4b4dc-a19a-4d72-a221-fb6d4d492e14',NULL,'{\"id\": \"96a4b4dc-a19a-4d72-a221-fb6d4d492e14\", \"name\": \"SQL Iso Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:36:57.478'),('45f05115-51b1-494a-b332-b98f56b379ee',NULL,'7ec54910-cfc2-41b7-96e8-beea4f1017f9','TREE_CREATED','Tree','03f9f6cd-ba4e-41f9-9518-87b2327348fd',NULL,'{\"id\": \"03f9f6cd-ba4e-41f9-9518-87b2327348fd\", \"name\": \"CrossTree Test B 1779198488133\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 13:48:08.214'),('46a14be0-0e5d-4b93-a6ea-6596ac3705d4',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','WARNING','USER','2026-05-13 18:44:21.165'),('46b009d7-6ce1-4167-aa17-23d4f5dd385c',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_LOGIN_SUCCESS','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:42:36.113'),('46e5a4b3-844a-49ba-bc05-c5dd3ac83081','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_READ','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:40:48.167'),('4716e430-2cc3-428d-874b-de388f7de3f2',NULL,'ari','TREE_INTERACTION_MODE_CHANGED','Tree','92aff236-5a8c-406f-8d61-dbf5def34213','{\"interactionMode\": \"MAXIMUM\"}','{\"interactionMode\": \"MEDIUM\"}',NULL,'127.0.0.1','node','INFO','USER','2026-05-19 04:30:35.129'),('477382e3-b825-452a-b478-26b1575bfca4',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:22:21.605'),('478d6d20-0d23-43ca-95d7-77127c864889','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_READ','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:56:29.000'),('480f2ba9-a734-4872-b78e-1f8739163279','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:13:25.682'),('48332d52-813c-44f0-b280-afc460b98ee7',NULL,'926fb090-82c5-4774-89cc-038682fd8994','USER_REGISTERED','User','926fb090-82c5-4774-89cc-038682fd8994',NULL,'{\"id\": \"926fb090-82c5-4774-89cc-038682fd8994\", \"role\": \"USER\", \"email\": \"byo2@test.com\", \"username\": \"byotest2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 16:47:17.921'),('48a75a8f-3f9f-4929-9d95-bf3721aa8c85',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:51:53.293'),('48a77b49-3a18-4ea4-b2bd-cd4e024d3384','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_READ','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:57:34.837'),('49301ce1-c7d4-4cbc-bcc1-f976d06cf58b',NULL,'86ab07ff-5932-46ea-ad89-a742815d4e8d','TREE_CREATED','Tree','1895d9c9-5468-4cc7-86f2-511fd75b3cae',NULL,'{\"id\": \"1895d9c9-5468-4cc7-86f2-511fd75b3cae\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:21:17.881'),('493190fe-1f04-4eb5-a29a-4729bbe24471',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:42:00.339'),('49f9dda0-2869-4183-950f-bf54af87b9ac',NULL,'4cc9f888-516f-4847-94af-41ce5a1635e4','USER_LOGIN_SUCCESS','User','4cc9f888-516f-4847-94af-41ce5a1635e4',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:42:36.460'),('4a35c766-eec5-43bf-b433-21d9f72815d3',NULL,'a017be03-4b21-4477-992d-0da855531b8e','USER_LOGIN_SUCCESS','User','a017be03-4b21-4477-992d-0da855531b8e',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:23:49.709'),('4a93bd5c-366b-48cd-8a2b-1dd1c18b8339',NULL,'3f174e8e-5d21-434b-9705-68413394d778','TREE_CREATED','Tree','3c9dac17-5f06-4680-93b3-20e62b983cf0',NULL,'{\"id\": \"3c9dac17-5f06-4680-93b3-20e62b983cf0\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:25:18.558'),('4ab5e193-e1a9-4b6e-a637-0969817e9621',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-18 15:34:37.396'),('4b58032e-e6e6-480b-bdfc-2c085906d6d2',NULL,'134b2149-eadc-4e83-ade4-a1b1c4af9cce','USER_LOGIN_FAILED','User','134b2149-eadc-4e83-ade4-a1b1c4af9cce',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:34:31.667'),('4b68b351-9c89-4ab7-98e8-9ebd7d432d8e',NULL,'6fe69220-33e9-4c86-8e5d-b8ba924c5962','USER_LOGIN_SUCCESS','User','6fe69220-33e9-4c86-8e5d-b8ba924c5962',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 19:29:07.568'),('4c5c9461-b6da-4810-bdfd-70f31e2f0b2f',NULL,'86ab07ff-5932-46ea-ad89-a742815d4e8d','TREE_CREATED','Tree','959004a0-425e-4259-9d12-40b676291d37',NULL,'{\"id\": \"959004a0-425e-4259-9d12-40b676291d37\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:21:17.944'),('4e186c6d-b58b-4e58-9021-c643dd5ff642',NULL,'ari','TREE_CREATED','Tree','c8f98c30-4e66-4264-97e0-825058b45a3c',NULL,'{\"id\": \"c8f98c30-4e66-4264-97e0-825058b45a3c\", \"name\": \"E2E-Modes-1779164851056\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 04:27:31.157'),('4e521ac3-f0da-4fd9-98ae-66c01e94a4a1',NULL,'ebf76fd4-281d-4ca6-ac52-0035556c259e','TREE_CREATED','Tree','57b17562-2500-4b95-bc91-10506703f590',NULL,'{\"id\": \"57b17562-2500-4b95-bc91-10506703f590\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:26:27.718'),('4eb53ce6-727a-42ab-8cb7-bd2e148af9b1',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 16:39:54.657'),('4ee756f3-d104-4f86-8dee-1545aa516f81',NULL,'befd8a78-6838-4401-8fec-8c387188c4b2','USER_REGISTERED','User','befd8a78-6838-4401-8fec-8c387188c4b2',NULL,'{\"id\": \"befd8a78-6838-4401-8fec-8c387188c4b2\", \"role\": \"PERSON\", \"email\": \"test5028@test.com\", \"username\": \"test5028\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:38:29.239'),('4f0a91fc-ab87-48da-b916-77f3721b16d0',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-16 17:22:10.073'),('4f86395f-e2fd-4f45-af52-0951339783cf',NULL,'e0712bee-a5e5-4a4e-b8f3-41b115d8bda9','USER_REGISTERED','User','e0712bee-a5e5-4a4e-b8f3-41b115d8bda9',NULL,'{\"id\": \"e0712bee-a5e5-4a4e-b8f3-41b115d8bda9\", \"role\": \"USER\", \"email\": \"surveytest_admin_1779200698796@test.com\", \"username\": \"surveytest_admin_1779200698796\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:24:59.138'),('4fac72b1-855a-4278-be3a-d24562469ee0','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_LAZY_INIT','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"file\": \"[REDACTED]\"}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:40:48.038'),('510b59db-2dd6-4ec8-ad9c-de20cf78fb61',NULL,'a02529a7-ff2f-4189-8651-16af77d6646b','USER_REGISTERED','User','a02529a7-ff2f-4189-8651-16af77d6646b',NULL,'{\"id\": \"a02529a7-ff2f-4189-8651-16af77d6646b\", \"role\": \"USER\", \"email\": null, \"username\": \"test_ssh_admin2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-15 05:00:26.316'),('51142a30-4ea3-428f-af0b-a1819ac95629','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 0}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:52:21.130'),('51627c62-943d-4c8c-960d-01f294f240a6',NULL,NULL,'USER_LOGIN_SUCCESS','User','0451d945-17f8-4628-9e16-c0d8a1542a04',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:26:52.313'),('520098f9-099a-40df-bac2-5615c40fcf4a',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_LOGIN_SUCCESS','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:36:36.689'),('52182f83-5d17-4013-a9a5-0d66cb1f0b7a',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 11:56:07.969'),('52981ee3-48ed-49f0-a392-0d8c015c1dea',NULL,'a017be03-4b21-4477-992d-0da855531b8e','USER_LOGIN_SUCCESS','User','a017be03-4b21-4477-992d-0da855531b8e',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:25:22.134'),('52b684f4-59e8-4fa3-86fc-6c35e1a8f1a9',NULL,NULL,'USER_LOGIN_SUCCESS','User','0451d945-17f8-4628-9e16-c0d8a1542a04',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:22:18.312'),('52cfea97-2292-465d-8a5c-0adfb94a6d6c',NULL,'3ab38cbb-8bbb-4515-a3ef-198cb6abfa23','USER_REGISTERED','User','3ab38cbb-8bbb-4515-a3ef-198cb6abfa23',NULL,'{\"id\": \"3ab38cbb-8bbb-4515-a3ef-198cb6abfa23\", \"role\": \"USER\", \"email\": null, \"username\": \"e2e_70757\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-15 05:02:23.315'),('53f02e83-0c1e-4fd4-9242-41c3f374d2ed',NULL,'3f174e8e-5d21-434b-9705-68413394d778','USER_REGISTERED','User','3f174e8e-5d21-434b-9705-68413394d778',NULL,'{\"id\": \"3f174e8e-5d21-434b-9705-68413394d778\", \"role\": \"USER\", \"email\": \"sandboxtest_1778851515793@test.com\", \"username\": \"sandboxtest_1778851515793\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:25:16.111'),('556693f9-2c64-451e-8ba0-e1067d391406',NULL,'4e230f5d-4b16-4082-b504-309106a90d34','USER_REGISTERED','User','4e230f5d-4b16-4082-b504-309106a90d34',NULL,'{\"id\": \"4e230f5d-4b16-4082-b504-309106a90d34\", \"role\": \"PERSON\", \"email\": \"roletester3@test.com\", \"username\": \"roletester3\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:28:30.067'),('55deeff6-3654-4297-987b-3d3d924013e7','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"x\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:59:11.481'),('5672a6ea-13fb-4a75-a42c-9c616e1618cf',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 14:34:01.700'),('57bd0045-0679-4805-a6ee-70a22a96a89b','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 0}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:54:49.652'),('583e5215-43fc-4de2-bcf3-8d8130c0e41e',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 00:26:36.439'),('58546de8-eba6-464b-b3a2-be8e5dd56ab9',NULL,'f31cf403-afa7-4b2f-917a-9692b50063cc','USER_REGISTERED','User','f31cf403-afa7-4b2f-917a-9692b50063cc',NULL,'{\"id\": \"f31cf403-afa7-4b2f-917a-9692b50063cc\", \"role\": \"USER\", \"email\": \"testhist3@test.com\", \"username\": \"testhist3\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:28:44.581'),('594f9633-4120-4754-9f73-fe198c277fb4','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_READ','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:40:48.244'),('59bf9998-51e4-49a5-b549-7c4373c6c39a',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_FAILED','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 00:57:32.870'),('5a8edcab-5e20-4156-9a49-c7bca0c92445',NULL,'1533fbac-698c-42d7-a161-75f3434020f9','USER_REGISTERED','User','1533fbac-698c-42d7-a161-75f3434020f9',NULL,'{\"id\": \"1533fbac-698c-42d7-a161-75f3434020f9\", \"role\": \"USER\", \"email\": null, \"username\": \"concierge_58696\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-15 05:03:29.535'),('5b13c5f0-bf0b-45e9-9213-69be15d4b530',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:49:50.622'),('5b1727f3-27c4-42d3-b3ca-3548dddc52e3',NULL,'ari','TREE_CREATED','Tree','0136eb27-ce60-4693-b630-102b1315e09d',NULL,'{\"id\": \"0136eb27-ce60-4693-b630-102b1315e09d\", \"name\": \"Padre-E2E-1779167450343\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 1}','127.0.0.1','node','INFO','USER','2026-05-19 05:10:50.433'),('5bfcbeaf-6611-44bd-b529-f7157935dda6',NULL,'5d47ff7a-b727-4fef-88bc-a04469384b5c','TREE_CREATED','Tree','d4561308-7111-4d7a-9e76-13e10c7d884d',NULL,'{\"id\": \"d4561308-7111-4d7a-9e76-13e10c7d884d\", \"name\": \"SQL Iso Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:42:16.492'),('5c60b835-1798-4538-8599-02f36460dde1',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_FAILED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 16:38:28.886'),('5c921b11-d010-4dab-97ad-a103f71f234d',NULL,'befd8a78-6838-4401-8fec-8c387188c4b2','TOOL_RECOMMENDATION_GENERATED','GroupTool','recommendation',NULL,NULL,'{\"groupType\": \"albañiles\", \"fixedCount\": 0, \"poolAmount\": 50, \"totalTools\": 2, \"catalogSize\": 3}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:38:29.760'),('5dd1d182-06f9-410e-bc95-963ffe9e1960',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 13:13:37.055'),('5ff8e0bb-28ec-4d7b-befc-689b8460c5f4',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:27:59.834'),('6089fdd3-500d-4ff5-9f80-2fd51bb4a643',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_FAILED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:18:55.195'),('625b7319-498a-4ef9-a862-fd9ff85d9224',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 13:13:30.077'),('62cefca0-8680-46e6-ba9c-2f25b202f8b6',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:13:43.079'),('631364e9-35f9-4b25-a8ca-36c36e29a387',NULL,'9e44ddf5-bb54-4697-be45-e1a8f92b219e','TREE_CREATED','Tree','e29db5d5-35ac-40c3-8039-0464338f896a',NULL,'{\"id\": \"e29db5d5-35ac-40c3-8039-0464338f896a\", \"name\": \"SurveyTest Tree 1779200734070\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:25:34.115'),('63d37d21-7089-472d-a164-2dde4141843b',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-20 15:22:07.339'),('655982af-1dc8-410f-a13c-617b375cb0d8',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 09:43:57.206'),('65e23a15-e44a-4ecc-8a59-44cfa6fe67d2',NULL,'ari','TREE_CREATED','Tree','52ad3089-1ae2-421d-b20b-a1c67edb78a1',NULL,'{\"id\": \"52ad3089-1ae2-421d-b20b-a1c67edb78a1\", \"name\": \"Raíz-E2E-1779159566069\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:59:26.158'),('65ec8b34-15f6-4fdb-a959-e229aa6cb989',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:51:18.441'),('65f9ae53-aec6-4c1e-8a3b-3adcd8f8fe4c',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_FAILED','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-20 15:22:07.513'),('660382b2-4fdf-4d31-aeb5-72fb5051d866',NULL,'f8be3975-34fb-422f-8746-2ebb436330b4','USER_REGISTERED','User','f8be3975-34fb-422f-8746-2ebb436330b4',NULL,'{\"id\": \"f8be3975-34fb-422f-8746-2ebb436330b4\", \"role\": \"USER\", \"email\": \"n6test@integration.test\", \"username\": \"n6test\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 09:44:12.838'),('663991ba-a324-4617-98bd-6508083fc23a',NULL,NULL,'USER_LOGIN_SUCCESS','User','0154b3d6-5b86-4d0f-8ed3-37c1bbb576c9',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 16:46:55.972'),('66afdc01-ab48-457c-8ea4-04269e6b167e','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"test\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:56:17.256'),('66d39549-870b-4d06-9179-91eea915ca0f',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_SUCCESS','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:31:44.528'),('66fe1ad4-161b-4b0c-9afb-ff1ae403c667',NULL,'7a3a01ae-7dcb-445d-942f-9996de05ddad','TREE_CREATED','Tree','3b514a31-8740-4b6b-9a5d-0f5e44e2f8a1',NULL,'{\"id\": \"3b514a31-8740-4b6b-9a5d-0f5e44e2f8a1\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 14:25:02.954'),('67190874-a5e2-42cb-8112-52be516c1bf7',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:27:16.175'),('68220c48-cb62-44b9-8c6f-28e50bed6018',NULL,'86ab07ff-5932-46ea-ad89-a742815d4e8d','USER_REGISTERED','User','86ab07ff-5932-46ea-ad89-a742815d4e8d',NULL,'{\"id\": \"86ab07ff-5932-46ea-ad89-a742815d4e8d\", \"role\": \"USER\", \"email\": \"sandboxtest_1778851276872@test.com\", \"username\": \"sandboxtest_1778851276872\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:21:17.180'),('6877163d-9eb3-4032-993c-3737fb58a88c',NULL,'cf27b711-0b6b-4bb5-a9e0-bf3aab44971c','USER_REGISTERED','User','cf27b711-0b6b-4bb5-a9e0-bf3aab44971c',NULL,'{\"id\": \"cf27b711-0b6b-4bb5-a9e0-bf3aab44971c\", \"role\": \"ADMIN\", \"email\": \"test_social@test.com\", \"username\": \"testuser_social\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 15:48:21.298'),('693212a8-424c-4291-96b3-3238ab9dedad','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WRITE','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:36:24.269'),('693a5207-a707-4d08-8512-6bf4ad91eff8',NULL,'4cc9f888-516f-4847-94af-41ce5a1635e4','USER_REGISTERED','User','4cc9f888-516f-4847-94af-41ce5a1635e4',NULL,'{\"id\": \"4cc9f888-516f-4847-94af-41ce5a1635e4\", \"role\": \"USER\", \"email\": \"worker@test.dev\", \"username\": \"worker_person\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:35:43.833'),('6940d182-baf4-43fd-94c3-b385465bb349',NULL,'ari','TREE_CREATED','Tree','5b46187d-2b6e-48b2-8c12-41ca1e025b62',NULL,'{\"id\": \"5b46187d-2b6e-48b2-8c12-41ca1e025b62\", \"name\": \"Raíz-E2E-1779159089130\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:51:29.220'),('6a441c5e-ce59-463b-b43e-1eb4fd0e2884',NULL,'752a5c35-8903-4fd4-95bf-f790b8ddb292','USER_REGISTERED','User','752a5c35-8903-4fd4-95bf-f790b8ddb292',NULL,'{\"id\": \"752a5c35-8903-4fd4-95bf-f790b8ddb292\", \"role\": \"USER\", \"email\": \"testhist4@test.com\", \"username\": \"testhist4\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:29:02.550'),('6a8db508-4e38-463b-bd10-cca17a5b9d72',NULL,NULL,'USER_REGISTERED','User','e4dc4169-31f1-491b-815f-c51a1e96842a',NULL,'{\"id\": \"e4dc4169-31f1-491b-815f-c51a1e96842a\", \"role\": \"USER\", \"email\": \"isolated@test.com\", \"username\": \"isolated_test\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:28:19.022'),('6ad90ba1-6ea7-4777-a484-0db17f710d69',NULL,'9e44ddf5-bb54-4697-be45-e1a8f92b219e','USER_REGISTERED','User','9e44ddf5-bb54-4697-be45-e1a8f92b219e',NULL,'{\"id\": \"9e44ddf5-bb54-4697-be45-e1a8f92b219e\", \"role\": \"USER\", \"email\": \"surveytest_admin_1779200733734@test.com\", \"username\": \"surveytest_admin_1779200733734\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:25:34.065'),('6b011fd9-1ffe-4228-a0a6-f70b10d96117',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-20 15:22:07.518'),('6b37115f-f6a3-4134-b0d2-502a1af9ea8c',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:21:52.528'),('6b72f9d7-1083-4f09-8d65-bfdeb61ed568','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_READ','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:36:38.846'),('6cb6e6ca-2f1f-4337-ac9a-67db26ed4f41','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'TRIGGER_COMMENT_REVIEW','Tree','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"chatId\": \"-5154581921\", \"messageId\": 1079}','127.0.0.1','curl/8.5.0','INFO','AUTOMATION','2026-05-20 15:57:35.755'),('6cf66f26-0a95-4dc3-b137-f7d1f235e98d',NULL,'6fe69220-33e9-4c86-8e5d-b8ba924c5962','USER_LOGIN_SUCCESS','User','6fe69220-33e9-4c86-8e5d-b8ba924c5962',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 19:28:00.769'),('6e8e20e5-a6e4-43d8-abb8-aa5c94af1a80',NULL,'78f7d145-ab6f-48f5-a836-c93a2c02fd52','USER_REGISTERED','User','78f7d145-ab6f-48f5-a836-c93a2c02fd52',NULL,'{\"id\": \"78f7d145-ab6f-48f5-a836-c93a2c02fd52\", \"role\": \"USER\", \"email\": \"schema@test.com\", \"username\": \"schematest\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 18:47:26.809'),('6f41d5d4-6230-4f11-83c8-68b8cb00436b',NULL,'a017be03-4b21-4477-992d-0da855531b8e','USER_LOGIN_SUCCESS','User','a017be03-4b21-4477-992d-0da855531b8e',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:22:54.738'),('6f89d79c-1f07-4a68-8127-22532747c0f6',NULL,'ari','SUBTREE_CREATED','Tree','79c73464-7913-44a3-a360-1049af71e989',NULL,'{\"id\": \"79c73464-7913-44a3-a360-1049af71e989\", \"name\": \"Sub-API-E2E-1779167545948\", \"parentTreeId\": \"ab464de8-7ee5-4eb5-b53c-280c7cbb0a51\"}','{\"route\": \"/api/trees/ab464de8-7ee5-4eb5-b53c-280c7cbb0a51/subtree\", \"method\": \"POST\", \"result\": \"success\", \"parentTreeId\": \"ab464de8-7ee5-4eb5-b53c-280c7cbb0a51\"}','127.0.0.1','node','INFO','USER','2026-05-19 05:12:26.032'),('6fd6242d-6840-41b1-9a33-15052458c1e6',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-15 04:57:03.768'),('705d96cf-13e0-4088-8a9f-a42870f42c3d','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_WRITE','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:35:49.202'),('70a0c695-69e7-4ec2-b28c-67e236ca7424',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 00:27:50.771'),('70f37822-b5fa-4801-8b2f-c47bf325d71e',NULL,'892980d6-a579-4912-9763-f058203bc362','USER_REGISTERED','User','892980d6-a579-4912-9763-f058203bc362',NULL,'{\"id\": \"892980d6-a579-4912-9763-f058203bc362\", \"role\": \"USER\", \"email\": \"exttask2@test.dev\", \"username\": \"exttask2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:35:19.034'),('7175f0e3-0a16-4496-b785-87075edb22ea','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 0}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:54:49.635'),('721b5b05-db61-4336-8f96-040cde2a2a92','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_WRITE','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:57:34.896'),('734fe17d-6bfa-4ef9-b364-b0f0245ee15b',NULL,'ari','TREE_CREATED','Tree','960d1c47-965e-4ecf-80a5-01762fd0edfb',NULL,'{\"id\": \"960d1c47-965e-4ecf-80a5-01762fd0edfb\", \"name\": \"Raíz-E2E-1779159826591\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 03:03:46.689'),('738baeef-7fdb-4c51-89a5-405de433ac28',NULL,'14f24111-6c3d-4ddc-9669-73d0d3703cd0','USER_REGISTERED','User','14f24111-6c3d-4ddc-9669-73d0d3703cd0',NULL,'{\"id\": \"14f24111-6c3d-4ddc-9669-73d0d3703cd0\", \"role\": \"USER\", \"email\": \"tester2@test.com\", \"username\": \"tester2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:16:55.864'),('73a62f10-0dda-4043-8551-9c94505db218',NULL,'68907da8-6eca-41aa-affa-e4710435daff','TREE_CREATED','Tree','b2f4f2e3-8514-4b6a-bcbf-388aa1510f2b',NULL,'{\"id\": \"b2f4f2e3-8514-4b6a-bcbf-388aa1510f2b\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:42:42.774'),('74792678-b37d-4445-a1c1-7dfd9f5908b1','677544eb-4a02-457b-b0fe-933f37277158','1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','TREE_CREATED','Tree','677544eb-4a02-457b-b0fe-933f37277158',NULL,'{\"id\": \"677544eb-4a02-457b-b0fe-933f37277158\", \"name\": \"N6 Final Test\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 11:37:22.571'),('74882632-18e9-4059-8657-cead0a352899',NULL,'a017be03-4b21-4477-992d-0da855531b8e','USER_LOGIN_SUCCESS','User','a017be03-4b21-4477-992d-0da855531b8e',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:24:39.892'),('7622080f-7281-48ae-b17a-2c3f936d6fd7',NULL,'86a75cdd-221c-4ce0-8f07-7da08e21fdfb','TOOL_RECOMMENDATION_GENERATED','GroupTool','recommendation',NULL,NULL,'{\"groupType\": \"construction\", \"infraType\": \"cloud\", \"fixedCount\": 1, \"poolAmount\": 60, \"totalTools\": 8, \"catalogSize\": 13, \"hasServerEstimate\": true}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:48:04.968'),('76daf306-935f-458f-a91e-e66a20c26bd2',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 14:01:23.503'),('77f86205-e599-4a9f-8900-6d9d6561edfb',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 14:00:48.829'),('7833aef4-8e34-4dd8-80a8-6461e9b7fa47',NULL,'698ca1b3-8f97-4156-bb79-88f0869781ca','TREE_CREATED','Tree','4bce0efc-e179-4328-8cf7-a187e5249c43',NULL,'{\"id\": \"4bce0efc-e179-4328-8cf7-a187e5249c43\", \"name\": \"SQL Iso Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:38:13.275'),('7864cfd3-8a8a-4d76-9724-7eeb08a7c55b',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','WARNING','USER','2026-05-13 18:44:06.743'),('7889ab39-24c7-4ee0-ae78-c40550444e13',NULL,NULL,'USER_REGISTERED','User','051dda42-2061-45dc-bd72-f745d3bdbda8',NULL,'{\"id\": \"051dda42-2061-45dc-bd72-f745d3bdbda8\", \"role\": \"USER\", \"email\": \"hermes@trustmaker.local\", \"username\": \"HermesAgent\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 15:21:02.828'),('79259639-f3a2-42f5-bf8b-2416305f82b9',NULL,'0a08c64a-3126-4492-8e00-9c4f44f43086','TREE_CREATED','Tree','23703657-db3a-4c11-b2a1-b8163de1c0ae',NULL,'{\"id\": \"23703657-db3a-4c11-b2a1-b8163de1c0ae\", \"name\": \"SQL Iso Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:31:37.619'),('79839dd9-6910-4be2-ba68-2a2d49d35821',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_SUCCESS','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 22:46:22.538'),('79e6cdc0-b1a4-439c-a87d-f7dd30112cf0',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_SUCCESS','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:19:05.051'),('7a73ec16-1e0c-46f9-95d3-74072d7c81a8',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 00:22:12.257'),('7b8f7630-20c9-4e38-ab86-22d484ae074a',NULL,'c5d7f4f1-afbe-4cc7-aa67-81c82485d2a2','USER_REGISTERED','User','c5d7f4f1-afbe-4cc7-aa67-81c82485d2a2',NULL,'{\"id\": \"c5d7f4f1-afbe-4cc7-aa67-81c82485d2a2\", \"role\": \"USER\", \"email\": \"testhermes@demo.local\", \"username\": \"testhermes\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 14:34:19.446'),('7b91c33b-5da7-4edf-a4b1-32a07f0ffcd4',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_SUCCESS','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:21:53.148'),('7bb05b94-b6a1-4f04-919a-d669664c198c',NULL,'14f24111-6c3d-4ddc-9669-73d0d3703cd0','USER_LOGIN_SUCCESS','User','14f24111-6c3d-4ddc-9669-73d0d3703cd0',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:20:11.366'),('7c9967bd-50a7-410f-9550-c1257c2075a9',NULL,'ari','TREE_CREATED','Tree','34c61779-82ee-4825-a312-87d406f26123',NULL,'{\"id\": \"34c61779-82ee-4825-a312-87d406f26123\", \"name\": \"TestChild\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 02:55:58.037'),('7ca8ca76-b059-47ba-85fd-ea5293e58182',NULL,'4ba12ced-0fad-4aeb-af79-490873802100','TREE_CREATED','Tree','f13d3ab3-3d30-41f7-bd61-2c003076c577',NULL,'{\"id\": \"f13d3ab3-3d30-41f7-bd61-2c003076c577\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-17 17:14:10.202'),('7cb28a5e-3fdc-426c-84c0-40d0d86c1d50',NULL,'a017be03-4b21-4477-992d-0da855531b8e','USER_LOGIN_SUCCESS','User','a017be03-4b21-4477-992d-0da855531b8e',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:25:45.017'),('7cc66774-5c13-4f4e-8de8-4be7b6ff3c60',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_SUCCESS','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:26:42.559'),('7d79ad77-6423-423c-bbd4-66dbdd60ecf5',NULL,'ari','TREE_CREATED','Tree','ecaa3d3a-0889-4ab3-aad4-3a7669bcad01',NULL,'{\"id\": \"ecaa3d3a-0889-4ab3-aad4-3a7669bcad01\", \"name\": \"E2E Test 1779132222750\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 2}','127.0.0.1','node','INFO','USER','2026-05-18 19:23:42.861'),('7eac1d2b-67da-4269-98f0-0ce918c4a14f','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:28:45.814'),('7fa5a362-799b-4293-ab57-381c3307788b',NULL,NULL,'USER_LOGIN_SUCCESS','User','5e5cdf70-f348-424a-9391-b7f936f91374',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:18:53.775'),('7ff1e4ca-476c-4302-8d46-2948e16291e1',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:28:38.267'),('80c5080f-1928-4fe9-a25b-1a5a6a62547e',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-15 00:40:03.555'),('82b5a2e1-3082-4ad4-86b4-e47ff1aa5047',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_SUCCESS','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:20:11.052'),('82f8d447-ed2a-4639-a2ee-0188a4289a3b',NULL,'ae90dc20-de65-4e66-95aa-376767826016','USER_REGISTERED','User','ae90dc20-de65-4e66-95aa-376767826016',NULL,'{\"id\": \"ae90dc20-de65-4e66-95aa-376767826016\", \"role\": \"USER\", \"email\": \"sandboxtest_1778784098837@test.com\", \"username\": \"sandboxtest_1778784098837\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:41:39.054'),('82ff532e-4296-4cae-b09b-f377e156605f',NULL,'7d7465e7-e3b8-4f85-8e01-40b2d958392a','USER_REGISTERED','User','7d7465e7-e3b8-4f85-8e01-40b2d958392a',NULL,'{\"id\": \"7d7465e7-e3b8-4f85-8e01-40b2d958392a\", \"role\": \"PERSON\", \"email\": \"roletest@trust.com\", \"username\": \"roletest\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:40:11.255'),('83373f2b-0232-46a2-b408-ba70c6972a87',NULL,'ari','TREE_CREATED','Tree','cb247615-8728-4b42-8f41-1e0d1bfeaea9',NULL,'{\"id\": \"cb247615-8728-4b42-8f41-1e0d1bfeaea9\", \"name\": \"Raíz-E2E-1779158807865\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:46:47.972'),('836fb9ec-cc48-451a-a7fd-4fb1e3207e89',NULL,'3f174e8e-5d21-434b-9705-68413394d778','SANDBOX_DELETED','TreeSandbox','e12a032b-0eae-4497-8ced-a24798b4445e',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:25:16.718'),('837be8d3-2951-4aa0-8195-9bbab40e3946','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 16:19:30.976'),('83833880-20bc-470a-af4d-547fb796f668',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:27:43.249'),('8396227a-3441-4080-ba71-714927b02b25','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_WRITE','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:35:48.861'),('83e7aa38-fb63-42fa-b80e-39b35a67c0dc',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_FAILED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','WARNING','USER','2026-05-13 21:54:56.058'),('85521874-d9e7-4909-8c74-3c6232d862d1',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-20 15:22:07.328'),('85685af3-d4da-4f29-955a-427a00e1cc05',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:23:24.560'),('856efc3d-1dcc-431b-9637-8457f43c126d',NULL,'ari','TREE_CREATED','Tree','aa704be6-a2df-40b8-99a8-8dc672732400',NULL,'{\"id\": \"aa704be6-a2df-40b8-99a8-8dc672732400\", \"name\": \"Hijo-E2E-1779166283666\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 04:51:23.729'),('8603a805-9aa5-4da9-b89d-5c34990257a8',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:59:26.539'),('874c6ab7-dedc-4591-addf-c19a6866d565',NULL,'6fe69220-33e9-4c86-8e5d-b8ba924c5962','INVESTMENT_MATCH_PROPOSED','InvestmentMatch','10690cc4-4f56-4ddc-9e0f-8b697c844ffd',NULL,NULL,'{\"route\": \"/api/investment/matches\", \"amount\": 5000000, \"method\": \"POST\", \"seekerTreeId\": \"17ab49ab-3d5e-4d43-9a6c-b838ec35e81d\", \"investmentType\": \"REVENUE_SHARE\", \"investorTreeId\": \"29f356ce-826f-49a9-ab46-f477cd2d68e9\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 19:29:08.399'),('87b45fc3-e107-42ff-9349-2796606b0940',NULL,'8f9a3896-671e-4a44-826c-253829bbebd9','USER_LOGIN_SUCCESS','User','8f9a3896-671e-4a44-826c-253829bbebd9',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:41:30.639'),('87ffab70-d6cd-4787-a497-54bafe100e45','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"x\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:59:11.162'),('88ae6aca-21b7-43be-9d1e-1c2bd0311234',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-15 00:31:59.624'),('8a196805-8b7b-4e1e-a133-ddcaf41d3975',NULL,'3f174e8e-5d21-434b-9705-68413394d778','TREE_CREATED','Tree','da4c28f8-09d6-4fed-a7cd-c40e84c6dd7d',NULL,'{\"id\": \"da4c28f8-09d6-4fed-a7cd-c40e84c6dd7d\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:25:16.805'),('8ac9a142-939d-4a2d-8b8e-de4ab01ae825','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:43:18.475'),('8b18deff-d894-49a7-99a3-a6f1b86d144a','71e3319c-a60b-45bd-afb9-d2b767977dfe','f8be3975-34fb-422f-8746-2ebb436330b4','TREE_CREATED','Tree','71e3319c-a60b-45bd-afb9-d2b767977dfe',NULL,'{\"id\": \"71e3319c-a60b-45bd-afb9-d2b767977dfe\", \"name\": \"N6 Verify Delete\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees/\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 09:51:32.854'),('8b3f5fc2-67e6-43b0-b5c8-b1cb86e8fe01',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 11:22:13.210'),('8f890dc1-2d61-403d-a0c3-4a0352e3fab3',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 13:01:48.746'),('8fae94ed-2905-460e-904b-c6324e236c99',NULL,'68907da8-6eca-41aa-affa-e4710435daff','TREE_CREATED','Tree','e8be6611-0d24-454f-8255-848273a2083f',NULL,'{\"id\": \"e8be6611-0d24-454f-8255-848273a2083f\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:42:44.596'),('8fc8b566-ce0a-4e7b-9610-959f720fe438',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:18:55.428'),('9111d6f5-ad6c-4369-afa1-55576225569c',NULL,'ca933a62-0228-412c-be01-9cfe4262c2d6','TREE_CREATED','Tree','89382879-8e91-4967-974e-94944d987a26',NULL,'{\"id\": \"89382879-8e91-4967-974e-94944d987a26\", \"name\": \"SQL Iso Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:36:57.407'),('916ecdb8-ce97-41de-9c6e-5c798036748d',NULL,NULL,'USER_REGISTERED','User','56ce4886-a44d-4465-bf61-4bd2cb763bbc',NULL,'{\"id\": \"56ce4886-a44d-4465-bf61-4bd2cb763bbc\", \"role\": \"USER\", \"email\": \"chat@test.com\", \"username\": \"test_ci_chat\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:26:44.223'),('91c74282-31f0-42b0-942c-88c4668ae996',NULL,'66c04512-b98e-48ef-b5ac-14386e21f0b8','USER_REGISTERED','User','66c04512-b98e-48ef-b5ac-14386e21f0b8',NULL,'{\"id\": \"66c04512-b98e-48ef-b5ac-14386e21f0b8\", \"role\": \"USER\", \"email\": \"sandboxtest_1778784630464@test.com\", \"username\": \"sandboxtest_1778784630464\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:50:30.680'),('91eb2cce-a966-480b-be32-be922821029f','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_READ','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:40:48.056'),('920fed57-57fe-49ff-9602-5fab00e94e74',NULL,NULL,'USER_LOGIN_SUCCESS','User','7b446ec1-1f1b-4efa-b2e3-c218632abc69',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:19:42.579'),('947f199a-008d-4af5-a519-2c73af788959',NULL,NULL,'CONCIERGE_SUGGEST_TEST','ConciergeSuggestion',NULL,NULL,NULL,'{\"type\": \"test\", \"source\": \"trustmaker-context-watch\", \"message\": \"test\", \"priority\": \"low\", \"createdAt\": \"2026-05-16T09:56:26.400Z\"}',NULL,NULL,'INFO','AUTOMATION','2026-05-16 09:56:26.432'),('94e7a2e5-8c1c-4343-9623-e0fb691f8114','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"bitcoin price 2026\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:54:11.438'),('951e5596-ec5f-4e12-a1bd-d4a568086c11',NULL,'723d908a-75b6-40ff-89c0-e7272f514afb','USER_REGISTERED','User','723d908a-75b6-40ff-89c0-e7272f514afb',NULL,'{\"id\": \"723d908a-75b6-40ff-89c0-e7272f514afb\", \"role\": \"USER\", \"email\": \"surveyvoter_2_1779200699441@test.com\", \"username\": \"surveyvoter_2_1779200699441\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:24:59.624'),('96cc3099-461f-4ca0-a49f-9ef30a8d185c',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_SUCCESS','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:12:29.172'),('96f63565-394f-4d5d-bae6-da7b6acfeaef','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:51:49.405'),('9702c5ea-d733-475b-8aeb-98dce6dc7e29',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 09:05:40.950'),('970efdf3-faf7-4376-af8a-aa24eb23e888',NULL,'ari','TREE_CREATED','Tree','5b146f86-082a-46e5-bab8-8dbe9e14d4c6',NULL,'{\"id\": \"5b146f86-082a-46e5-bab8-8dbe9e14d4c6\", \"name\": \"Padre-E2E-1779165820854\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 1}','127.0.0.1','node','INFO','USER','2026-05-19 04:43:40.974'),('97dedf47-fa7b-4112-bbd1-7adaefd5b473','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'TRIGGER_COMMENT_REVIEW','Tree','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"chatId\": \"-5154581921\", \"messageId\": 1076}','127.0.0.1','curl/8.5.0','INFO','AUTOMATION','2026-05-20 15:40:49.105'),('98a491bb-7c4b-4834-b036-d470871b5a67',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_SUCCESS','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:22:30.950'),('98a4cf2d-e635-453b-b5fa-9e90f8c315b1','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"x\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:59:11.368'),('999838d9-543b-493d-9639-181e31da6872',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_LOGIN_SUCCESS','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:36:01.651'),('99cf0207-5903-427a-b5b9-8191a976f3cd',NULL,'942125f0-2e1c-4c4c-a382-ebfb63f17f3d','TREE_CREATED','Tree','3512d26d-bf4e-4e1d-8451-d396a5181cb5',NULL,'{\"id\": \"3512d26d-bf4e-4e1d-8451-d396a5181cb5\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 11:41:59.384'),('9a5afec8-1a37-4e41-981f-83ae73effca0',NULL,'66c04512-b98e-48ef-b5ac-14386e21f0b8','TREE_CREATED','Tree','e88b55ea-a7db-42dc-8834-08558fc75c36',NULL,'{\"id\": \"e88b55ea-a7db-42dc-8834-08558fc75c36\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:50:31.427'),('9adb8f29-c8bb-46fd-a85b-c0aaacc57010',NULL,'ari','TREE_CREATED','Tree','f5648ec2-eb99-4183-af35-e61a11c82249',NULL,'{\"id\": \"f5648ec2-eb99-4183-af35-e61a11c82249\", \"name\": \"Padre-E2E-1779167081704\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 1}','127.0.0.1','node','INFO','USER','2026-05-19 05:04:41.830'),('9b78c336-64c5-41d1-b46b-d52b73b5c8e5',NULL,'ari','TREE_CREATED','Tree','271ded3c-d1a1-42e4-a74e-e60ad7c148d5',NULL,'{\"id\": \"271ded3c-d1a1-42e4-a74e-e60ad7c148d5\", \"name\": \"Raíz-E2E-1779158869043\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:47:49.127'),('9cca2a58-72fa-47e7-b49b-4d8747d94d4f',NULL,'ari','TREE_CREATED','Tree','0b006a51-ac31-4172-bc4f-db46ed47a083',NULL,'{\"id\": \"0b006a51-ac31-4172-bc4f-db46ed47a083\", \"name\": \"Hijo-E2E-1779167081839\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 05:04:41.901'),('9d64900f-664d-4c83-b249-fb583d1e8c11',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 16:47:17.453'),('9ea22a07-bae4-4f73-8dfd-d6562e33f6d3',NULL,'86ab07ff-5932-46ea-ad89-a742815d4e8d','TREE_CREATED','Tree','9682fc07-1ed7-4b63-aa5d-1383e15a552b',NULL,'{\"id\": \"9682fc07-1ed7-4b63-aa5d-1383e15a552b\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:21:19.738'),('9f48930d-cd6b-4838-8477-f0de87004ef4',NULL,'7a3a01ae-7dcb-445d-942f-9996de05ddad','TREE_CREATED','Tree','2930977a-0fd1-4f72-8261-de70ff736b42',NULL,'{\"id\": \"2930977a-0fd1-4f72-8261-de70ff736b42\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 14:25:02.264'),('a01b6d30-21b8-4ade-a970-5d57a914a56d',NULL,'942125f0-2e1c-4c4c-a382-ebfb63f17f3d','TREE_CREATED','Tree','8690140b-bf7c-4b50-95af-6d4306d175db',NULL,'{\"id\": \"8690140b-bf7c-4b50-95af-6d4306d175db\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 11:41:59.957'),('a1f90217-b618-43fd-afbe-684624b34543',NULL,'2621936f-70cb-43f6-8ef0-5a8244383d5a','USER_REGISTERED','User','2621936f-70cb-43f6-8ef0-5a8244383d5a',NULL,'{\"id\": \"2621936f-70cb-43f6-8ef0-5a8244383d5a\", \"role\": \"PERSON\", \"email\": \"finaltest9@test.com\", \"username\": \"finaltest9\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:55:20.032'),('a2b5bb13-9ca0-47d8-a93b-4dd4f2b1a8f0',NULL,'ari','TREE_CREATED','Tree','3a574d7c-e586-485a-b349-a761d7b566d7',NULL,'{\"id\": \"3a574d7c-e586-485a-b349-a761d7b566d7\", \"name\": \"Hijo-E2E-1779167545761\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 05:12:25.813'),('a2f59293-d3ec-49a2-b12c-71241b74b916','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_WRITE','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:14:15.735'),('a311cb58-fec7-4665-975d-b27eb3a7503f',NULL,'614b8f42-4e90-4331-9cf9-2a0bb6589e16','USER_REGISTERED','User','614b8f42-4e90-4331-9cf9-2a0bb6589e16',NULL,'{\"id\": \"614b8f42-4e90-4331-9cf9-2a0bb6589e16\", \"role\": \"PERSON\", \"email\": \"infratest3@test.com\", \"username\": \"infratest3\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:47:28.730'),('a36997f2-f9ac-4541-af5f-39cea9efdc6e',NULL,'ari','TREE_CREATED','Tree','51f76b60-606a-48c8-b364-d601c6c69fe1',NULL,'{\"id\": \"51f76b60-606a-48c8-b364-d601c6c69fe1\", \"name\": \"Padre-E2E-1779166568576\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 1}','127.0.0.1','node','INFO','USER','2026-05-19 04:56:08.673'),('a3e4dbf2-14a2-4c36-a18e-4bcc50b02165',NULL,'3218c868-514d-4327-87fc-e1afaec8ce72','USER_REGISTERED','User','3218c868-514d-4327-87fc-e1afaec8ce72',NULL,'{\"id\": \"3218c868-514d-4327-87fc-e1afaec8ce72\", \"role\": \"PERSON\", \"email\": \"treetestx@test.com\", \"username\": \"treetestX\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:55:32.813'),('a41b2921-d0f4-4c1e-8f9a-0084b7e1c52b','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:32:44.077'),('a42f3a73-5317-4040-b7a7-62466a01505c',NULL,'7a3a01ae-7dcb-445d-942f-9996de05ddad','TREE_CREATED','Tree','251f70b6-709b-4086-b064-b1ba2a78af57',NULL,'{\"id\": \"251f70b6-709b-4086-b064-b1ba2a78af57\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 14:25:04.958'),('a63b613b-70c7-4675-9080-19962c650fa1',NULL,'ebf76fd4-281d-4ca6-ac52-0035556c259e','SANDBOX_DELETED','TreeSandbox','dd5c8954-adee-4e97-a9dd-a30c2696af9e',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:26:27.663'),('a6769bdf-31f9-4905-9913-39f6b2fd56b7',NULL,NULL,'USER_LOGIN_SUCCESS','User','5e5cdf70-f348-424a-9391-b7f936f91374',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:20:01.650'),('a6a25723-3580-4c20-ada7-686bb5380c21',NULL,NULL,'USER_LOGIN_SUCCESS','User','0451d945-17f8-4628-9e16-c0d8a1542a04',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:27:31.843'),('a7bab76e-1222-4484-8bc5-bb56397c0f95',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 00:28:14.842'),('a848232e-e684-4440-9171-5a49e0b669a5','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:28:02.476'),('a892206a-9f3a-4328-8d28-46f24c6d5bc6',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:51:40.044'),('a8ed4990-de42-4e76-abfb-bf74db061200','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_READ','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:57:34.911'),('a9298770-adff-4a66-8142-20dc858bee10','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:43:42.655'),('a94fdee6-4c7d-41ee-bded-ef853d1b3d4c',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:40:31.898'),('aa1edc7c-9c50-4bda-aa78-824c93f5a47b','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_LIST','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:33:26.349'),('aa6fa884-8bc2-4fb5-9bc2-ebcd67fa41b3',NULL,'0b121a5e-9b0f-4ed7-9cef-95200af8ec44','TOOL_RECOMMENDATION_GENERATED','GroupTool','recommendation',NULL,NULL,'{\"groupType\": \"albañiles\", \"fixedCount\": 0, \"poolAmount\": 50, \"totalTools\": 2, \"catalogSize\": 3}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:38:44.360'),('abb4b4f7-ce7b-4fec-9057-d1a09404bdde',NULL,'2b39885b-7421-4e3a-848b-58c4c9372279','USER_REGISTERED','User','2b39885b-7421-4e3a-848b-58c4c9372279',NULL,'{\"id\": \"2b39885b-7421-4e3a-848b-58c4c9372279\", \"role\": \"PERSON\", \"email\": \"invtest2@test.com\", \"username\": \"invtest2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:21:22.467'),('adf6dab5-6738-4f30-b267-3d403d3af0ef',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_FAILED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:18:41.809'),('af0a134f-1457-4321-8624-fb98b1c79095',NULL,'4cc9f888-516f-4847-94af-41ce5a1635e4','USER_LOGIN_SUCCESS','User','4cc9f888-516f-4847-94af-41ce5a1635e4',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:39:47.285'),('af4b92d4-2105-4e9d-b072-3fd8ae3aaeca',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_SUCCESS','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:16:56.171'),('b0b7f105-abb6-44cb-b16e-2c22dff012c4',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:38:44.711'),('b0d5f009-2d4a-48ce-96c9-fef2a9dc3d7b','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:28:45.776'),('b117931e-2f3b-4021-a997-1311e649ee73',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-14 11:29:46.239'),('b163536d-82ff-431f-98b7-bf68acdacc6c',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','USER_LOGIN_SUCCESS','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 22:03:36.735'),('b17257a9-1f18-4b91-92dd-f3d965900daa',NULL,'4cc9f888-516f-4847-94af-41ce5a1635e4','USER_LOGIN_SUCCESS','User','4cc9f888-516f-4847-94af-41ce5a1635e4',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:42:59.501'),('b3768930-2444-43e3-a65e-5b9c14c210cb',NULL,'ari','TREE_CREATED','Tree','1fb4e383-22f0-4c5b-96f4-3415577d6796',NULL,'{\"id\": \"1fb4e383-22f0-4c5b-96f4-3415577d6796\", \"name\": \"Sub-E2E-1779159089230\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:51:29.292'),('b3788651-207d-45f4-b146-9cd4fb51fa53',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-15 05:00:08.494'),('b39aa123-4d25-4c90-a7d4-19e5b6b3e981',NULL,'ari','TREE_INTERACTION_MODE_CHANGED','Tree','92aff236-5a8c-406f-8d61-dbf5def34213','{\"interactionMode\": \"MEDIUM\"}','{\"interactionMode\": \"MINIMUM\"}',NULL,'127.0.0.1','node','INFO','USER','2026-05-19 04:30:35.225'),('b41695fe-5e0e-4c19-add0-a27b3b8f5908',NULL,'22972369-0833-45d6-a5c6-37d7157061d0','USER_REGISTERED','User','22972369-0833-45d6-a5c6-37d7157061d0',NULL,'{\"id\": \"22972369-0833-45d6-a5c6-37d7157061d0\", \"role\": \"USER\", \"email\": \"testhist2@test.com\", \"username\": \"testhist2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-14 00:28:30.556'),('b450801d-12fc-45ff-80aa-91c572be6d45',NULL,'66c04512-b98e-48ef-b5ac-14386e21f0b8','SANDBOX_DELETED','TreeSandbox','3d2e9fc8-e95a-4eb8-9b00-b9129aca30d2',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:50:31.295'),('b4a4afc1-461f-4d40-a8c9-eff87f974568',NULL,'ari','TREE_CREATED','Tree','cc53a92e-8ec0-4877-a58e-10da1a272834',NULL,'{\"id\": \"cc53a92e-8ec0-4877-a58e-10da1a272834\", \"name\": \"Padre-E2E-1779166283523\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 1}','127.0.0.1','node','INFO','USER','2026-05-19 04:51:23.656'),('b4c98fdf-e8bb-4e0a-aaba-13df4407dcbc',NULL,'5d47ff7a-b727-4fef-88bc-a04469384b5c','TREE_CREATED','Tree','d367e64e-2663-4636-952b-8e61674069c3',NULL,'{\"id\": \"d367e64e-2663-4636-952b-8e61674069c3\", \"name\": \"SQL Iso Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:42:16.658'),('b56c55fc-1dac-4d77-b1fc-0cc198e40d2b',NULL,'0a93ae63-b3ec-435e-9700-1324132b047c','USER_REGISTERED','User','0a93ae63-b3ec-435e-9700-1324132b047c',NULL,'{\"id\": \"0a93ae63-b3ec-435e-9700-1324132b047c\", \"role\": \"USER\", \"email\": \"crosstree_1779198287839@test.com\", \"username\": \"crosstree_1779198287839\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 13:44:48.269'),('b5ddf8da-8511-485d-9f4c-fb1eb3d40084',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 15:48:37.027'),('b649e1fe-3569-468b-a9f1-68e9d589f2e5',NULL,'ari','TREE_CREATED','Tree','2db35669-9de9-4840-8ab4-5011ee848c65',NULL,'{\"id\": \"2db35669-9de9-4840-8ab4-5011ee848c65\", \"name\": \"Sub-E2E-1779159487331\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:58:07.399'),('b6658ba1-cf29-40ea-965c-7b69793f390f',NULL,NULL,'SANDBOX_EXEC','TreeSandbox','2fd56af7-6e89-4640-92ef-1c7f574ce90a',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 16:19:31.008'),('b760c415-87ad-43fc-8656-961e9d3e0432',NULL,'ari','TREE_CREATED','Tree','92aff236-5a8c-406f-8d61-dbf5def34213',NULL,'{\"id\": \"92aff236-5a8c-406f-8d61-dbf5def34213\", \"name\": \"E2E-Modes-1779165034464\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 04:30:34.898'),('b7b77404-0a94-4a87-b748-49967516852f',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.0.0 Safari/537.36','INFO','USER','2026-05-13 14:18:09.868'),('b8202c21-40d7-466d-87ba-d0ecaa86e8b3',NULL,'8d93fc6c-f486-49a9-9849-b58bc9201167','USER_REGISTERED','User','8d93fc6c-f486-49a9-9849-b58bc9201167',NULL,'{\"id\": \"8d93fc6c-f486-49a9-9849-b58bc9201167\", \"role\": \"USER\", \"email\": \"integration@test.com\", \"username\": \"integration_test\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 14:02:13.093'),('b897bf9e-fe82-4347-9365-2f6328db44d4',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:22:08.595'),('b8d75d34-6fb5-48e1-a8a1-2de37f35e747',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:33:57.445'),('b92d92d4-235a-49eb-8703-5b0a39c1f82a',NULL,'4ba12ced-0fad-4aeb-af79-490873802100','SANDBOX_DELETED','TreeSandbox','ce443b14-6a5e-4d18-a433-40134b56ef91',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-17 17:14:08.194'),('bb75678e-f72b-449d-bf3f-74e4d43e6cdc',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:21:02.627'),('bb92155c-99d8-442e-bc90-247c094181cc','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:43:42.673'),('bbbb2a6c-4b02-44b9-9d56-3e7bc4314cab',NULL,'cea7d32a-a582-4ecc-9988-72fa0d0e6e6c','USER_REGISTERED','User','cea7d32a-a582-4ecc-9988-72fa0d0e6e6c',NULL,'{\"id\": \"cea7d32a-a582-4ecc-9988-72fa0d0e6e6c\", \"role\": \"USER\", \"email\": \"testsocial@test.com\", \"username\": \"testsocial\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1',NULL,'INFO','USER','2026-05-16 15:57:53.890'),('bc630696-c981-4fef-bac4-9bc6b338bcc0',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 13:23:04.615'),('bdad3cce-873d-43b3-bd2d-4edcd1652fe7',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_SUCCESS','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:02:00.361'),('bdbc901a-b30b-4aae-848a-3372ff59d4b2',NULL,'7a3a01ae-7dcb-445d-942f-9996de05ddad','TREE_CREATED','Tree','4e9cf255-73ed-488c-94b9-04109a39db82',NULL,'{\"id\": \"4e9cf255-73ed-488c-94b9-04109a39db82\", \"name\": \"Sandbox Test Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 14:25:03.109'),('be3945d2-fd61-4f32-b40e-8ef95c48c8bb',NULL,NULL,'USER_LOGIN_SUCCESS','User','3bb695ea-3074-42fa-b206-3857c65890df',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 14:37:13.877'),('be39c9b5-6f60-4cbd-a483-b09c2629c397',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 13:13:14.027'),('be53d740-c97f-4a61-a22d-75b182114e26',NULL,'68907da8-6eca-41aa-affa-e4710435daff','USER_REGISTERED','User','68907da8-6eca-41aa-affa-e4710435daff',NULL,'{\"id\": \"68907da8-6eca-41aa-affa-e4710435daff\", \"role\": \"USER\", \"email\": \"sandboxtest_1778784161666@test.com\", \"username\": \"sandboxtest_1778784161666\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:42:42.034'),('bec984e3-19e2-45ab-af8c-602d79c9dc70',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-15 00:29:40.500'),('bf08bf76-df07-427d-b026-fc45df8bfe47',NULL,'471a81d1-2a9b-4fdf-8f30-116178eaf85b','USER_LOGIN_SUCCESS','User','471a81d1-2a9b-4fdf-8f30-116178eaf85b',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:31:11.080'),('c0874603-da34-440e-be27-467ef40d307a',NULL,NULL,'USER_LOGIN_SUCCESS','User','5e5cdf70-f348-424a-9391-b7f936f91374',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:16:59.112'),('c1b53436-2963-440e-8178-46f7d1137936','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'TRIGGER_COMMENT_REVIEW','Tree','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"chatId\": \"-5274848173\", \"messageId\": 1077}','127.0.0.1','curl/8.5.0','INFO','AUTOMATION','2026-05-20 15:55:57.038'),('c25ce9a6-21a2-4ba7-877d-1eeb0db436b0',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_REGISTERED','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,'{\"id\": \"379a2d98-460e-4c0c-a3d5-fc70bb541ca1\", \"role\": \"USER\", \"email\": \"tester1@test.com\", \"username\": \"tester1\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:16:27.013'),('c2f7be9e-b83e-493d-9be7-06ed8d97c4f1',NULL,'6fb42ad9-11d5-443a-8ab9-4915ea5da9c3','USER_REGISTERED','User','6fb42ad9-11d5-443a-8ab9-4915ea5da9c3',NULL,'{\"id\": \"6fb42ad9-11d5-443a-8ab9-4915ea5da9c3\", \"role\": \"PERSON\", \"email\": \"verifyz@test.com\", \"username\": \"verifyZ\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:56:00.917'),('c3dd5fe7-ac66-4630-9f5a-7a1b30e2bb4a',NULL,'18c35f7a-ac4d-4939-bc31-688b95eabf3c','USER_REGISTERED','User','18c35f7a-ac4d-4939-bc31-688b95eabf3c',NULL,'{\"id\": \"18c35f7a-ac4d-4939-bc31-688b95eabf3c\", \"role\": \"USER\", \"email\": \"test_h@test.com\", \"username\": \"test_hierarchy\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-15 00:16:08.760'),('c4030195-dfd7-46e7-9f71-3fd4b123c75a',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 15:48:12.897'),('c485bf1d-6833-4aa1-820c-4c213cf4a2fa','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:16:44.935'),('c65661fa-6b2d-492f-a0f9-5115bac96e3f','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_WRITE','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:35:47.849'),('c6636fed-03fa-4fcc-9378-702638afac11',NULL,'ari','TREE_CREATED','Tree','ab464de8-7ee5-4eb5-b53c-280c7cbb0a51',NULL,'{\"id\": \"ab464de8-7ee5-4eb5-b53c-280c7cbb0a51\", \"name\": \"Padre-E2E-1779167545598\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 1}','127.0.0.1','node','INFO','USER','2026-05-19 05:12:25.713'),('c6948cdd-8573-48b0-8c50-9939feb486b1',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','WARNING','USER','2026-05-13 13:58:46.425'),('c7347be6-41b7-4a6d-a662-65c2daa22ee4',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_LOGIN_SUCCESS','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:42:59.157'),('c7ce9ce2-4518-4f86-898f-e4369d18606d',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 12:50:34.606'),('c8097333-4af3-48b1-9396-b01a48e088d5',NULL,'87809908-5136-4782-bb91-421b58281ad2','USER_REGISTERED','User','87809908-5136-4782-bb91-421b58281ad2',NULL,'{\"id\": \"87809908-5136-4782-bb91-421b58281ad2\", \"role\": \"USER\", \"email\": \"byo@test.com\", \"username\": \"byotest\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 16:46:56.385'),('c9738228-7c0d-4569-b1e5-ca03f60ac1b4',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:27:38.563'),('ca0c66cd-ff7a-4184-b1d2-ee9cd544359d',NULL,'14f24111-6c3d-4ddc-9669-73d0d3703cd0','USER_LOGIN_SUCCESS','User','14f24111-6c3d-4ddc-9669-73d0d3703cd0',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:22:31.104'),('ca8f67e2-23f8-443f-a011-4cde967ef052','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"x\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:59:11.268'),('cae2f602-ec8c-4b2f-840f-8834fbd4658d','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_READ','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:33:54.062'),('cb29ba3e-9615-43a6-9dfc-fbee0f6047dd',NULL,'7a3a01ae-7dcb-445d-942f-9996de05ddad','TREE_CREATED','Tree','cb9f011f-1de2-45bb-8c53-77a5c544f1a1',NULL,'{\"id\": \"cb9f011f-1de2-45bb-8c53-77a5c544f1a1\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 14:25:04.347'),('cc177671-9f64-4d94-9743-3ec03daf3273',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 18:46:50.193'),('ccd3108d-da16-46d0-849a-854ea0c2bd09',NULL,'8f9a3896-671e-4a44-826c-253829bbebd9','USER_REGISTERED','User','8f9a3896-671e-4a44-826c-253829bbebd9',NULL,'{\"id\": \"8f9a3896-671e-4a44-826c-253829bbebd9\", \"role\": \"PERSON\", \"email\": \"roletest2@trust.com\", \"username\": \"roletest2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:41:13.149'),('cd6e88ed-6fea-418d-912c-bdbb10eb0453',NULL,'ari','TREE_CREATED','Tree','642cb713-a0a8-4135-8f05-1ffe3a3b4b99',NULL,'{\"id\": \"642cb713-a0a8-4135-8f05-1ffe3a3b4b99\", \"name\": \"Sub-E2E-1779158807984\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:46:48.036'),('cd9b39fd-3f43-4d77-aa93-d974616d0ac3',NULL,'698ca1b3-8f97-4156-bb79-88f0869781ca','USER_REGISTERED','User','698ca1b3-8f97-4156-bb79-88f0869781ca',NULL,'{\"id\": \"698ca1b3-8f97-4156-bb79-88f0869781ca\", \"role\": \"USER\", \"email\": \"sqliso_1779201492838@test.com\", \"username\": \"sqliso_1779201492838\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:38:13.162'),('cdb3a9d0-04bc-47fb-89fb-da5a020e55eb',NULL,'942125f0-2e1c-4c4c-a382-ebfb63f17f3d','TREE_CREATED','Tree','597d34de-0da6-41df-a953-77150af8f55d',NULL,'{\"id\": \"597d34de-0da6-41df-a953-77150af8f55d\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 11:41:58.021'),('ce4ede66-01d6-4b48-956d-3518e9f23ca5',NULL,NULL,'USER_LOGIN_SUCCESS','User','051dda42-2061-45dc-bd72-f745d3bdbda8',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 15:29:16.555'),('cf8398d8-ff48-4a1c-a6cf-f83fbfb14fb5',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:28:24.651'),('d07b68fd-326d-4cb8-bd75-43ba9ee0f9fd',NULL,'ari','TREE_CREATED','Tree','9fb2ad0c-8d1c-4d64-81e2-b7c4bf4d3459',NULL,'{\"id\": \"9fb2ad0c-8d1c-4d64-81e2-b7c4bf4d3459\", \"name\": \"Sub-E2E-1779159566168\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 02:59:26.219'),('d08d3411-f1b3-40b8-9618-838bbe8745d4','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:28:02.455'),('d0bd4982-ad87-4eee-95ba-6406df2d9646',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:42:37.014'),('d13fb470-830a-40f4-bc6c-ab6a4cb9001b',NULL,'942125f0-2e1c-4c4c-a382-ebfb63f17f3d','USER_REGISTERED','User','942125f0-2e1c-4c4c-a382-ebfb63f17f3d',NULL,'{\"id\": \"942125f0-2e1c-4c4c-a382-ebfb63f17f3d\", \"role\": \"USER\", \"email\": \"sandboxtest_1778845317109@test.com\", \"username\": \"sandboxtest_1778845317109\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 11:41:57.309'),('d1929b2a-7a35-46bf-88a3-88ecd0d5a49e',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-19 14:01:22.708'),('d1e8c384-7260-4eee-a3e9-3b7628b64980',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:18:56.494'),('d25946a0-0801-4ddd-94a9-af72ea7e3267','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:28:45.797'),('d2d3a21f-4ad4-462e-bbc8-50557d0be52d',NULL,NULL,'USER_LOGIN_SUCCESS','User','530e9dd9-c32d-4a2c-9b81-2eac2ba28167',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 13:14:04.522'),('d2f2c8e1-7b96-43ab-87ac-67398eb01473',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 14:34:09.788'),('d3cfda71-52bb-433f-a3ee-228ed229040d',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','WARNING','USER','2026-05-13 13:58:37.835'),('d401ddc6-c15b-4609-8368-00dce088d011',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-13 13:10:51.555'),('d5759ee2-c60b-42f0-981d-eb2a2196617e','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_WEB_SEARCH','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"query\": \"bitcoin price 2026\", \"resultCount\": 0}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-19 17:58:54.947'),('d58c477f-a161-4919-8a05-f50e3ff76567',NULL,NULL,'USER_REGISTERED','User','598054cb-dc80-45b7-85fd-a9739e6c1acd',NULL,'{\"id\": \"598054cb-dc80-45b7-85fd-a9739e6c1acd\", \"role\": \"USER\", \"email\": \"test-ideas@demo.com\", \"username\": \"testideas\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:11:10.758'),('d5d01124-084f-45f4-a6d0-edeaf32bdb20',NULL,'abead984-c09c-4fba-8460-0f0537b2dea1','USER_REGISTERED','User','abead984-c09c-4fba-8460-0f0537b2dea1',NULL,'{\"id\": \"abead984-c09c-4fba-8460-0f0537b2dea1\", \"role\": \"USER\", \"email\": \"surveyvoter_3_1779200699636@test.com\", \"username\": \"surveyvoter_3_1779200699636\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:24:59.804'),('d5f7cf80-48f7-4914-91d9-3f5812f602db','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_READ','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-19 16:56:29.007'),('d73547e1-3e37-4929-bad4-116d54aee86e',NULL,'a017be03-4b21-4477-992d-0da855531b8e','USER_REGISTERED','User','a017be03-4b21-4477-992d-0da855531b8e',NULL,'{\"id\": \"a017be03-4b21-4477-992d-0da855531b8e\", \"role\": \"PERSON\", \"email\": \"investest@test.com\", \"username\": \"investest\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:21:04.581'),('d7454157-2a9f-461d-b1c5-1b1ae174f85a','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_WRITE','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:35:48.179'),('d771b130-8e14-4a4c-b557-9760f682ee2f',NULL,'6fe69220-33e9-4c86-8e5d-b8ba924c5962','USER_LOGIN_SUCCESS','User','6fe69220-33e9-4c86-8e5d-b8ba924c5962',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 18:55:45.666'),('d879a67b-5fed-4273-a4ce-b4eb981deb83',NULL,'cf27b711-0b6b-4bb5-a9e0-bf3aab44971c','USER_LOGIN_SUCCESS','User','cf27b711-0b6b-4bb5-a9e0-bf3aab44971c',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-16 15:55:16.611'),('d8b31519-6b39-49cf-8947-b00ae6c0c827',NULL,'68907da8-6eca-41aa-affa-e4710435daff','SANDBOX_DELETED','TreeSandbox','3bec632f-d6ff-420f-ad68-e5abe47b524c',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:42:42.673'),('d8e34a84-b6fb-4004-84fb-8130e0a9ab6c',NULL,'4ba12ced-0fad-4aeb-af79-490873802100','TREE_CREATED','Tree','a4c8b356-c3a4-41be-80a5-86f414c20d81',NULL,'{\"id\": \"a4c8b356-c3a4-41be-80a5-86f414c20d81\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-17 17:14:08.265'),('d9064eff-7143-4504-a04e-fcd580dfea51',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_LOGIN_SUCCESS','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:39:46.818'),('d9176202-6512-4772-b12d-acd067b4f92a',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 16:39:41.708'),('d93671c3-d9db-46a0-b3c7-7abbc0980b97',NULL,'c94d5e30-c52e-453c-b80d-8ff3f329cbf9','USER_REGISTERED','User','c94d5e30-c52e-453c-b80d-8ff3f329cbf9',NULL,'{\"id\": \"c94d5e30-c52e-453c-b80d-8ff3f329cbf9\", \"role\": \"USER\", \"email\": \"schema2@test.com\", \"username\": \"schematest2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 18:47:39.032'),('d97730b6-3395-4f8c-a882-f7f2a0f9dc5d',NULL,'71564219-1f09-457e-8b41-ef328da7fd80','USER_REGISTERED','User','71564219-1f09-457e-8b41-ef328da7fd80',NULL,'{\"id\": \"71564219-1f09-457e-8b41-ef328da7fd80\", \"role\": \"USER\", \"email\": \"structadm@test.com\", \"username\": \"structadm\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 19:08:34.443'),('d991a680-7383-4103-9fc3-cc1c5b7ed626',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:27:40.654'),('da54db24-1943-4b03-9d9c-2f8466f27c97',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:39:02.012'),('db0df480-084f-4120-9666-fe26d4eb39c9','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:54:49.616'),('dd8a131a-aa4e-48a0-a391-932668f3f9ad',NULL,'86ab07ff-5932-46ea-ad89-a742815d4e8d','SANDBOX_DELETED','TreeSandbox','be982170-e43b-40e0-8fc3-573a8ecb2b34',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:21:17.821'),('ddce0b6f-11fa-4754-a9c4-69efd930e535',NULL,'14f24111-6c3d-4ddc-9669-73d0d3703cd0','USER_LOGIN_SUCCESS','User','14f24111-6c3d-4ddc-9669-73d0d3703cd0',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:20:11.217'),('de218b93-e0f5-4810-806b-79bd0b74d79b','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:44:04.235'),('deb8e392-3299-4e56-9e32-3a4d8d82628f',NULL,NULL,'USER_LOGIN_SUCCESS','User','0451d945-17f8-4628-9e16-c0d8a1542a04',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 15:21:33.591'),('dfb92535-d124-4007-9585-a3559995d1b1',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_FAILED','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"invalid_password\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:22:10.071'),('e04822b1-7b59-42ef-9d40-5d52189c5291',NULL,'e7d16ca7-0f65-412c-9e35-0ddd44c3d218','USER_REGISTERED','User','e7d16ca7-0f65-412c-9e35-0ddd44c3d218',NULL,'{\"id\": \"e7d16ca7-0f65-412c-9e35-0ddd44c3d218\", \"role\": \"USER\", \"email\": \"surveyvoter_1_1779200699209@test.com\", \"username\": \"surveyvoter_1_1779200699209\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:24:59.411'),('e0ebe6dc-47bd-4ab8-a3f9-f62324aa0448','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:14:35.380'),('e10b8e0b-d2b5-4dd0-8a62-317f2577e247',NULL,'4ba12ced-0fad-4aeb-af79-490873802100','USER_REGISTERED','User','4ba12ced-0fad-4aeb-af79-490873802100',NULL,'{\"id\": \"4ba12ced-0fad-4aeb-af79-490873802100\", \"role\": \"USER\", \"email\": \"sandboxtest_1779038047208@test.com\", \"username\": \"sandboxtest_1779038047208\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-17 17:14:07.509'),('e27026ef-2c2c-4631-98b5-d0cff406604c',NULL,'ari','TREE_CREATED','Tree','7f71975e-7332-4de1-9bcb-eaca7e11e62f',NULL,'{\"id\": \"7f71975e-7332-4de1-9bcb-eaca7e11e62f\", \"name\": \"E2E Test 1779132476451\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 2}','127.0.0.1','node','INFO','USER','2026-05-18 19:27:56.554'),('e2a1543a-f15a-45f2-a46a-c3f97aff2772',NULL,'942125f0-2e1c-4c4c-a382-ebfb63f17f3d','SANDBOX_DELETED','TreeSandbox','cc01e186-a9ec-4b02-a03f-af4cdd19432a',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 11:41:57.975'),('e3cfaae2-026d-4a81-a8ed-e7200f0ec45b',NULL,'7ec54910-cfc2-41b7-96e8-beea4f1017f9','TREE_CREATED','Tree','0ccdc7b5-c0f1-4fc9-ae7a-c59b9ca7f427',NULL,'{\"id\": \"0ccdc7b5-c0f1-4fc9-ae7a-c59b9ca7f427\", \"name\": \"CrossTree Test A 1779198488055\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 13:48:08.119'),('e45f1bf0-ccb8-4ae7-9ebc-d2e957ee6a9e','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'TRIGGER_COMMENT_REVIEW','Tree','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"chatId\": \"-5274848173\", \"messageId\": 1078}','127.0.0.1','curl/8.5.0','INFO','AUTOMATION','2026-05-20 15:57:35.335'),('e70b20ea-71c0-4c9d-8afd-ad09680076ae',NULL,'6835f00a-c875-4a23-bf8d-5273a381c21f','USER_REGISTERED','User','6835f00a-c875-4a23-bf8d-5273a381c21f',NULL,'{\"id\": \"6835f00a-c875-4a23-bf8d-5273a381c21f\", \"role\": \"USER\", \"email\": null, \"username\": \"ssh_test_4172\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-15 05:01:27.294'),('e75bfdf0-1a76-41c2-9e57-7528bd4a006d',NULL,'3f174e8e-5d21-434b-9705-68413394d778','TREE_CREATED','Tree','9e390595-94cd-4598-afcf-c768d8ae0644',NULL,'{\"id\": \"9e390595-94cd-4598-afcf-c768d8ae0644\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:25:16.761'),('e7ad2324-84c8-482c-940f-d220d36f7ad5',NULL,'86ab07ff-5932-46ea-ad89-a742815d4e8d','TREE_CREATED','Tree','ee264570-b77d-4001-a84a-e096232454f4',NULL,'{\"id\": \"ee264570-b77d-4001-a84a-e096232454f4\", \"name\": \"Sandbox Test Tree C\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:21:19.134'),('e7ecf77b-4b31-459c-9ae8-14e8b853b2e2','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_WRITE','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 15:40:48.228'),('e7fd179e-0628-4333-acb4-484637c4f29f',NULL,'457bd5da-9edc-4217-90f9-93e7a320f455','USER_REGISTERED','User','457bd5da-9edc-4217-90f9-93e7a320f455',NULL,'{\"id\": \"457bd5da-9edc-4217-90f9-93e7a320f455\", \"role\": \"USER\", \"email\": \"structure@test.com\", \"username\": \"structuretest\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 19:08:19.596'),('e8f639d1-960d-4cf0-8fc5-cc82e37f7bf2',NULL,'ebf76fd4-281d-4ca6-ac52-0035556c259e','USER_REGISTERED','User','ebf76fd4-281d-4ca6-ac52-0035556c259e',NULL,'{\"id\": \"ebf76fd4-281d-4ca6-ac52-0035556c259e\", \"role\": \"USER\", \"email\": \"sandboxtest_1778851586754@test.com\", \"username\": \"sandboxtest_1778851586754\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 13:26:27.045'),('e9109196-0ccd-40c6-99b2-9b190cf644f3','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:51:49.384'),('e940fd35-cb95-4a31-a427-ac58b19cecdf',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','TOKEN_REFRESHED','User','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2',NULL,NULL,'{\"route\": \"/api/auth/refresh\", \"method\": \"POST\"}','127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','INFO','USER','2026-05-13 19:10:50.103'),('e964bb36-974f-4faf-ae5a-297cf4af20db',NULL,'68907da8-6eca-41aa-affa-e4710435daff','TREE_CREATED','Tree','0eb74c5d-3ceb-4b89-8680-4acffa892d3e',NULL,'{\"id\": \"0eb74c5d-3ceb-4b89-8680-4acffa892d3e\", \"name\": \"Sandbox Test Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:42:42.718'),('e9858398-c9bf-4707-bba4-f67f13503cfc',NULL,'698ca1b3-8f97-4156-bb79-88f0869781ca','TREE_CREATED','Tree','4f704e0c-b3ce-4ca5-8387-39baccb94b24',NULL,'{\"id\": \"4f704e0c-b3ce-4ca5-8387-39baccb94b24\", \"name\": \"SQL Iso Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:38:13.219'),('ea36bc73-6291-411c-9605-bd38bd2ead4d',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 16:32:53.287'),('ea757b2d-bd6c-43db-bfb7-d56306bca376',NULL,'66c04512-b98e-48ef-b5ac-14386e21f0b8','TREE_CREATED','Tree','3d2e9fc8-e95a-4eb8-9b00-b9129aca30d2',NULL,'{\"id\": \"3d2e9fc8-e95a-4eb8-9b00-b9129aca30d2\", \"name\": \"Sandbox Test Tree 1\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:50:30.721'),('eb74e055-5551-4d8f-8d22-8e146e775dce',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:28:38.271'),('ec89adec-057d-437a-aad6-fb3df43dbf07',NULL,'caf27a62-1a0f-4615-9e18-c07d43813883','USER_LOGIN_SUCCESS','User','caf27a62-1a0f-4615-9e18-c07d43813883',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-18 15:35:43.155'),('ec8b592d-df17-40ce-b4a0-dc21261ec043',NULL,'e695c7d3-daf8-4643-a3bb-0881b5dceedd','USER_REGISTERED','User','e695c7d3-daf8-4643-a3bb-0881b5dceedd',NULL,'{\"id\": \"e695c7d3-daf8-4643-a3bb-0881b5dceedd\", \"role\": \"USER\", \"email\": \"test42@local\", \"username\": \"TestAgent42\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 15:28:38.438'),('ed3762e3-68d0-4f7a-bdaa-6ba9957ba426','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_EXEC','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,'{\"exitCode\": 0, \"timeoutMs\": 30000}','127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:32:44.404'),('ede03c2b-7ea9-4017-b59f-03c8f2819bf3','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'TRIGGER_COMMENT_REVIEW','Tree','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,'{\"chatId\": \"-5274848173\", \"messageId\": 1075}','127.0.0.1','curl/8.5.0','INFO','AUTOMATION','2026-05-20 15:40:48.688'),('ee500a73-0dc6-42e8-9979-9d9893b6ccfa',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','Python-urllib/3.11','WARNING','USER','2026-05-13 15:28:38.258'),('f0267238-200e-407c-b273-d8be99b8fc93',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:28:21.707'),('f13d2b43-76a7-4bb3-94ea-e8ba6ac3b010','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:17:15.645'),('f14fc539-e249-4ca0-9f59-e34459bdb635',NULL,'7a3a01ae-7dcb-445d-942f-9996de05ddad','SANDBOX_DELETED','TreeSandbox','2930977a-0fd1-4f72-8261-de70ff736b42',NULL,NULL,NULL,'::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-15 14:25:02.871'),('f26a49f7-57ee-4aa4-ba7d-14b0e661c450',NULL,'0a08c64a-3126-4492-8e00-9c4f44f43086','TREE_CREATED','Tree','b71dd711-462a-4322-a007-5f11f1ce196c',NULL,'{\"id\": \"b71dd711-462a-4322-a007-5f11f1ce196c\", \"name\": \"SQL Iso Tree A\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:31:37.552'),('f499c018-4d8a-4cf9-a5ca-6a71f81ac450','a6568a38-9e21-4310-98ce-83e1a9e180f4','0a93ae63-b3ec-435e-9700-1324132b047c','TREE_CREATED','Tree','a6568a38-9e21-4310-98ce-83e1a9e180f4',NULL,'{\"id\": \"a6568a38-9e21-4310-98ce-83e1a9e180f4\", \"name\": \"CrossTree Test A 1779198288276\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 13:44:48.339'),('f4b0fd53-528a-468e-9e06-f2ff4b7c6465','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'SANDBOX_LIST','TreeSandbox','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:37:02.427'),('f5c0942f-9b2e-4881-aae6-d3f0bf747134',NULL,NULL,'USER_LOGIN_SUCCESS','User','dfa4c399-8fa7-43d7-ba64-2619f2bca753',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:39:59.356'),('f5c4fc00-87a8-4db3-8496-ddfd1d19e889',NULL,'ari','TREE_CREATED','Tree','a513e954-b684-4624-880d-38f71167fc55',NULL,'{\"id\": \"a513e954-b684-4624-880d-38f71167fc55\", \"name\": \"Sub-E2E-1779159826700\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','node','INFO','USER','2026-05-19 03:03:46.752'),('f661aed5-ddbe-4eb7-b396-7d0b6fb0c898','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 1}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:13:06.064'),('f669cd8e-39ce-4d87-8549-96217fbdd684','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'SANDBOX_EXEC','TreeSandbox','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,NULL,'{\"exitCode\": 0}','127.0.0.1','Python-urllib/3.11','INFO','SYSTEM','2026-05-20 11:52:21.173'),('f776cdcc-924a-43ce-a1c9-f72390fc6b02',NULL,'1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','TREE_CREATED','Tree','4241aa88-a679-4e17-afd6-0eb334c8d94e',NULL,'{\"id\": \"4241aa88-a679-4e17-afd6-0eb334c8d94e\", \"name\": \"Integration Test N6 v2\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 11:27:32.560'),('f8288478-2a3c-4e7e-8384-bb2c4a334e1b',NULL,'3d4cf853-e23d-43da-b661-e30f09f2b680','USER_REGISTERED','User','3d4cf853-e23d-43da-b661-e30f09f2b680',NULL,'{\"id\": \"3d4cf853-e23d-43da-b661-e30f09f2b680\", \"role\": \"USER\", \"email\": \"surveyvoter_3_1779200734549@test.com\", \"username\": \"surveyvoter_3_1779200734549\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:25:34.716'),('faf821cc-f14a-4b3c-95d0-d04c5f3928be',NULL,'0b121a5e-9b0f-4ed7-9cef-95200af8ec44','USER_REGISTERED','User','0b121a5e-9b0f-4ed7-9cef-95200af8ec44',NULL,'{\"id\": \"0b121a5e-9b0f-4ed7-9cef-95200af8ec44\", \"role\": \"PERSON\", \"email\": \"tooltester2@test.com\", \"username\": \"tooltester2\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 16:38:44.154'),('fb33dc68-49ec-4095-bed7-9759a36cab6e',NULL,'118bcfdb-bd89-42ce-a95b-83020a97dc5f','USER_REGISTERED','User','118bcfdb-bd89-42ce-a95b-83020a97dc5f',NULL,'{\"id\": \"118bcfdb-bd89-42ce-a95b-83020a97dc5f\", \"role\": \"USER\", \"email\": null, \"username\": \"test_admin\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-15 04:57:19.278'),('fb379c94-d521-4b25-a4fc-adef93653806',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','TREE_CREATED','Tree','a934d635-056a-4a0e-a78b-a671de31ca43',NULL,'{\"id\": \"a934d635-056a-4a0e-a78b-a671de31ca43\", \"name\": \"N6 Integration Test\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 11:58:06.434'),('fb76cbd5-7d07-43f7-997f-7c5571cc7700',NULL,'6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','TREE_CREATED','Tree','8979625b-e27c-42de-bf9c-66af576e15cf',NULL,'{\"id\": \"8979625b-e27c-42de-bf9c-66af576e15cf\", \"name\": \"N6 Integration Test v2\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-19 12:02:56.121'),('fb8aedb8-291b-4a37-870c-cfc5b2b5c40e',NULL,'e8ea827e-1378-4ed1-85ce-4850ddc7221f','TREE_CREATED','Tree','2ee717ef-f865-4472-a3ad-2e978cc29429',NULL,'{\"id\": \"2ee717ef-f865-4472-a3ad-2e978cc29429\", \"name\": \"SQL Iso Tree B\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:39:59.626'),('fbc50ecb-272d-415e-ae0d-4baeb2cf08d9',NULL,'379a2d98-460e-4c0c-a3d5-fc70bb541ca1','USER_LOGIN_SUCCESS','User','379a2d98-460e-4c0c-a3d5-fc70bb541ca1',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-13 13:27:41.113'),('fcd40db4-efb0-4807-8f4e-b094aa8593f3',NULL,'66c04512-b98e-48ef-b5ac-14386e21f0b8','TREE_CREATED','Tree','ca3fc928-7967-45cc-ba42-6647b88d296e',NULL,'{\"id\": \"ca3fc928-7967-45cc-ba42-6647b88d296e\", \"name\": \"Sandbox Test Tree D\", \"admissionPolicy\": \"OPEN\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-14 18:50:33.203'),('fd846310-0f84-4267-b862-4e90fb391251',NULL,NULL,'USER_LOGIN_FAILED','User',NULL,NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"reason\": \"user_not_found\"}','127.0.0.1','curl/8.5.0','WARNING','USER','2026-05-16 17:13:42.429'),('fdade000-1b8d-4033-801a-81ad9fc796f7',NULL,'7ec54910-cfc2-41b7-96e8-beea4f1017f9','USER_REGISTERED','User','7ec54910-cfc2-41b7-96e8-beea4f1017f9',NULL,'{\"id\": \"7ec54910-cfc2-41b7-96e8-beea4f1017f9\", \"role\": \"USER\", \"email\": \"crosstree_1779198487658@test.com\", \"username\": \"crosstree_1779198487658\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 13:48:08.046'),('fe8649ee-3da5-489a-b2c8-935eb93a12ef',NULL,NULL,'USER_LOGIN_SUCCESS','User','7b446ec1-1f1b-4efa-b2e3-c218632abc69',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','Python-urllib/3.11','INFO','USER','2026-05-13 13:17:48.606'),('fed8096e-6edb-4672-b186-25d21f5b8ecb',NULL,'4e230f5d-4b16-4082-b504-309106a90d34','USER_LOGIN_SUCCESS','User','4e230f5d-4b16-4082-b504-309106a90d34',NULL,NULL,'{\"route\": \"/api/auth/login\", \"method\": \"POST\", \"result\": \"success\"}','127.0.0.1','curl/8.5.0','INFO','USER','2026-05-16 17:29:24.096'),('ff3c6f9a-171b-4676-9705-74b0c411754b','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'SANDBOX_READ','TreeSandbox','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,NULL,NULL,'127.0.0.1','curl/8.5.0','INFO','SYSTEM','2026-05-20 04:33:53.743'),('ff433e48-d191-4577-af67-2732a557315c',NULL,'ca933a62-0228-412c-be01-9cfe4262c2d6','USER_REGISTERED','User','ca933a62-0228-412c-be01-9cfe4262c2d6',NULL,'{\"id\": \"ca933a62-0228-412c-be01-9cfe4262c2d6\", \"role\": \"USER\", \"email\": \"sqliso_1779201416931@test.com\", \"username\": \"sqliso_1779201416931\"}','{\"route\": \"/api/auth/register\", \"method\": \"POST\", \"result\": \"success\"}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 14:36:57.333'),('ffa83718-b2e0-48ad-a061-0938dd7fe352','c0c67870-7659-49df-b663-59b53c838123','0a93ae63-b3ec-435e-9700-1324132b047c','TREE_CREATED','Tree','c0c67870-7659-49df-b663-59b53c838123',NULL,'{\"id\": \"c0c67870-7659-49df-b663-59b53c838123\", \"name\": \"CrossTree Test B 1779198288350\", \"admissionPolicy\": \"INVITE_ONLY\"}','{\"route\": \"/api/trees\", \"method\": \"POST\", \"result\": \"success\", \"invitedCount\": 0}','::ffff:127.0.0.1',NULL,'INFO','USER','2026-05-19 13:44:48.445');
/*!40000 ALTER TABLE `EventLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EvidenceFile`
--

DROP TABLE IF EXISTS `EvidenceFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EvidenceFile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaderId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auditId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `originalName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storedName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storagePath` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `mimeType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sizeBytes` int NOT NULL,
  `visibility` enum('PRIVATE','TASK_PARTICIPANTS','TREE_ONLY','TRUST_NETWORK','PUBLIC_METADATA','PUBLIC') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TASK_PARTICIPANTS',
  `status` enum('ACTIVE','DELETED','QUARANTINED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `checksumSha256` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `EvidenceFile_uploaderId_idx` (`uploaderId`),
  KEY `EvidenceFile_treeId_idx` (`treeId`),
  KEY `EvidenceFile_taskId_idx` (`taskId`),
  KEY `EvidenceFile_visibility_idx` (`visibility`),
  KEY `EvidenceFile_status_idx` (`status`),
  CONSTRAINT `EvidenceFile_taskId_fkey` FOREIGN KEY (`taskId`) REFERENCES `Task` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `EvidenceFile_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EvidenceFile`
--

LOCK TABLES `EvidenceFile` WRITE;
/*!40000 ALTER TABLE `EvidenceFile` DISABLE KEYS */;
/*!40000 ALTER TABLE `EvidenceFile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExternalAgent`
--

DROP TABLE IF EXISTS `ExternalAgent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExternalAgent` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `externalNeedId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('CLIENT','SPONSOR','CONTACT','APPROVER','OBSERVER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CLIENT',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `consentAccepted` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `ExternalAgent_externalNeedId_idx` (`externalNeedId`),
  KEY `ExternalAgent_email_idx` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExternalAgent`
--

LOCK TABLES `ExternalAgent` WRITE;
/*!40000 ALTER TABLE `ExternalAgent` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExternalAgent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExternalNeed`
--

DROP TABLE IF EXISTS `ExternalNeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExternalNeed` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('DRAFT','OPEN','UNDER_REVIEW','SOLUTIONS_PROPOSED','APPROVED','REJECTED','CONVERTED_TO_TASKS','CANCELLED','COMPLETED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `clientSummary` text COLLATE utf8mb4_unicode_ci,
  `desiredOutcome` text COLLATE utf8mb4_unicode_ci,
  `constraints` text COLLATE utf8mb4_unicode_ci,
  `deadline` datetime(3) DEFAULT NULL,
  `budgetMinFiat` double DEFAULT NULL,
  `budgetMaxFiat` double DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'CLP',
  `visibility` enum('PRIVATE','TREE_ONLY','TRUST_NETWORK','PUBLIC_METADATA','PUBLIC') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TREE_ONLY',
  `metadataJson` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `ExternalNeed_treeId_idx` (`treeId`),
  KEY `ExternalNeed_status_idx` (`status`),
  KEY `ExternalNeed_createdById_idx` (`createdById`),
  KEY `ExternalNeed_createdAt_idx` (`createdAt`),
  CONSTRAINT `ExternalNeed_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExternalNeed`
--

LOCK TABLES `ExternalNeed` WRITE;
/*!40000 ALTER TABLE `ExternalNeed` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExternalNeed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExternalTask`
--

DROP TABLE IF EXISTS `ExternalTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExternalTask` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `skills` json NOT NULL,
  `budget` int NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CLP',
  `workerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('OPEN','CLAIMED','DELIVERED','APPROVED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `deliverableUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `approvedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kanbanBoard` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kanbanTaskId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rejectReason` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locationType` enum('REMOTE','ONSITE','HYBRID') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REMOTE',
  `difficulty` int DEFAULT '5',
  `quality` double DEFAULT NULL,
  `type` enum('HUMAN','AGENT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HUMAN',
  `endDate` datetime(3) DEFAULT NULL,
  `startDate` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ExternalTask_treeId_idx` (`treeId`),
  KEY `ExternalTask_workerId_idx` (`workerId`),
  KEY `ExternalTask_status_idx` (`status`),
  KEY `ExternalTask_createdBy_fkey` (`createdBy`),
  CONSTRAINT `ExternalTask_createdBy_fkey` FOREIGN KEY (`createdBy`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ExternalTask_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ExternalTask_workerId_fkey` FOREIGN KEY (`workerId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExternalTask`
--

LOCK TABLES `ExternalTask` WRITE;
/*!40000 ALTER TABLE `ExternalTask` DISABLE KEYS */;
INSERT INTO `ExternalTask` VALUES ('04e9c3dd-2e0f-482a-a861-85997b89da51','d48bd81b-3172-4687-8327-f6f743dac72d','ari','TEST-E2E: human-worker webhook verify','E2E verification — approve should trigger webhook','[\"test\"]',5000,'CLP',NULL,'OPEN',NULL,'2026-05-20 15:43:56.943','2026-05-20 15:43:56.943',NULL,'main','t_77453a98',NULL,NULL,'REMOTE',5,NULL,'HUMAN',NULL,NULL),('525e8a89-b06b-4131-9d07-60ec78dd0c0e','d48bd81b-3172-4687-8327-f6f743dac72d','ari','TEST-E2E-REJECT','Reject test','[\"test\"]',5000,'CLP','8d93fc6c-f486-49a9-9849-b58bc9201167','REJECTED','d48bd81b-3172-4687-8327-f6f743dac72d/external-tasks/525e8a89-b06b-4131-9d07-60ec78dd0c0e/1779292169295_evidence.txt','2026-05-20 15:49:29.204','2026-05-20 15:50:18.206',NULL,'main','t_65a9ec5b','La evidencia \"evidence\" es un placeholder genérico que no demuestra ningún trabajo realizado ni satisface los requisitos de la tarea. No hay entregable real.',NULL,'REMOTE',5,NULL,'HUMAN',NULL,NULL),('6edd860d-8ef8-442f-bcd3-65c62fc23edb','d48bd81b-3172-4687-8327-f6f743dac72d','ari','TEST-E2E-v2','E2E verification','[\"test\"]',5000,'CLP','8d93fc6c-f486-49a9-9849-b58bc9201167','APPROVED','d48bd81b-3172-4687-8327-f6f743dac72d/external-tasks/6edd860d-8ef8-442f-bcd3-65c62fc23edb/1779292106266_evidence.txt','2026-05-20 15:48:26.168','2026-05-20 15:48:26.300','ari','main','t_be05c18a',NULL,NULL,'REMOTE',5,NULL,'HUMAN',NULL,NULL),('9dd27e19-a15d-4750-bd72-a0304dcfcafb','d48bd81b-3172-4687-8327-f6f743dac72d','ari','TEST-E2E: human-worker dispatch test','Test dispatcher creates ExternalTask','[]',0,'CLP',NULL,'OPEN',NULL,'2026-05-20 15:47:42.795','2026-05-20 15:47:42.795',NULL,'default','t_4312bbfb',NULL,NULL,'REMOTE',5,NULL,'HUMAN',NULL,NULL),('d7b9151f-0512-4374-bbb2-ac76e40a83f6','d48bd81b-3172-4687-8327-f6f743dac72d','ari','TEST-E2E: Verify human-worker webhook','E2E verification — webhook should complete Kanban task on approve','[\"test\"]',5000,'CLP',NULL,'OPEN',NULL,'2026-05-20 15:41:55.383','2026-05-20 15:41:55.383',NULL,'main','t_e28c7c7f',NULL,NULL,'REMOTE',5,NULL,'HUMAN',NULL,NULL),('e8d16596-2069-4d64-877f-58a132317b49','d48bd81b-3172-4687-8327-f6f743dac72d','ari','TEST-E2E: human-worker webhook verify','E2E verification — approve should trigger webhook','[\"test\"]',5000,'CLP','8d93fc6c-f486-49a9-9849-b58bc9201167','APPROVED','d48bd81b-3172-4687-8327-f6f743dac72d/external-tasks/e8d16596-2069-4d64-877f-58a132317b49/1779291895280_evidence.txt','2026-05-20 15:44:55.133','2026-05-20 15:44:55.305','ari','main','t_fbd60e45',NULL,NULL,'REMOTE',5,NULL,'HUMAN',NULL,NULL),('fcf19aaf-ac77-4f3e-af78-9528fd3accea','d48bd81b-3172-4687-8327-f6f743dac72d','ari','TEST-E2E-REJECT','Reject test','[\"test\"]',5000,'CLP','8d93fc6c-f486-49a9-9849-b58bc9201167','REJECTED','d48bd81b-3172-4687-8327-f6f743dac72d/external-tasks/fcf19aaf-ac77-4f3e-af78-9528fd3accea/1779292208216_evidence.txt','2026-05-20 15:50:08.126','2026-05-20 15:50:08.246',NULL,'main','t_dac64297','Test rejection',NULL,'REMOTE',5,NULL,'HUMAN',NULL,NULL);
/*!40000 ALTER TABLE `ExternalTask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExternalTaskNotification`
--

DROP TABLE IF EXISTS `ExternalTaskNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExternalTaskNotification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `externalTaskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ExternalTaskNotification_externalTaskId_userId_key` (`externalTaskId`,`userId`),
  KEY `ExternalTaskNotification_externalTaskId_idx` (`externalTaskId`),
  KEY `ExternalTaskNotification_userId_idx` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExternalTaskNotification`
--

LOCK TABLES `ExternalTaskNotification` WRITE;
/*!40000 ALTER TABLE `ExternalTaskNotification` DISABLE KEYS */;
INSERT INTO `ExternalTaskNotification` VALUES ('c9f250f3-ae1d-4efb-bdf3-59fb1c91fbba','9dd27e19-a15d-4750-bd72-a0304dcfcafb','a03911c9-b29e-4d58-ab1a-794473d788d5',NULL,'2026-05-20 15:47:43.141');
/*!40000 ALTER TABLE `ExternalTaskNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FiatTemplate`
--

DROP TABLE IF EXISTS `FiatTemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FiatTemplate` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double DEFAULT NULL,
  `type` enum('INCOME','EXPENSE','INVESTMENT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('WATER','ELECTRICITY','GAS','MORTGAGE','FUEL','SHOPPING','EQUIPMENT','MATERIAL','MONEY','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `isPeriodic` tinyint(1) NOT NULL DEFAULT '0',
  `periodicity` enum('BEGINNING_OF_YEAR','BEGINNING_OF_MONTH','BEGINNING_OF_WEEK','CUSTOM_DAYS') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `daysCount` int DEFAULT NULL,
  `isFixed` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `lastUsedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FiatTemplate`
--

LOCK TABLES `FiatTemplate` WRITE;
/*!40000 ALTER TABLE `FiatTemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `FiatTemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FiatTransaction`
--

DROP TABLE IF EXISTS `FiatTransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FiatTransaction` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branchId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `externalNeedId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `templateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CLP',
  `type` enum('INCOME','EXPENSE','INVESTMENT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('WATER','ELECTRICITY','GAS','MORTGAGE','FUEL','SHOPPING','EQUIPMENT','MATERIAL','MONEY','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `verificationStatus` enum('DECLARED','BACKED_BY_RECEIPT','RECONCILED','AUDITED','API_VERIFIED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DECLARED',
  `receiptEvidenceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadataJson` json DEFAULT NULL,
  `date` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isAutomatic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FiatTransaction_treeId_idx` (`treeId`),
  KEY `FiatTransaction_branchId_idx` (`branchId`),
  KEY `FiatTransaction_taskId_idx` (`taskId`),
  KEY `FiatTransaction_type_idx` (`type`),
  KEY `FiatTransaction_verificationStatus_idx` (`verificationStatus`),
  KEY `FiatTransaction_date_idx` (`date`),
  KEY `FiatTransaction_externalNeedId_fkey` (`externalNeedId`),
  KEY `FiatTransaction_templateId_fkey` (`templateId`),
  CONSTRAINT `FiatTransaction_branchId_fkey` FOREIGN KEY (`branchId`) REFERENCES `Branch` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FiatTransaction_externalNeedId_fkey` FOREIGN KEY (`externalNeedId`) REFERENCES `ExternalNeed` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FiatTransaction_templateId_fkey` FOREIGN KEY (`templateId`) REFERENCES `FiatTemplate` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FiatTransaction`
--

LOCK TABLES `FiatTransaction` WRITE;
/*!40000 ALTER TABLE `FiatTransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `FiatTransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GroupMilestone`
--

DROP TABLE IF EXISTS `GroupMilestone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GroupMilestone` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` int NOT NULL,
  `phaseName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expectedMonths` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `objectives` json NOT NULL,
  `targetKPIs` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `GroupMilestone_groupType_phase_idx` (`groupType`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GroupMilestone`
--

LOCK TABLES `GroupMilestone` WRITE;
/*!40000 ALTER TABLE `GroupMilestone` DISABLE KEYS */;
INSERT INTO `GroupMilestone` VALUES ('062031fc-b982-4505-b686-11d95251b7aa','programadores',2,'Operación inicial',4,'2026-05-16 19:04:46.141','[\"MVP entregado\", \"5 features completadas\", \"Code review activo\"]','{\"mvpDelivered\": 1, \"featuresCompleted\": 5}'),('11363ae5-1ff0-4aad-8684-93afa47b50de','restaurantes',1,'Constitución',2,'2026-05-16 19:04:46.673','[\"Formar equipo\", \"Habilitar cocina\", \"Permisos sanitarios\"]','{\"cocinaHabilitada\": true, \"membersOnboarded\": 5}'),('25705082-c858-4928-89a6-52d83bb76efb','profesores',3,'Validación',6,'2026-05-16 19:04:46.548','[\"Alumnos recurrentes\", \"Resultados de aprendizaje\", \"Ajuste de programas\"]','{\"avgSatisfaction\": 80, \"recurringStudents\": 10}'),('2b5f5e9e-4226-4051-8a62-9d2aba15a926','programadores',4,'Autonomía',10,'2026-05-16 19:04:46.169','[\"Autonomía financiera\", \"Producto propio\", \"Open source contribution\"]','{\"openSourceRepos\": 1, \"financialAutonomy\": true}'),('2c0137ed-1a54-42bb-aeb8-a1f2b02023f6','profesores',2,'Operación inicial',4,'2026-05-16 19:04:46.539','[\"20 alumnos activos\", \"Primeras evaluaciones\", \"Material didáctico\"]','{\"activeStudents\": 20}'),('2c684ffa-579c-4dfa-a88d-cfb9283b7405','contadores',3,'Validación',6,'2026-05-16 19:04:46.493','[\"Clientes recurrentes\", \"Auditorías completadas\", \"Ajuste de tarifas\"]','{\"auditsCompleted\": 2, \"recurringClients\": 5}'),('4a968cc3-a9c7-444a-b747-e7797592205a','restaurantes',2,'Operación inicial',4,'2026-05-16 19:04:46.695','[\"Apertura al público\", \"Menú estable\", \"50 cubiertos/día\"]','{\"dailyCovers\": 50}'),('5224a204-f99a-4b95-98e8-99fa302b01d6','fotografos',2,'Operación inicial',4,'2026-05-16 19:04:46.602','[\"5 clientes atendidos\", \"Presencia online\", \"Primeros ingresos\"]','{\"clientsServed\": 5}'),('56a9a0de-ec7d-46a3-b678-95477c448196','lawyers',4,'Autonomy',12,'2026-05-16 19:04:46.874','[\"Financial autonomy\", \"Specialization by branch\", \"Export model\"]','{\"financialAutonomy\": true, \"specialtyBranches\": 2}'),('56eac74a-ebac-4e74-80f8-0298046cc2b8','lawyers',2,'Initial ops',4,'2026-05-16 19:04:46.851','[\"5 cases opened\", \"Case management system\", \"First fees collected\"]','{\"casesOpened\": 5}'),('5790b74d-49d3-40f0-8b49-65616868850c','medicos',4,'Autonomía',12,'2026-05-16 19:04:46.237','[\"Autonomía financiera\", \"Atención multidisciplinaria\", \"Exportar modelo\"]','{\"disciplinesCount\": 3, \"financialAutonomy\": true}'),('60812900-6312-4a27-856e-4d1e3ce842af','abogados',1,'Constitución',2,'2026-05-16 19:04:46.276','[\"Formar equipo legal\", \"Habilitar estudio\", \"Inscripción en colegio\"]','{\"membersOnboarded\": 3, \"estudioHabilitado\": true}'),('65274b85-5f89-4b0f-846e-98fd744041cd','abogados',3,'Validación',6,'2026-05-16 19:04:46.318','[\"2 causas ganadas\", \"Clientes corporativos\", \"Ajuste de honorarios\"]','{\"casesWon\": 2, \"corporativeClients\": 1}'),('6634158f-fb52-49ff-a4f1-4042dcd5c0cc','restaurantes',4,'Autonomía',12,'2026-05-16 19:04:46.734','[\"Autonomía financiera\", \"Carta de vinos\", \"Exportar concepto\"]','{\"expandedMenu\": true, \"financialAutonomy\": true}'),('6c178d9e-dda0-4732-b248-eae888db3e4b','construction',2,'Operación inicial',4,'2026-05-16 19:04:46.060','[\"Primera obra iniciada\", \"5 tareas completadas\", \"80% asistencia\"]','{\"worksStarted\": 1, \"tasksCompleted\": 5}'),('71e8953e-17dc-4953-bcd5-637474b450e3','construction',4,'Autonomía',12,'2026-05-16 19:04:46.100','[\"Autonomía financiera\", \"2 obras simultáneas\", \"Exportar know-how\"]','{\"financialAutonomy\": true, \"simultaneousWorks\": 2}'),('76a38091-5815-4cfb-85c5-fb16beaf2dc2','medicos',3,'Validación',6,'2026-05-16 19:04:46.219','[\"Convenio con obra social\", \"Pacientes recurrentes\", \"Ajuste de honorarios\"]','{\"recurringPatients\": 20, \"obraSocialConvenio\": 1}'),('7a958422-61d4-405d-98f7-f2521b373a90','fotografos',4,'Autonomía',8,'2026-05-16 19:04:46.636','[\"Autonomía financiera\", \"Estudio propio\", \"Exportar estilo\"]','{\"financialAutonomy\": true, \"studioEstablished\": true}'),('82b54abd-0f5b-4ba6-8e0b-60f18ad4fbc1','albañiles',2,'Operación inicial',4,'2026-05-16 19:04:46.766','[\"3 obras pequeñas\", \"Calidad consistente\", \"80% puntualidad\"]','{\"jobsCompleted\": 3}'),('8cee9c99-1ddf-4e83-81aa-823d33379118','abogados',4,'Autonomía',12,'2026-05-16 19:04:46.366','[\"Autonomía financiera\", \"Especialización por rama\", \"Exportar modelo\"]','{\"financialAutonomy\": true, \"specialtyBranches\": 2}'),('92ef0315-b706-439d-8380-a1b09c6879c1','construction',1,'Constitución',2,'2026-05-16 19:04:46.043','[\"Formar equipo base\", \"Instalar herramientas\", \"Primera cotización aceptada\"]','{\"quoteAccepted\": 1, \"membersOnboarded\": 4}'),('97203a6f-be5a-473c-865a-35b429e7cf23','contadores',2,'Operación inicial',4,'2026-05-16 19:04:46.467','[\"10 clientes activos\", \"Primeras declaraciones\", \"Sistema de cobranza\"]','{\"activeClients\": 10}'),('9f1ae3fa-6b78-4cac-96b2-1d7fbc1f45a2','abogados',2,'Operación inicial',4,'2026-05-16 19:04:46.293','[\"5 causas iniciadas\", \"Sistema de gestión\", \"Primeros honorarios\"]','{\"casesOpened\": 5}'),('a2c2f7c6-7f6d-4aab-b9a0-7bf6e8488ef0','profesores',1,'Constitución',2,'2026-05-16 19:04:46.522','[\"Formar equipo docente\", \"Definir programas\", \"Inscripción de alumnos\"]','{\"programsDefined\": 3, \"membersOnboarded\": 3}'),('a62fa0a6-989a-44fe-a252-1abb91c07fbd','lawyers',3,'Validation',6,'2026-05-16 19:04:46.866','[\"2 cases won\", \"Corporate clients\", \"Fee adjustment\"]','{\"casesWon\": 2, \"corporateClients\": 1}'),('a6a5c844-487b-43f9-affb-c8dd9c852596','contadores',1,'Constitución',2,'2026-05-16 19:04:46.436','[\"Formar equipo contable\", \"Software de gestión\", \"Registro profesional\"]','{\"softwareSetup\": true, \"membersOnboarded\": 2}'),('a8f283f7-440b-47b5-abf0-7cf42b622560','restaurantes',3,'Validación',6,'2026-05-16 19:04:46.726','[\"Clientes recurrentes\", \"Reseñas positivas\", \"Ajuste de menú\"]','{\"avgRating\": 4, \"recurringCustomers\": 30}'),('b0fa50c5-6714-45fa-a616-5d8f480f8baf','medicos',2,'Operación inicial',4,'2026-05-16 19:04:46.209','[\"50 pacientes atendidos\", \"Sistema de turnos\", \"Historias clínicas digitalizadas\"]','{\"patientsAttended\": 50}'),('b6cc5f31-c0e8-4ad6-821f-dfbd0d8e62e4','programadores',1,'Constitución',2,'2026-05-16 19:04:46.132','[\"Formar equipo dev\", \"Configurar repositorio\", \"Elegir stack tecnológico\"]','{\"repoSetup\": true, \"membersOnboarded\": 3}'),('ba391a8e-30af-4316-9376-7537ac68e7a3','programadores',3,'Validación',6,'2026-05-16 19:04:46.151','[\"Primer cliente recurrente\", \"Pipeline CI/CD\", \"Métricas de calidad\"]','{\"ciCdSetup\": true, \"recurringClients\": 1}'),('c033808f-18e0-472d-baf0-3a1cd7fe9ec4','medicos',1,'Constitución',2,'2026-05-16 19:04:46.195','[\"Formar equipo médico\", \"Habilitar consultorio\", \"Registros sanitarios\"]','{\"membersOnboarded\": 3, \"consultorioHabilitado\": true}'),('c1173ff1-c4b5-49f2-bf3d-9634cc1cec59','contadores',4,'Autonomía',10,'2026-05-16 19:04:46.501','[\"Autonomía financiera\", \"Consultoría fiscal avanzada\", \"Exportar modelo\"]','{\"fiscalConsulting\": true, \"financialAutonomy\": true}'),('c5c1eb4e-0dae-4bcd-a792-793855ec14b4','albañiles',4,'Autonomía',10,'2026-05-16 19:04:46.809','[\"Autonomía financiera\", \"Especialización\", \"Exportar oficio\"]','{\"specialtyWorkers\": 2, \"financialAutonomy\": true}'),('dac54008-3c24-44c2-850e-3a2d28e66a4b','fotografos',1,'Constitución',2,'2026-05-16 19:04:46.586','[\"Formar equipo\", \"Adquirir equipo base\", \"Portfolio inicial\"]','{\"portfolioPieces\": 10, \"membersOnboarded\": 2}'),('e5fece82-9d77-44c1-94cf-b6ec8fd25af0','profesores',4,'Autonomía',8,'2026-05-16 19:04:46.565','[\"Autonomía financiera\", \"Programas propios\", \"Exportar metodología\"]','{\"financialAutonomy\": true, \"proprietaryPrograms\": 2}'),('e6b38eec-de3a-4baf-8953-564a8f6d1a02','albañiles',3,'Validación',6,'2026-05-16 19:04:46.795','[\"Clientes satisfechos\", \"Obras medianas\", \"Ajuste de tarifas\"]','{\"mediumJobs\": 1, \"clientSatisfaction\": 85}'),('ebf8048b-e71f-467c-8b86-de7ee5dda237','fotografos',3,'Validación',6,'2026-05-16 19:04:46.620','[\"Clientes recurrentes\", \"Especialización\", \"Ajuste de tarifas\"]','{\"recurringClients\": 3, \"specialtyDefined\": true}'),('ec59f002-6db8-43d5-bd54-ef9e4678c525','albañiles',1,'Constitución',2,'2026-05-16 19:04:46.755','[\"Formar equipo\", \"Adquirir herramientas\", \"Primer trabajo\"]','{\"toolsReady\": true, \"membersOnboarded\": 3}'),('f2fb18d3-f291-4c8a-9055-733dd4f66f30','lawyers',1,'Setup',2,'2026-05-16 19:04:46.831','[\"Form legal team\", \"Setup office\", \"Bar registration\"]','{\"officeReady\": true, \"membersOnboarded\": 3}'),('fedbe889-b0f4-452e-95fa-4b593499cba8','construction',3,'Validación',6,'2026-05-16 19:04:46.077','[\"Primera obra entregada\", \"Cliente satisfecho\", \"Ajuste de presupuesto\"]','{\"worksDelivered\": 1, \"clientSatisfaction\": 80}');
/*!40000 ALTER TABLE `GroupMilestone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GroupRole`
--

DROP TABLE IF EXISTS `GroupRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GroupRole` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roleName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `typicalCount` int NOT NULL,
  `ratioToMembers` double DEFAULT NULL,
  `requiredSkills` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avgLoad` int DEFAULT NULL,
  `occurrences` int NOT NULL DEFAULT '1',
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'seed',
  `lastConfirmedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `GroupRole_groupType_roleName_key` (`groupType`,`roleName`),
  KEY `GroupRole_groupType_idx` (`groupType`),
  KEY `GroupRole_roleName_idx` (`roleName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GroupRole`
--

LOCK TABLES `GroupRole` WRITE;
/*!40000 ALTER TABLE `GroupRole` DISABLE KEYS */;
INSERT INTO `GroupRole` VALUES ('b9354af0-5145-11f1-9ad5-843a4b23a26c','constructora pequeña','jefe de obra',1,0.125,'[\"gestión de obra\", \"liderazgo\", \"seguridad\"]',8,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9355192-5145-11f1-9ad5-843a4b23a26c','constructora pequeña','maestro de obra',2,0.25,'[\"albañilería\", \"lectura de planos\", \"supervisión\"]',7,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9355545-5145-11f1-9ad5-843a4b23a26c','constructora pequeña','oficial albañil',3,0.375,'[\"albañilería\", \"mezclas\", \"herramientas\"]',6,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9355850-5145-11f1-9ad5-843a4b23a26c','constructora pequeña','administrador',1,0.125,'[\"contabilidad\", \"compras\", \"nómina\"]',5,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9355b44-5145-11f1-9ad5-843a4b23a26c','constructora pequeña','prevencionista',1,0.125,'[\"seguridad laboral\", \"normativa\", \"inspección\"]',4,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9355e80-5145-11f1-9ad5-843a4b23a26c','constructora mediana','gerente de proyecto',1,0.05,'[\"gestión de proyecto\", \"PMBOK\", \"presupuestos\"]',9,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b93561b3-5145-11f1-9ad5-843a4b23a26c','constructora mediana','jefe de obra',2,0.1,'[\"gestión de obra\", \"liderazgo\", \"seguridad\"]',8,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9356490-5145-11f1-9ad5-843a4b23a26c','constructora mediana','maestro de obra',3,0.15,'[\"albañilería\", \"lectura de planos\", \"supervisión\"]',7,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9356790-5145-11f1-9ad5-843a4b23a26c','constructora mediana','oficial albañil',6,0.3,'[\"albañilería\", \"mezclas\", \"herramientas\"]',6,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9356a7b-5145-11f1-9ad5-843a4b23a26c','constructora mediana','administrador',2,0.1,'[\"contabilidad\", \"compras\", \"nómina\"]',5,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9356ddf-5145-11f1-9ad5-843a4b23a26c','constructora mediana','prevencionista',1,0.05,'[\"seguridad laboral\", \"normativa\", \"inspección\"]',4,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b93570e1-5145-11f1-9ad5-843a4b23a26c','constructora mediana','topógrafo',1,0.05,'[\"topografía\", \"estación total\", \"GPS\"]',5,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9357524-5145-11f1-9ad5-843a4b23a26c','constructora mediana','arquitecto',2,0.1,'[\"diseño\", \"Revit\", \"normativa urbana\"]',7,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b93578a1-5145-11f1-9ad5-843a4b23a26c','agencia digital','director creativo',1,0.1,'[\"dirección de arte\", \"estrategia\", \"pitch\"]',9,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9357b91-5145-11f1-9ad5-843a4b23a26c','agencia digital','diseñador senior',2,0.2,'[\"UI/UX\", \"Figma\", \"design systems\"]',8,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9357e65-5145-11f1-9ad5-843a4b23a26c','agencia digital','desarrollador full-stack',2,0.2,'[\"React\", \"Node.js\", \"PostgreSQL\"]',8,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935813a-5145-11f1-9ad5-843a4b23a26c','agencia digital','project manager',1,0.1,'[\"Scrum\", \"Jira\", \"gestión de clientes\"]',7,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9358424-5145-11f1-9ad5-843a4b23a26c','agencia digital','copywriter',1,0.1,'[\"copywriting\", \"SEO\", \"branding\"]',5,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b93586fd-5145-11f1-9ad5-843a4b23a26c','agencia digital','community manager',1,0.1,'[\"redes sociales\", \"contenido\", \"analítica\"]',4,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9358aee-5145-11f1-9ad5-843a4b23a26c','restaurante','chef ejecutivo',1,0.125,'[\"cocina\", \"menú\", \"proveedores\"]',9,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9358ec0-5145-11f1-9ad5-843a4b23a26c','restaurante','sous chef',1,0.125,'[\"cocina\", \"supervisión\", \"inventario\"]',8,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b93591ef-5145-11f1-9ad5-843a4b23a26c','restaurante','cocinero',2,0.25,'[\"cocina\", \"preparación\", \"higiene\"]',7,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b93595fe-5145-11f1-9ad5-843a4b23a26c','restaurante','mesero',3,0.375,'[\"servicio\", \"atención al cliente\", \"POS\"]',6,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9359a06-5145-11f1-9ad5-843a4b23a26c','restaurante','administrador',1,0.125,'[\"contabilidad\", \"proveedores\", \"personal\"]',5,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9359cfa-5145-11f1-9ad5-843a4b23a26c','taller mecánico','jefe de taller',1,0.2,'[\"mecánica\", \"gestión\", \"diagnóstico\"]',8,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b9359fc7-5145-11f1-9ad5-843a4b23a26c','taller mecánico','mecánico senior',1,0.2,'[\"mecánica general\", \"electrónica\", \"diagnóstico\"]',7,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935a29a-5145-11f1-9ad5-843a4b23a26c','taller mecánico','mecánico',2,0.4,'[\"mecánica\", \"cambio de piezas\", \"mantenimiento\"]',6,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935a571-5145-11f1-9ad5-843a4b23a26c','taller mecánico','administrador',1,0.2,'[\"facturación\", \"inventario\", \"atención al cliente\"]',4,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935a845-5145-11f1-9ad5-843a4b23a26c','consultora','socio director',1,0.1,'[\"estrategia\", \"desarrollo de negocio\", \"liderazgo\"]',9,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935ab30-5145-11f1-9ad5-843a4b23a26c','consultora','consultor senior',2,0.2,'[\"análisis\", \"presentaciones\", \"gestión de proyectos\"]',8,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935ae17-5145-11f1-9ad5-843a4b23a26c','consultora','consultor junior',3,0.3,'[\"investigación\", \"Excel\", \"PowerPoint\"]',6,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935b0fd-5145-11f1-9ad5-843a4b23a26c','consultora','analista de datos',1,0.1,'[\"SQL\", \"Python\", \"visualización\"]',7,1,'CURATED',NULL,'2026-05-16 12:38:52.000'),('b935b3e0-5145-11f1-9ad5-843a4b23a26c','consultora','administrador',1,0.1,'[\"facturación\", \"RRHH\", \"operaciones\"]',4,1,'CURATED',NULL,'2026-05-16 12:38:52.000');
/*!40000 ALTER TABLE `GroupRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GroupStructure`
--

DROP TABLE IF EXISTS `GroupStructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GroupStructure` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'seed',
  `usageCount` int NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `budgetAllocation` json DEFAULT NULL,
  `capitalInicial` double DEFAULT NULL,
  `roiMonth` int DEFAULT NULL,
  `typicalSubTrees` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `GroupStructure_groupType_idx` (`groupType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GroupStructure`
--

LOCK TABLES `GroupStructure` WRITE;
/*!40000 ALTER TABLE `GroupStructure` DISABLE KEYS */;
INSERT INTO `GroupStructure` VALUES ('08a344ce-a614-4d36-907b-2484f6f2fb24','restaurantes','seed',1,'2026-05-16 19:04:46.658','{\"tools\": 20, \"services\": 20, \"personnel\": 45, \"contingency\": 15}',10000000,12,'[{\"name\": \"Cocina\", \"goals\": \"Preparación de platos, menú y control de calidad\", \"members\": 3, \"budgetPct\": 35}, {\"name\": \"Salón\", \"goals\": \"Atención al cliente y servicio de mesa\", \"members\": 2, \"budgetPct\": 20}, {\"name\": \"Administración\", \"goals\": \"Compras, proveedores y finanzas\", \"members\": 2, \"budgetPct\": 20}, {\"name\": \"Marketing\", \"goals\": \"Redes sociales, promociones y delivery\", \"members\": 1, \"budgetPct\": 15}, {\"name\": \"Reserva\", \"goals\": \"Mantenimiento de equipos y emergencias\", \"members\": 0, \"budgetPct\": 10}]'),('5c42cfa6-5658-408a-9c68-f7fc00d2c1a0','medicos','seed',1,'2026-05-16 19:04:46.185','{\"tools\": 15, \"services\": 15, \"personnel\": 55, \"contingency\": 15}',8000000,12,'[{\"name\": \"Consultas\", \"goals\": \"Atención de pacientes y consultas médicas\", \"members\": 3, \"budgetPct\": 40}, {\"name\": \"Especialidades\", \"goals\": \"Derivaciones y atención especializada\", \"members\": 2, \"budgetPct\": 25}, {\"name\": \"Administración\", \"goals\": \"Agenda, facturación y gestión de historiales\", \"members\": 2, \"budgetPct\": 20}, {\"name\": \"Reserva\", \"goals\": \"Equipamiento médico, insumos y emergencias\", \"members\": 0, \"budgetPct\": 15}]'),('676a987d-8eb9-467c-ae26-bf437d0b5e5d','fotografos','seed',1,'2026-05-16 19:04:46.575','{\"tools\": 30, \"services\": 15, \"personnel\": 40, \"contingency\": 15}',3500000,8,'[{\"name\": \"Producción\", \"goals\": \"Sesiones fotográficas, edición y post-producción\", \"members\": 2, \"budgetPct\": 40}, {\"name\": \"Comercial\", \"goals\": \"Ventas, marketing y captación de clientes\", \"members\": 2, \"budgetPct\": 25}, {\"name\": \"Equipamiento\", \"goals\": \"Mantenimiento y actualización de equipos\", \"members\": 1, \"budgetPct\": 15}, {\"name\": \"Administración\", \"goals\": \"Contratos, agenda y facturación\", \"members\": 1, \"budgetPct\": 20}]'),('91c7c5e0-e0db-4bd8-87c8-a7d999fc71aa','programadores','seed',1,'2026-05-16 19:04:46.109','{\"tools\": 20, \"services\": 15, \"personnel\": 55, \"contingency\": 10}',3000000,8,'[{\"name\": \"Desarrollo\", \"goals\": \"Desarrollo de software: frontend, backend y mobile\", \"members\": 3, \"budgetPct\": 45}, {\"name\": \"Diseño UX/UI\", \"goals\": \"Diseño de interfaces y experiencia de usuario\", \"members\": 1, \"budgetPct\": 15}, {\"name\": \"QA / Testing\", \"goals\": \"Control de calidad, testing automatizado y manual\", \"members\": 1, \"budgetPct\": 15}, {\"name\": \"Administración\", \"goals\": \"Gestión de proyectos, clientes y finanzas\", \"members\": 2, \"budgetPct\": 15}, {\"name\": \"Reserva\", \"goals\": \"Fondo para servidores, herramientas SaaS y emergencias\", \"members\": 0, \"budgetPct\": 10}]'),('9c946cb7-bdaf-4daa-985e-6fa436e706e5','contadores','seed',1,'2026-05-16 19:04:46.404','{\"tools\": 10, \"services\": 15, \"personnel\": 60, \"contingency\": 15}',2500000,10,'[{\"name\": \"Contabilidad\", \"goals\": \"Registros contables, balances y estados financieros\", \"members\": 2, \"budgetPct\": 40}, {\"name\": \"Impuestos\", \"goals\": \"Declaraciones juradas, IVA y planificación fiscal\", \"members\": 2, \"budgetPct\": 25}, {\"name\": \"Auditoría\", \"goals\": \"Auditorías internas y externas\", \"members\": 1, \"budgetPct\": 15}, {\"name\": \"Administración\", \"goals\": \"Atención a clientes, cobranza y gestión\", \"members\": 2, \"budgetPct\": 20}]'),('cbf7434a-4993-4aff-a427-3976953884fd','lawyers','seed',1,'2026-05-16 19:04:46.820','{\"tools\": 10, \"services\": 15, \"personnel\": 60, \"contingency\": 15}',5000000,12,'[{\"name\": \"Litigation\", \"goals\": \"Legal representation in court and mediation\", \"members\": 2, \"budgetPct\": 35}, {\"name\": \"Consulting\", \"goals\": \"Preventive legal advice and contracts\", \"members\": 2, \"budgetPct\": 25}, {\"name\": \"Corporate\", \"goals\": \"Company incorporation and compliance\", \"members\": 1, \"budgetPct\": 20}, {\"name\": \"Administration\", \"goals\": \"Case management, billing and scheduling\", \"members\": 2, \"budgetPct\": 20}]'),('d5d7353b-be24-4307-b297-af54c465d37c','profesores','seed',1,'2026-05-16 19:04:46.512','{\"tools\": 10, \"services\": 15, \"personnel\": 60, \"contingency\": 15}',2000000,8,'[{\"name\": \"Cátedras\", \"goals\": \"Dictado de clases y preparación de material\", \"members\": 3, \"budgetPct\": 40}, {\"name\": \"Tutorías\", \"goals\": \"Apoyo personalizado y refuerzo académico\", \"members\": 2, \"budgetPct\": 25}, {\"name\": \"Investigación\", \"goals\": \"Desarrollo de contenido y publicaciones\", \"members\": 1, \"budgetPct\": 15}, {\"name\": \"Administración\", \"goals\": \"Gestión de alumnos, cobranza y agenda\", \"members\": 2, \"budgetPct\": 20}]'),('da2e3915-d8f9-4409-b880-c02611bf55b4','abogados','seed',1,'2026-05-16 19:04:46.265','{\"tools\": 10, \"services\": 15, \"personnel\": 60, \"contingency\": 15}',4000000,12,'[{\"name\": \"Litigios\", \"goals\": \"Representación legal en juicios y mediaciones\", \"members\": 2, \"budgetPct\": 35}, {\"name\": \"Consultoría\", \"goals\": \"Asesoría legal preventiva y contratos\", \"members\": 2, \"budgetPct\": 25}, {\"name\": \"Corporativo\", \"goals\": \"Constitución de empresas y compliance\", \"members\": 1, \"budgetPct\": 20}, {\"name\": \"Administración\", \"goals\": \"Gestión de expedientes, cobranza y agenda\", \"members\": 2, \"budgetPct\": 20}]'),('dfddd0aa-3b18-4a6f-8107-b8a470df60de','albañiles','seed',1,'2026-05-16 19:04:46.745','{\"tools\": 20, \"services\": 15, \"personnel\": 50, \"contingency\": 15}',3000000,10,'[{\"name\": \"Obra\", \"goals\": \"Albañilería, hormigón y estructura\", \"members\": 3, \"budgetPct\": 45}, {\"name\": \"Terminaciones\", \"goals\": \"Yeso, pintura y revestimientos\", \"members\": 2, \"budgetPct\": 25}, {\"name\": \"Administración\", \"goals\": \"Presupuestos y gestión de trabajos\", \"members\": 1, \"budgetPct\": 15}, {\"name\": \"Reserva\", \"goals\": \"Herramientas y materiales de emergencia\", \"members\": 0, \"budgetPct\": 15}]'),('f714b0fb-f048-417e-a57b-aa6c1973efb7','construction','seed',1,'2026-05-16 19:04:46.019','{\"tools\": 25, \"services\": 15, \"personnel\": 45, \"contingency\": 15}',5000000,12,'[{\"name\": \"Obra Gruesa\", \"goals\": \"Ejecución de estructura, cimientos y obra gruesa\", \"members\": 4, \"budgetPct\": 40}, {\"name\": \"Terminaciones\", \"goals\": \"Pintura, revestimientos y acabados finales\", \"members\": 3, \"budgetPct\": 25}, {\"name\": \"Administración\", \"goals\": \"Presupuestos, permisos y gestión de clientes\", \"members\": 2, \"budgetPct\": 15}, {\"name\": \"Adquisiciones\", \"goals\": \"Compra de materiales y subcontratación de especialistas\", \"members\": 2, \"budgetPct\": 15}, {\"name\": \"Reserva\", \"goals\": \"Fondo de contingencia para imprevistos de obra\", \"members\": 0, \"budgetPct\": 5}]');
/*!40000 ALTER TABLE `GroupStructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HiringApplicant`
--

DROP TABLE IF EXISTS `HiringApplicant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HiringApplicant` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('APPLIED','IGNORED','CLOSED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'APPLIED',
  `appliedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `closedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `HiringApplicant_taskId_userId_key` (`taskId`,`userId`),
  KEY `HiringApplicant_taskId_idx` (`taskId`),
  KEY `HiringApplicant_userId_idx` (`userId`),
  KEY `HiringApplicant_taskId_status_idx` (`taskId`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HiringApplicant`
--

LOCK TABLES `HiringApplicant` WRITE;
/*!40000 ALTER TABLE `HiringApplicant` DISABLE KEYS */;
INSERT INTO `HiringApplicant` VALUES ('e470d90f-538d-11f1-9ad5-843a4b23a26c','hiring-test-6e501027','a03911c9-b29e-4d58-ab1a-794473d788d5','45d2cc3b-4e61-4fe0-aeda-0f7c8d27a6f1','CLOSED','2026-05-19 10:20:31.000','2026-05-19 10:20:31.000');
/*!40000 ALTER TABLE `HiringApplicant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Idea`
--

DROP TABLE IF EXISTS `Idea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Idea` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `creatorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isGlobal` tinyint(1) NOT NULL DEFAULT '0',
  `sourceTreeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalLikes` int NOT NULL DEFAULT '0',
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `telegramMessageId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Idea_creatorId_fkey` (`creatorId`),
  KEY `Idea_needId_fkey` (`needId`),
  CONSTRAINT `Idea_creatorId_fkey` FOREIGN KEY (`creatorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Idea_needId_fkey` FOREIGN KEY (`needId`) REFERENCES `Need` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Idea`
--

LOCK TABLES `Idea` WRITE;
/*!40000 ALTER TABLE `Idea` DISABLE KEYS */;
INSERT INTO `Idea` VALUES ('0268a4b4-8032-470b-9ed7-6b91f70fad5d','Alertas inteligentes con anomaly detection. Usar Prometheus anomaly detection para alertar solo en desviaciones reales, no en ruido de tráfico normal.','705ea231-a674-446d-bc21-b4691320b409',0,NULL,3,NULL,'2026-05-16 18:55:05.348',NULL),('0272f1ef-3d67-41e5-9300-4870b6372707','Integrar Playwright en vez de Cypress. Playwright ofrece mejor soporte para múltiples browsers, fixtures y test isolation que Cypress.','c3888834-11ca-4e59-a693-1a557aea49fa',0,NULL,5,NULL,'2026-05-16 18:55:05.289',NULL),('0b82d793-f5ca-4e47-9fb4-dc2683170940','Documentación interactiva con Storybook 8. Storybook 8 con addon-docs automático, controles interactivos y deploy automático a Chromatic.','60c0e19e-75d8-4dd8-898a-02e7b6253610',1,NULL,2,NULL,'2026-05-16 18:55:05.415',NULL),('3144cee8-c37c-44bf-bbcc-36d84636da68','Riego por goteo con materiales reciclados. Usar botellas PET y mangueras recicladas para armar un sistema de riego de bajo costo para el huerto.','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c',0,NULL,6,NULL,'2026-05-16 18:55:05.452',NULL),('34bb5f4c-6564-4f82-9cc6-7367f104d45f','Usar Turbopack para builds más rápidos. Migrar de Webpack a Turbopack en Next.js 15 para reducir tiempo de build en CI.','b71a1f60-81c4-4d7a-af4a-a822b7826e1e',0,NULL,11,NULL,'2026-05-16 18:55:05.310',NULL),('393f8b94-b2a5-477f-b821-214437dfc5cf','App de seguimiento de huerto escolar. App simple para que los niños registren crecimiento de plantas, riego y cosecha con fotos.','edad98a4-7db3-4318-98ce-55eabab586ed',1,NULL,2,NULL,'2026-05-16 18:55:05.620',NULL),('3c254fee-71ce-4686-9e20-17347bf5c59d','Videos de ejercicios pregrabados con tracking. Biblioteca de 40 videos de rehabilitación organizados por fase post-operatoria con tracking de visualización.','0a258c6d-5917-4ed6-9555-a8dbd5706720',1,NULL,3,NULL,'2026-05-16 18:55:05.754',NULL),('3d82f6c3-a987-44fd-a8c1-32cc05208206','Guía de remediación de vulnerabilidades. Documento con pasos concretos para cada vulnerabilidad encontrada, priorizadas por severidad.','a8f9dba7-2d27-404c-87a7-23916748ba03',1,NULL,2,NULL,'2026-05-16 18:55:05.360',NULL),('43588f35-e929-4e77-a894-3f74a6d551b1','Componentes base: Button, Input, Modal, Table. Primeros 4 componentes del design system con variantes, estados y accesibilidad WCAG 2.1 AA.','f73b8593-2d52-4a8a-8201-58545e5371fb',1,NULL,2,NULL,'2026-05-16 18:55:05.391',NULL),('4714b46c-912c-4229-b04c-83dbefbb10a8','Wearables Bluetooth integrados. Conectar tensiómetros y glucómetros Bluetooth LE al dashboard con alertas de lecturas anómalas.','60c0e19e-75d8-4dd8-898a-02e7b6253610',0,NULL,2,NULL,'2026-05-16 18:55:05.698',NULL),('480d1f45-33e6-4afe-a0e0-fa189ae1ae2b','Microinversores en vez de string inverter. Microinversores por panel para mejor rendimiento en sombra parcial y monitoreo individual.','d1a2989d-903a-4667-91cd-408cc462648f',0,NULL,2,NULL,'2026-05-16 18:55:05.543',NULL),('491334d5-2288-4d22-9eb3-794a327bdc00','Compostera con sistema de aireación pasiva. Diseño que usa convección natural para oxigenar el compost sin necesidad de volteo manual.','193f5b52-1c15-4def-83bc-d3bdd760c992',0,NULL,7,NULL,'2026-05-16 18:55:05.493',NULL),('4f7b0a27-a9ca-412f-973a-ad19ae05c5fe','MLflow model registry con versionado automático. Configurar MLflow para registro automático de modelos entrenados, versionado semántico y stage transitions (staging → production).','60c0e19e-75d8-4dd8-898a-02e7b6253610',0,NULL,1,NULL,'2026-05-16 18:55:05.427',NULL),('505396d7-cbe0-4b0b-8ae1-7d45e36ac9ac','Server Components con streaming SSR. Implementar React Server Components para la página principal, reduciendo JS enviado al cliente en 60%.','c3888834-11ca-4e59-a693-1a557aea49fa',0,NULL,3,NULL,'2026-05-16 18:55:05.324',NULL),('5ed3e03b-aa93-4e48-a5d1-484a57e64a08','Dashboard médico con alertas configurables. Dashboard React con thresholds configurables por médico y alertas SMS/email para valores críticos.','a77f4b7f-12f3-4ab2-9860-1b3acbedb622',0,NULL,2,NULL,'2026-05-16 18:55:05.717',NULL),('66a8aa5b-b8c3-44ef-9d89-4ee8ed018821','GitHub Actions con matriz de tests paralelos. Configurar jobs paralelos para unit, integration y e2e tests con caching inteligente de dependencias.','835ec2b6-c416-4218-bced-ead9433c32c1',0,NULL,6,NULL,'2026-05-16 18:55:05.272',NULL),('7046ee83-5abd-4aed-81ba-2b8f2d36a771','API de datos anonimizados para investigadores. API REST con acceso controlado por token para investigadores autorizados con documentación OpenAPI.','6fe69220-33e9-4c86-8e5d-b8ba924c5962',1,NULL,2,NULL,'2026-05-16 18:55:05.816',NULL),('7516665e-c0ca-4396-998a-e51e2e79a3e5','Política de dependencias seguras. Automatizar npm audit + dependabot con política de actualización obligatoria para critical/high.','08e75fbf-4a4b-4b80-8362-b96c60bacad7',1,NULL,3,NULL,'2026-05-16 18:55:05.371',NULL),('826861be-f465-405f-b375-79fd13660a06','Cuestionario PHQ-9 y GAD-7 digital. Implementar screening automatizado de depresión y ansiedad antes de cada consulta con scoring automático.','60c0e19e-75d8-4dd8-898a-02e7b6253610',0,NULL,13,NULL,'2026-05-16 18:55:05.674',NULL),('8a0535c0-2a46-48cb-abf1-41971d803ea2','Sensor de humedad IoT con Arduino. Automatizar el riego con sensores de humedad de suelo conectados por LoRaWAN a un controlador central.','2cce65d3-4489-40fc-9689-760f97e29a32',0,NULL,8,NULL,'2026-05-16 18:55:05.479',NULL),('9264f0e2-80be-43d9-a470-fbb931bc388a','Dashboard de latencia por endpoint. Grafana dashboard con percentiles p50/p95/p99 por endpoint, tasa de errores 4xx/5xx.','9e4c07a8-0780-44de-bc68-0cb821539d00',0,NULL,1,NULL,'2026-05-16 18:55:05.336',NULL),('96e31074-2df2-4868-b024-9fce17fca069','Encuesta de dolor y movilidad semanal. Formulario digital semanal para pacientes con escala EVA de dolor y medición de rango de movimiento.','cdb2ed1b-e73f-4994-8600-738cbd515f5e',1,NULL,3,NULL,'2026-05-16 18:55:05.774',NULL),('ac671741-073c-47a5-ac72-71ae8fd9802a','Catálogo digital con QR codes. Cada sobre de semilla con QR que lleva a ficha técnica con origen, fecha de recolección y tasa de germinación.','821731f9-06bc-47e8-ad1e-d6c95427ef14',1,NULL,1,NULL,'2026-05-16 18:55:05.556',NULL),('b150a720-5d57-44bb-a241-63a45e0bf435','Integración con Zoom Web SDK. Usar Zoom Web SDK para videoconsultas con encriptación end-to-end y sala de espera virtual.','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8',0,NULL,7,NULL,'2026-05-16 18:55:05.632',NULL),('b60af311-0859-42b1-a53b-7668a53dbfca','Historial clínico FHIR-compatible. Implementar HL7 FHIR R4 para interoperabilidad con sistemas hospitalarios y exportación de datos.','60c0e19e-75d8-4dd8-898a-02e7b6253610',0,NULL,9,NULL,'2026-05-16 18:55:05.650',NULL),('bcf88686-6953-4fea-8464-06043304ec04','Dashboard de epidemiología con Tableau. Dashboard interactivo con mapas de calor de incidencia por sector, tasas por grupo etario y tendencias temporales.','a77f4b7f-12f3-4ab2-9860-1b3acbedb622',1,NULL,2,NULL,'2026-05-16 18:55:05.799',NULL),('d0c53a70-ba5f-4091-bff8-9baea638e65c','Feature store con Feast para reutilizar features. Implementar Feast como feature store para compartir features entre modelos de ML evitando training-serving skew.','9e4c07a8-0780-44de-bc68-0cb821539d00',0,NULL,2,NULL,'2026-05-16 18:55:05.439',NULL),('d1539bc1-6c51-4340-ac81-5b302ebf5b80','Auditar contraste con axe-core y Lighthouse. Ejecutar auditoría automatizada de accesibilidad en todas las pantallas de la plataforma usando axe-core y Lighthouse CI.','f73b8593-2d52-4a8a-8201-58545e5371fb',0,NULL,1,NULL,'2026-05-16 18:55:05.829',NULL),('d6313e31-a55a-472d-91aa-d0195da83eab','Inoculante microbiano artesanal. Producir inoculante con microorganismos de bosque nativo para acelerar la descomposición del compost.','193f5b52-1c15-4def-83bc-d3bdd760c992',0,NULL,3,NULL,'2026-05-16 18:55:05.509',NULL),('d71ccfb7-2945-40e6-8a92-a812f33c75a9','Protocolo de test de germinación. Documentar protocolo estandarizado para test de germinación de cada especie con reporte de viabilidad.','821731f9-06bc-47e8-ad1e-d6c95427ef14',1,NULL,2,NULL,'2026-05-16 18:55:05.575',NULL),('d87c2dd7-1d19-4481-ba50-419b323bc961','Kit educativo \"Pequeño Compostador\". Kit didáctico para niños con compostera de mesa, guía ilustrada y semillas de girasol.','193f5b52-1c15-4def-83bc-d3bdd760c992',1,NULL,3,NULL,'2026-05-16 18:55:05.606',NULL),('e29b9788-3781-4453-b6ae-0284d03a5903','Guía de manejo de crisis en teleconsulta. Documentar protocolo paso a paso: reconocimiento de señales de alerta, contactos de emergencia, derivación.','821731f9-06bc-47e8-ad1e-d6c95427ef14',0,NULL,1,NULL,'2026-05-16 18:55:05.685',NULL),('fa599549-327f-4e12-8c5e-379478e7ded2','Paneles solares bifaciales. Usar paneles bifaciales para capturar luz reflejada del suelo y aumentar generación en un 15%.','edad98a4-7db3-4318-98ce-55eabab586ed',0,NULL,2,NULL,'2026-05-16 18:55:05.526',NULL),('fffa6f65-b4a8-47ca-9ee0-7a68bdbc23ee','Implementar navegación por teclado completa. Refactorizar todos los componentes interactivos para soporte completo de teclado: Tab, Enter, Escape, arrow keys con focus management.','f73b8593-2d52-4a8a-8201-58545e5371fb',0,NULL,3,NULL,'2026-05-16 18:55:05.842',NULL);
/*!40000 ALTER TABLE `Idea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IdeaLike`
--

DROP TABLE IF EXISTS `IdeaLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IdeaLike` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ideaId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IdeaLike_ideaId_userId_key` (`ideaId`,`userId`),
  KEY `IdeaLike_userId_fkey` (`userId`),
  CONSTRAINT `IdeaLike_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IdeaLike`
--

LOCK TABLES `IdeaLike` WRITE;
/*!40000 ALTER TABLE `IdeaLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `IdeaLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IdeaVote`
--

DROP TABLE IF EXISTS `IdeaVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IdeaVote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ideaId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `weight` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `IdeaVote_ideaId_userId_needId_key` (`ideaId`,`userId`,`needId`),
  KEY `IdeaVote_userId_fkey` (`userId`),
  CONSTRAINT `IdeaVote_ideaId_fkey` FOREIGN KEY (`ideaId`) REFERENCES `Idea` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `IdeaVote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IdeaVote`
--

LOCK TABLES `IdeaVote` WRITE;
/*!40000 ALTER TABLE `IdeaVote` DISABLE KEYS */;
INSERT INTO `IdeaVote` VALUES ('02c70e6e-a9ca-4d51-bd87-128954ea247c','b60af311-0859-42b1-a53b-7668a53dbfca','60c0e19e-75d8-4dd8-898a-02e7b6253610','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.783',1),('0924292f-4b95-48b7-8b5e-1dd18ace6f41','b60af311-0859-42b1-a53b-7668a53dbfca','705ea231-a674-446d-bc21-b4691320b409','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.757',1),('0fc6ba7f-728f-4f02-a228-52d588222cef','491334d5-2288-4d22-9eb3-794a327bdc00','2cce65d3-4489-40fc-9689-760f97e29a32','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.001',1),('10a9c9d3-4fef-416f-a176-cd8ff10709f1','8a0535c0-2a46-48cb-abf1-41971d803ea2','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.865',1),('10b6981f-57d6-4113-a502-97f7e2fc9ded','826861be-f465-405f-b375-79fd13660a06','c3888834-11ca-4e59-a693-1a557aea49fa','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:08.050',1),('110c9955-c489-4b5c-91b9-4cb9336ff394','505396d7-cbe0-4b0b-8ae1-7d45e36ac9ac','60c0e19e-75d8-4dd8-898a-02e7b6253610','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.317',1),('1272fea0-0296-4dc4-a1df-6cf99dcae26a','fffa6f65-b4a8-47ca-9ee0-7a68bdbc23ee','f73b8593-2d52-4a8a-8201-58545e5371fb','febb5616-18c5-410d-b163-cc11ee31e7e2','2026-05-16 18:55:08.526',1),('1bb2f189-6a10-40fb-838b-fd4a19502e3f','826861be-f465-405f-b375-79fd13660a06','cdb2ed1b-e73f-4994-8600-738cbd515f5e','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.869',1),('1f69785b-c147-4f79-a303-f1ec4b5fab68','d71ccfb7-2945-40e6-8a92-a812f33c75a9','2cce65d3-4489-40fc-9689-760f97e29a32','118a7f3c-d218-4900-8619-2aa3e84497a2','2026-05-16 18:55:07.380',1),('24349f70-489a-4f25-889a-75ac1c4efd36','491334d5-2288-4d22-9eb3-794a327bdc00','92a06db9-bd98-425b-bbd4-0002af7bbc09','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.092',1),('249097d7-01bd-4be7-9417-ca83efb84197','d6313e31-a55a-472d-91aa-d0195da83eab','193f5b52-1c15-4def-83bc-d3bdd760c992','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.172',1),('2617f72e-bcb0-4fd5-a48a-fa481ff21c0d','34bb5f4c-6564-4f82-9cc6-7367f104d45f','0f760741-02be-4c8d-a33f-99d6f7fc19bc','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.270',1),('2a50f7b2-46a2-4095-b267-11a8fd147bc6','b60af311-0859-42b1-a53b-7668a53dbfca','835ec2b6-c416-4218-bced-ead9433c32c1','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.709',1),('2c090fe3-a089-476e-bab2-60c059db2b90','3d82f6c3-a987-44fd-a8c1-32cc05208206','cdb2ed1b-e73f-4994-8600-738cbd515f5e','2f44c6f6-7cd7-4f8c-83e1-2ada83d2e682','2026-05-16 18:55:06.428',1),('2cd8c0dc-8089-47c8-999a-34c9d8ceddbd','34bb5f4c-6564-4f82-9cc6-7367f104d45f','b71a1f60-81c4-4d7a-af4a-a822b7826e1e','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.117',1),('2d4dbca8-9304-4177-aac2-ee2c7b4102bb','0272f1ef-3d67-41e5-9300-4870b6372707','08e75fbf-4a4b-4b80-8362-b96c60bacad7','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:06.026',1),('2fda3ec7-fa19-4ec2-9507-1573264e7116','66a8aa5b-b8c3-44ef-9d89-4ee8ed018821','0a258c6d-5917-4ed6-9555-a8dbd5706720','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:05.925',1),('30463195-7280-4377-b082-bba76d24977a','826861be-f465-405f-b375-79fd13660a06','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.970',1),('3331e435-f6b9-44c5-b18e-891435625877','bcf88686-6953-4fea-8464-06043304ec04','a77f4b7f-12f3-4ab2-9860-1b3acbedb622','7ad4a621-9571-48da-b9bc-ffcc83cf02ef','2026-05-16 18:55:08.394',1),('340e6abb-55ee-4e3a-8742-eb3ffd2ba4fd','491334d5-2288-4d22-9eb3-794a327bdc00','821731f9-06bc-47e8-ad1e-d6c95427ef14','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.069',1),('38aeb16e-e714-4085-bc0c-d212a9e49658','b150a720-5d57-44bb-a241-63a45e0bf435','9e4c07a8-0780-44de-bc68-0cb821539d00','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.626',1),('3c9177fc-cbb9-4bb2-b7d4-c9ed7c586895','34bb5f4c-6564-4f82-9cc6-7367f104d45f','6fe69220-33e9-4c86-8e5d-b8ba924c5962','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.095',1),('3ca95f51-0fc4-4b34-995b-8c4d633ed102','b60af311-0859-42b1-a53b-7668a53dbfca','6fe69220-33e9-4c86-8e5d-b8ba924c5962','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.797',1),('40d4b4d3-de36-470a-8e76-3ae1f8727ae4','3d82f6c3-a987-44fd-a8c1-32cc05208206','0f760741-02be-4c8d-a33f-99d6f7fc19bc','2f44c6f6-7cd7-4f8c-83e1-2ada83d2e682','2026-05-16 18:55:06.440',1),('41a23d2c-69be-4fb5-b166-0eeea9644b42','d0c53a70-ba5f-4091-bff8-9baea638e65c','f73b8593-2d52-4a8a-8201-58545e5371fb','e1a5e08b-ef72-46bb-9cd5-ba3b7c2b017e','2026-05-16 18:55:06.709',1),('42090c70-057e-434a-bc77-e91bccac8edf','34bb5f4c-6564-4f82-9cc6-7367f104d45f','edad98a4-7db3-4318-98ce-55eabab586ed','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.141',1),('424196b8-95f1-46f9-ac99-efe3c3b7adb1','3c254fee-71ce-4686-9e20-17347bf5c59d','a77f4b7f-12f3-4ab2-9860-1b3acbedb622','dd364b90-fa83-47bc-a84d-ea6fcfb44b1d','2026-05-16 18:55:08.286',1),('432bd1c8-f5f1-49f7-8bad-6a294a92e899','826861be-f465-405f-b375-79fd13660a06','f73b8593-2d52-4a8a-8201-58545e5371fb','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.919',1),('44244be2-a8fa-4e56-b478-e6375c588598','b60af311-0859-42b1-a53b-7668a53dbfca','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.771',1),('4749f2df-6a00-40dc-994e-8573f67d3f4f','0268a4b4-8032-470b-9ed7-6b91f70fad5d','835ec2b6-c416-4218-bced-ead9433c32c1','e1383440-1f6b-42bb-a618-4502121515e9','2026-05-16 18:55:06.393',1),('4a2147cd-3fee-4cdb-a7b7-51abaa40e23d','8a0535c0-2a46-48cb-abf1-41971d803ea2','c3888834-11ca-4e59-a693-1a557aea49fa','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.888',1),('4f5b7956-2477-4c3e-aae0-674524f71209','66a8aa5b-b8c3-44ef-9d89-4ee8ed018821','cdb2ed1b-e73f-4994-8600-738cbd515f5e','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:05.862',1),('4ff6ca73-d694-463f-a4ec-fbdc87dd4ca4','826861be-f465-405f-b375-79fd13660a06','835ec2b6-c416-4218-bced-ead9433c32c1','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.826',1),('53de332e-28e7-44f0-a1a7-35ca42030113','43588f35-e929-4e77-a894-3f74a6d551b1','6fe69220-33e9-4c86-8e5d-b8ba924c5962','6a02e444-4259-455f-807e-4162b63e048a','2026-05-16 18:55:06.563',1),('54768b29-aea4-471a-94ed-2302dc45ebb5','d87c2dd7-1d19-4481-ba50-419b323bc961','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','c3cefd29-f444-46c8-9aad-e43d3fa26185','2026-05-16 18:55:07.412',1),('58ba86b7-7e2d-47a1-ae4b-6c66de3e2297','bcf88686-6953-4fea-8464-06043304ec04','821731f9-06bc-47e8-ad1e-d6c95427ef14','7ad4a621-9571-48da-b9bc-ffcc83cf02ef','2026-05-16 18:55:08.409',1),('58db974e-0ea2-4425-ac17-938599d70066','8a0535c0-2a46-48cb-abf1-41971d803ea2','edad98a4-7db3-4318-98ce-55eabab586ed','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.917',1),('5fa5889c-b84b-4539-b698-8ce2c2a6f3b6','3144cee8-c37c-44bf-bbcc-36d84636da68','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.815',1),('62ec7d33-6d92-47a7-93b5-e69dcb101f75','0268a4b4-8032-470b-9ed7-6b91f70fad5d','0f760741-02be-4c8d-a33f-99d6f7fc19bc','e1383440-1f6b-42bb-a618-4502121515e9','2026-05-16 18:55:06.405',1),('65d6b773-5b01-4e67-86b3-c47d76934304','505396d7-cbe0-4b0b-8ae1-7d45e36ac9ac','a8f9dba7-2d27-404c-87a7-23916748ba03','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.307',1),('663bdc5c-b0be-47ac-b9b7-5c45be08e0af','b150a720-5d57-44bb-a241-63a45e0bf435','f73b8593-2d52-4a8a-8201-58545e5371fb','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.639',1),('669bfda2-89e6-40c2-be92-58ba0b0739b1','b150a720-5d57-44bb-a241-63a45e0bf435','0a258c6d-5917-4ed6-9555-a8dbd5706720','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.555',1),('692e3eeb-adf0-4361-9a42-f95c5f894591','fffa6f65-b4a8-47ca-9ee0-7a68bdbc23ee','b71a1f60-81c4-4d7a-af4a-a822b7826e1e','febb5616-18c5-410d-b163-cc11ee31e7e2','2026-05-16 18:55:08.507',1),('6a155064-09ff-42e8-a7c3-66ffe5be6387','fa599549-327f-4e12-8c5e-379478e7ded2','92a06db9-bd98-425b-bbd4-0002af7bbc09','e727b722-729d-4a4b-845c-4a3402af0296','2026-05-16 18:55:07.232',1),('6dedbcf4-2d99-49d4-a565-6eddd047c1bb','96e31074-2df2-4868-b024-9fce17fca069','9e4c07a8-0780-44de-bc68-0cb821539d00','dd364b90-fa83-47bc-a84d-ea6fcfb44b1d','2026-05-16 18:55:08.360',1),('6f5a76e1-e11f-47c8-8649-972e47b1d655','34bb5f4c-6564-4f82-9cc6-7367f104d45f','a8f9dba7-2d27-404c-87a7-23916748ba03','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.084',1),('71a06633-59a2-44a3-b25f-3440fba8498f','7516665e-c0ca-4396-998a-e51e2e79a3e5','835ec2b6-c416-4218-bced-ead9433c32c1','2f44c6f6-7cd7-4f8c-83e1-2ada83d2e682','2026-05-16 18:55:06.481',1),('783bd893-3e82-4a55-822d-5f1eded55736','505396d7-cbe0-4b0b-8ae1-7d45e36ac9ac','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.298',1),('79e34ea4-ce47-4613-a496-48dc107ef473','480d1f45-33e6-4afe-a0e0-fa189ae1ae2b','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','e727b722-729d-4a4b-845c-4a3402af0296','2026-05-16 18:55:07.283',1),('7a10a953-3d8c-4bb5-911a-756cf6015820','e29b9788-3781-4453-b6ae-0284d03a5903','92a06db9-bd98-425b-bbd4-0002af7bbc09','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:08.096',1),('7a2c1021-0689-4c4b-bd6e-154dbf09279b','826861be-f465-405f-b375-79fd13660a06','92a06db9-bd98-425b-bbd4-0002af7bbc09','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.994',1),('7c0b39ae-5504-4f93-b6ba-7ea03754ce92','9264f0e2-80be-43d9-a470-fbb931bc388a','9e4c07a8-0780-44de-bc68-0cb821539d00','e1383440-1f6b-42bb-a618-4502121515e9','2026-05-16 18:55:06.344',1),('7cc159d8-2b9e-4c10-9bdd-150443397c7a','96e31074-2df2-4868-b024-9fce17fca069','821731f9-06bc-47e8-ad1e-d6c95427ef14','dd364b90-fa83-47bc-a84d-ea6fcfb44b1d','2026-05-16 18:55:08.333',1),('8217e1f9-04d4-4a6c-ae26-60261c7663f3','5ed3e03b-aa93-4e48-a5d1-484a57e64a08','b71a1f60-81c4-4d7a-af4a-a822b7826e1e','16f6ba8b-2e36-4a44-bb95-d15dd6065e9a','2026-05-16 18:55:08.196',1),('883a696f-0644-4c17-8334-c3cb725ae291','d1539bc1-6c51-4340-ac81-5b302ebf5b80','92a06db9-bd98-425b-bbd4-0002af7bbc09','febb5616-18c5-410d-b163-cc11ee31e7e2','2026-05-16 18:55:08.473',1),('8ab2ca04-fa9f-408d-87b9-c0090489c897','3144cee8-c37c-44bf-bbcc-36d84636da68','c3888834-11ca-4e59-a693-1a557aea49fa','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.737',1),('8b762a43-b474-46f2-950a-d242231b8f98','34bb5f4c-6564-4f82-9cc6-7367f104d45f','f73b8593-2d52-4a8a-8201-58545e5371fb','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.252',1),('8c937451-3002-40e8-b03c-7bf2e29a4f7c','0272f1ef-3d67-41e5-9300-4870b6372707','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:06.038',1),('8f634f2e-40eb-4219-b3ae-230ad8d820d7','3c254fee-71ce-4686-9e20-17347bf5c59d','92a06db9-bd98-425b-bbd4-0002af7bbc09','dd364b90-fa83-47bc-a84d-ea6fcfb44b1d','2026-05-16 18:55:08.266',1),('91991d69-21af-44ce-8b36-d96d64d702c3','0b82d793-f5ca-4e47-9fb4-dc2683170940','835ec2b6-c416-4218-bced-ead9433c32c1','6a02e444-4259-455f-807e-4162b63e048a','2026-05-16 18:55:06.611',1),('965e80ab-c823-4bef-beab-2b0e92d93d94','7516665e-c0ca-4396-998a-e51e2e79a3e5','c3888834-11ca-4e59-a693-1a557aea49fa','2f44c6f6-7cd7-4f8c-83e1-2ada83d2e682','2026-05-16 18:55:06.495',1),('977ae26e-e315-4d3f-be47-832c3abc0e16','3144cee8-c37c-44bf-bbcc-36d84636da68','821731f9-06bc-47e8-ad1e-d6c95427ef14','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.773',1),('9b32405f-3654-41fc-8167-0ae5b772c254','b60af311-0859-42b1-a53b-7668a53dbfca','c3888834-11ca-4e59-a693-1a557aea49fa','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.720',1),('9c9c97b2-1cb5-49f2-82df-777fd619064c','34bb5f4c-6564-4f82-9cc6-7367f104d45f','9e4c07a8-0780-44de-bc68-0cb821539d00','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.177',1),('9cb357e7-410e-4a61-86db-9c884d2dd554','66a8aa5b-b8c3-44ef-9d89-4ee8ed018821','705ea231-a674-446d-bc21-b4691320b409','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:05.949',1),('9f358f5f-bfc8-4bb4-8882-623bd0186a90','3c254fee-71ce-4686-9e20-17347bf5c59d','c3888834-11ca-4e59-a693-1a557aea49fa','dd364b90-fa83-47bc-a84d-ea6fcfb44b1d','2026-05-16 18:55:08.227',1),('9f695f3b-4597-4c26-9c62-2f36e718bbed','7046ee83-5abd-4aed-81ba-2b8f2d36a771','6fe69220-33e9-4c86-8e5d-b8ba924c5962','7ad4a621-9571-48da-b9bc-ffcc83cf02ef','2026-05-16 18:55:08.445',1),('a2bd79c2-9528-4696-ab3f-bfec30200ad2','393f8b94-b2a5-477f-b821-214437dfc5cf','92a06db9-bd98-425b-bbd4-0002af7bbc09','c3cefd29-f444-46c8-9aad-e43d3fa26185','2026-05-16 18:55:07.495',1),('a33a9443-643b-4f8c-ba28-cd9fdbf1ace7','826861be-f465-405f-b375-79fd13660a06','821731f9-06bc-47e8-ad1e-d6c95427ef14','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.845',1),('a58b0cbf-fa8d-43ac-9828-d748d095d1c9','480d1f45-33e6-4afe-a0e0-fa189ae1ae2b','821731f9-06bc-47e8-ad1e-d6c95427ef14','e727b722-729d-4a4b-845c-4a3402af0296','2026-05-16 18:55:07.272',1),('a7129b54-1084-459b-b974-3caa8bde0aca','b60af311-0859-42b1-a53b-7668a53dbfca','cdb2ed1b-e73f-4994-8600-738cbd515f5e','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.733',1),('a8196c26-7de1-4ef5-8ebe-be4b55ac8f7f','4714b46c-912c-4229-b04c-83dbefbb10a8','821731f9-06bc-47e8-ad1e-d6c95427ef14','16f6ba8b-2e36-4a44-bb95-d15dd6065e9a','2026-05-16 18:55:08.126',1),('a960bcda-f350-4dcb-84f0-f726933e449c','4714b46c-912c-4229-b04c-83dbefbb10a8','705ea231-a674-446d-bc21-b4691320b409','16f6ba8b-2e36-4a44-bb95-d15dd6065e9a','2026-05-16 18:55:08.151',1),('aaac9af5-d291-42c1-a775-f030f0269d20','826861be-f465-405f-b375-79fd13660a06','6fe69220-33e9-4c86-8e5d-b8ba924c5962','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.903',1),('ac7ae659-f8ae-4d17-bf22-20612786b08b','393f8b94-b2a5-477f-b821-214437dfc5cf','c3888834-11ca-4e59-a693-1a557aea49fa','c3cefd29-f444-46c8-9aad-e43d3fa26185','2026-05-16 18:55:07.478',1),('ae08fb1b-e78c-4c31-a801-6fd0c7c9c28d','8a0535c0-2a46-48cb-abf1-41971d803ea2','193f5b52-1c15-4def-83bc-d3bdd760c992','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.854',1),('b15a11ef-c9c8-40d7-86ec-beb8d4ace9e6','34bb5f4c-6564-4f82-9cc6-7367f104d45f','0a258c6d-5917-4ed6-9555-a8dbd5706720','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.129',1),('b4491d4d-5983-4467-a360-c0237f6dfb76','3144cee8-c37c-44bf-bbcc-36d84636da68','d1a2989d-903a-4667-91cd-408cc462648f','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.803',1),('b8ac696f-b8cb-4649-b7da-3f5e05df87fc','8a0535c0-2a46-48cb-abf1-41971d803ea2','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.934',1),('b91e12e8-0903-4715-ab5a-b48527d4970d','826861be-f465-405f-b375-79fd13660a06','60c0e19e-75d8-4dd8-898a-02e7b6253610','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:08.026',1),('b989d803-c200-486c-a202-1c4aeb13c8f2','491334d5-2288-4d22-9eb3-794a327bdc00','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.080',1),('ba66fc30-a98c-4880-a2ed-826a9f7a46fa','b150a720-5d57-44bb-a241-63a45e0bf435','821731f9-06bc-47e8-ad1e-d6c95427ef14','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.598',1),('bb5dbe8a-5c66-4dba-b7ef-ca638c8b0bf6','d0c53a70-ba5f-4091-bff8-9baea638e65c','edad98a4-7db3-4318-98ce-55eabab586ed','e1a5e08b-ef72-46bb-9cd5-ba3b7c2b017e','2026-05-16 18:55:06.684',1),('bcdb2039-1ee9-4705-a38b-3f0329d3aae8','491334d5-2288-4d22-9eb3-794a327bdc00','193f5b52-1c15-4def-83bc-d3bdd760c992','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.025',1),('bdd5cbc9-7ef2-4044-beb8-1aa391a51331','d6313e31-a55a-472d-91aa-d0195da83eab','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.136',1),('bdef1b75-cc0b-4f24-9368-e06af9747ae9','826861be-f465-405f-b375-79fd13660a06','9e4c07a8-0780-44de-bc68-0cb821539d00','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.957',1),('be12a32b-1713-4d09-bba6-2894054687e9','0272f1ef-3d67-41e5-9300-4870b6372707','a8f9dba7-2d27-404c-87a7-23916748ba03','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:05.982',1),('be6c2964-f3b5-4f70-9d4c-90b1df870198','3144cee8-c37c-44bf-bbcc-36d84636da68','edad98a4-7db3-4318-98ce-55eabab586ed','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.755',1),('c0b0c7c2-af03-466c-a38d-b1d96f80fb63','ac671741-073c-47a5-ac72-71ae8fd9802a','92a06db9-bd98-425b-bbd4-0002af7bbc09','118a7f3c-d218-4900-8619-2aa3e84497a2','2026-05-16 18:55:07.342',1),('c27d1ea8-38cb-4de4-9040-36a6db4d9962','d87c2dd7-1d19-4481-ba50-419b323bc961','d1a2989d-903a-4667-91cd-408cc462648f','c3cefd29-f444-46c8-9aad-e43d3fa26185','2026-05-16 18:55:07.448',1),('c3794891-19f9-47f7-9dbc-1a5507d08cf2','491334d5-2288-4d22-9eb3-794a327bdc00','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.014',1),('c468e78b-c9fe-40ea-bceb-518a06f14923','66a8aa5b-b8c3-44ef-9d89-4ee8ed018821','f73b8593-2d52-4a8a-8201-58545e5371fb','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:05.913',1),('c6646cea-d485-490d-842a-c29d19fbddf0','34bb5f4c-6564-4f82-9cc6-7367f104d45f','60c0e19e-75d8-4dd8-898a-02e7b6253610','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.195',1),('c68e4f89-93b3-4c89-8edc-9bbccbcac33b','0268a4b4-8032-470b-9ed7-6b91f70fad5d','0a258c6d-5917-4ed6-9555-a8dbd5706720','e1383440-1f6b-42bb-a618-4502121515e9','2026-05-16 18:55:06.383',1),('c7b2d001-645a-4fab-b074-099cc737c473','7046ee83-5abd-4aed-81ba-2b8f2d36a771','0a258c6d-5917-4ed6-9555-a8dbd5706720','7ad4a621-9571-48da-b9bc-ffcc83cf02ef','2026-05-16 18:55:08.428',1),('cb93868c-6698-4484-a7b0-cf259a7cde2c','34bb5f4c-6564-4f82-9cc6-7367f104d45f','835ec2b6-c416-4218-bced-ead9433c32c1','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.159',1),('cba96013-a96c-473e-a308-e67fe50bfa0a','d6313e31-a55a-472d-91aa-d0195da83eab','2cce65d3-4489-40fc-9689-760f97e29a32','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.147',1),('d20123e9-ae1f-4646-881f-8ad3a9865468','b60af311-0859-42b1-a53b-7668a53dbfca','b71a1f60-81c4-4d7a-af4a-a822b7826e1e','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.686',1),('d35950f8-9a65-4867-bd29-a98c9693f07e','0272f1ef-3d67-41e5-9300-4870b6372707','cdb2ed1b-e73f-4994-8600-738cbd515f5e','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:06.049',1),('d448ca7a-51b9-470b-9a21-a68830c8cfb1','d87c2dd7-1d19-4481-ba50-419b323bc961','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','c3cefd29-f444-46c8-9aad-e43d3fa26185','2026-05-16 18:55:07.429',1),('d4b6df73-3d0d-4a0f-a8ad-e5fb12f7920c','826861be-f465-405f-b375-79fd13660a06','a77f4b7f-12f3-4ab2-9860-1b3acbedb622','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.981',1),('d5f03f92-2c62-42c6-b0c0-cdd3d48e2456','0272f1ef-3d67-41e5-9300-4870b6372707','835ec2b6-c416-4218-bced-ead9433c32c1','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:06.008',1),('d9f01c00-f182-4ea4-bed1-1f2d1beb30d3','3144cee8-c37c-44bf-bbcc-36d84636da68','193f5b52-1c15-4def-83bc-d3bdd760c992','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.791',1),('db312c00-0f52-43a5-810d-70d6018e5ead','5ed3e03b-aa93-4e48-a5d1-484a57e64a08','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','16f6ba8b-2e36-4a44-bb95-d15dd6065e9a','2026-05-16 18:55:08.177',1),('db9cc1f8-1f30-45ff-ae88-761f2cff0438','826861be-f465-405f-b375-79fd13660a06','705ea231-a674-446d-bc21-b4691320b409','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.944',1),('dcc8cf76-8ae2-4938-b68a-5a0a4205fdb1','34bb5f4c-6564-4f82-9cc6-7367f104d45f','705ea231-a674-446d-bc21-b4691320b409','84c734dd-46b9-4867-82d6-5c1aa0794c5f','2026-05-16 18:55:06.214',1),('e2300504-1744-465e-b7e0-66d5a92270c4','8a0535c0-2a46-48cb-abf1-41971d803ea2','821731f9-06bc-47e8-ad1e-d6c95427ef14','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.877',1),('e3041319-bc51-4854-94af-dad3b82850b1','fa599549-327f-4e12-8c5e-379478e7ded2','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','e727b722-729d-4a4b-845c-4a3402af0296','2026-05-16 18:55:07.248',1),('e5831bfe-8a20-418a-b532-24a63a633ce4','d71ccfb7-2945-40e6-8a92-a812f33c75a9','92a06db9-bd98-425b-bbd4-0002af7bbc09','118a7f3c-d218-4900-8619-2aa3e84497a2','2026-05-16 18:55:07.369',1),('e591edcd-7cb5-4aaa-ad1a-db3da3d51a8d','4f7b0a27-a9ca-412f-973a-ad19ae05c5fe','c3888834-11ca-4e59-a693-1a557aea49fa','e1a5e08b-ef72-46bb-9cd5-ba3b7c2b017e','2026-05-16 18:55:06.642',1),('e5e81a05-c14a-43b4-8995-da39d625201f','491334d5-2288-4d22-9eb3-794a327bdc00','edad98a4-7db3-4318-98ce-55eabab586ed','0bc6096d-63d5-4a13-8be7-4e3fb2eb9bb2','2026-05-16 18:55:07.050',1),('e6335a23-264e-49a2-8f4c-beabe42ab3c2','96e31074-2df2-4868-b024-9fce17fca069','92a06db9-bd98-425b-bbd4-0002af7bbc09','dd364b90-fa83-47bc-a84d-ea6fcfb44b1d','2026-05-16 18:55:08.347',1),('e6b9ae85-ec95-4ae9-98b0-9c4ecfd74e08','fffa6f65-b4a8-47ca-9ee0-7a68bdbc23ee','0a258c6d-5917-4ed6-9555-a8dbd5706720','febb5616-18c5-410d-b163-cc11ee31e7e2','2026-05-16 18:55:08.518',1),('e70f5afe-26af-4b62-b88b-d5f301112c87','8a0535c0-2a46-48cb-abf1-41971d803ea2','d1a2989d-903a-4667-91cd-408cc462648f','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.953',1),('ec0b0877-ce64-4a0e-8795-a5b5d559c8b0','b150a720-5d57-44bb-a241-63a45e0bf435','a77f4b7f-12f3-4ab2-9860-1b3acbedb622','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.657',1),('ee4c4720-d24a-4751-b49a-57862ce3fae1','8a0535c0-2a46-48cb-abf1-41971d803ea2','92a06db9-bd98-425b-bbd4-0002af7bbc09','7ac97520-01b5-423f-b2d5-c03b5e212a26','2026-05-16 18:55:06.976',1),('f0514ead-1919-4ac3-9787-ead389751b14','7516665e-c0ca-4396-998a-e51e2e79a3e5','6fe69220-33e9-4c86-8e5d-b8ba924c5962','2f44c6f6-7cd7-4f8c-83e1-2ada83d2e682','2026-05-16 18:55:06.509',1),('f1a79815-34cc-4e25-b870-d8f899c1fbcd','826861be-f465-405f-b375-79fd13660a06','0a258c6d-5917-4ed6-9555-a8dbd5706720','6562e1da-12aa-4739-993c-5e3adc9e045f','2026-05-16 18:55:07.888',1),('f51faab4-6c6d-4964-b1e0-115eb557d719','b150a720-5d57-44bb-a241-63a45e0bf435','0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.530',1),('f5cd5828-6ad2-471d-8058-38f3a8438f84','66a8aa5b-b8c3-44ef-9d89-4ee8ed018821','39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:05.882',1),('f67a315d-485e-44f7-8e04-d27bfdc788b8','43588f35-e929-4e77-a894-3f74a6d551b1','0a258c6d-5917-4ed6-9555-a8dbd5706720','6a02e444-4259-455f-807e-4162b63e048a','2026-05-16 18:55:06.545',1),('fa3b0e30-1f02-4f5b-8e93-e6dd6ec61880','66a8aa5b-b8c3-44ef-9d89-4ee8ed018821','9e4c07a8-0780-44de-bc68-0cb821539d00','ec1a42c3-eeae-40fb-b8fd-7e102fd5f341','2026-05-16 18:55:05.938',1),('fd209a16-1dc3-4b20-b8b0-9a740a75c15f','0b82d793-f5ca-4e47-9fb4-dc2683170940','9e4c07a8-0780-44de-bc68-0cb821539d00','6a02e444-4259-455f-807e-4162b63e048a','2026-05-16 18:55:06.587',1),('fea67f58-3784-47e0-8be3-61ea4b96bcb3','b150a720-5d57-44bb-a241-63a45e0bf435','cdb2ed1b-e73f-4994-8600-738cbd515f5e','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.574',1),('fef55fe6-8351-4609-ac5e-68c57172ecb8','b60af311-0859-42b1-a53b-7668a53dbfca','92a06db9-bd98-425b-bbd4-0002af7bbc09','7f433faa-fd6f-4099-b270-29a8051d85e7','2026-05-16 18:55:07.697',1);
/*!40000 ALTER TABLE `IdeaVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InterviewInvitation`
--

DROP TABLE IF EXISTS `InterviewInvitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InterviewInvitation` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senderId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipientId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDING','ACCEPTED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `respondedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `InterviewInvitation_recipientId_status_idx` (`recipientId`,`status`),
  KEY `InterviewInvitation_senderId_idx` (`senderId`),
  CONSTRAINT `InterviewInvitation_recipientId_fkey` FOREIGN KEY (`recipientId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InterviewInvitation`
--

LOCK TABLES `InterviewInvitation` WRITE;
/*!40000 ALTER TABLE `InterviewInvitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `InterviewInvitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InvestmentMatch`
--

DROP TABLE IF EXISTS `InvestmentMatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvestmentMatch` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `investorTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seekerTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `revenueShare` double DEFAULT NULL,
  `termMonths` int DEFAULT NULL,
  `investmentType` enum('REVENUE_SHARE','LOAN','EQUITY') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REVENUE_SHARE',
  `status` enum('PROPOSED','ACCEPTED','NEGOTIATING','ACTIVE','COMPLETED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROPOSED',
  `proposedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptedAt` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `InvestmentMatch_investorTreeId_idx` (`investorTreeId`),
  KEY `InvestmentMatch_seekerTreeId_idx` (`seekerTreeId`),
  KEY `InvestmentMatch_status_idx` (`status`),
  CONSTRAINT `InvestmentMatch_investorTreeId_fkey` FOREIGN KEY (`investorTreeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `InvestmentMatch_seekerTreeId_fkey` FOREIGN KEY (`seekerTreeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvestmentMatch`
--

LOCK TABLES `InvestmentMatch` WRITE;
/*!40000 ALTER TABLE `InvestmentMatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `InvestmentMatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InvestmentRating`
--

DROP TABLE IF EXISTS `InvestmentRating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `InvestmentRating` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `raterTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ratedTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `InvestmentRating_matchId_raterTreeId_key` (`matchId`,`raterTreeId`),
  KEY `InvestmentRating_ratedTreeId_idx` (`ratedTreeId`),
  CONSTRAINT `InvestmentRating_matchId_fkey` FOREIGN KEY (`matchId`) REFERENCES `InvestmentMatch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvestmentRating`
--

LOCK TABLES `InvestmentRating` WRITE;
/*!40000 ALTER TABLE `InvestmentRating` DISABLE KEYS */;
/*!40000 ALTER TABLE `InvestmentRating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LoginAttempt`
--

DROP TABLE IF EXISTS `LoginAttempt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LoginAttempt` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `LoginAttempt_userId_createdAt_idx` (`userId`,`createdAt`),
  CONSTRAINT `LoginAttempt_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LoginAttempt`
--

LOCK TABLES `LoginAttempt` WRITE;
/*!40000 ALTER TABLE `LoginAttempt` DISABLE KEYS */;
INSERT INTO `LoginAttempt` VALUES ('3da9e68c-3ace-4aae-8ab6-5be5ab861d59','471a81d1-2a9b-4fdf-8f30-116178eaf85b','127.0.0.1','2026-05-20 15:22:07.482');
/*!40000 ALTER TABLE `LoginAttempt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ManagedServer`
--

DROP TABLE IF EXISTS `ManagedServer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ManagedServer` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int NOT NULL DEFAULT '22',
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryptedKey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDING_VERIFICATION','ACTIVE','UNREACHABLE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING_VERIFICATION',
  `lastCheck` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `consecutiveFails` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ManagedServer_treeId_idx` (`treeId`),
  CONSTRAINT `ManagedServer_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ManagedServer`
--

LOCK TABLES `ManagedServer` WRITE;
/*!40000 ALTER TABLE `ManagedServer` DISABLE KEYS */;
/*!40000 ALTER TABLE `ManagedServer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MemberBalance`
--

DROP TABLE IF EXISTS `MemberBalance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MemberBalance` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memberId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `availableBalance` int NOT NULL DEFAULT '0',
  `pendingBalance` int NOT NULL DEFAULT '0',
  `stripeAccountId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MemberBalance_memberId_key` (`memberId`),
  CONSTRAINT `MemberBalance_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `TreeMember` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MemberBalance`
--

LOCK TABLES `MemberBalance` WRITE;
/*!40000 ALTER TABLE `MemberBalance` DISABLE KEYS */;
INSERT INTO `MemberBalance` VALUES ('8e7bb956-b87c-465b-b7ae-046025ccd9f3','367c23db-7007-4889-9c5c-2247db0185ce',10000,0,NULL,'2026-05-20 15:44:55.333','2026-05-20 15:48:26.320');
/*!40000 ALTER TABLE `MemberBalance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MemberSocialProfile`
--

DROP TABLE IF EXISTS `MemberSocialProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MemberSocialProfile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proposedNeedTopics` json NOT NULL,
  `votingPatterns` json NOT NULL,
  `taskCompletionRate` double NOT NULL DEFAULT '0',
  `chatActivity` json NOT NULL,
  `contributionSummary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastAnalyzedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MemberSocialProfile_userId_treeId_key` (`userId`,`treeId`),
  KEY `MemberSocialProfile_treeId_idx` (`treeId`),
  CONSTRAINT `MemberSocialProfile_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `MemberSocialProfile_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MemberSocialProfile`
--

LOCK TABLES `MemberSocialProfile` WRITE;
/*!40000 ALTER TABLE `MemberSocialProfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `MemberSocialProfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Need`
--

DROP TABLE IF EXISTS `Need`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Need` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creatorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `importance` int DEFAULT NULL,
  `status` enum('OPEN','PENDING_APPROVAL','REJECTED','IN_PROGRESS','SATISFIED','CLOSED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `telegramMessageId` int DEFAULT NULL,
  `dailyVotes` int NOT NULL DEFAULT '0',
  `approvalMessageId` int DEFAULT NULL,
  `approvalPollId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isComplex` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Need_creatorId_fkey` (`creatorId`),
  KEY `Need_treeId_fkey` (`treeId`),
  CONSTRAINT `Need_creatorId_fkey` FOREIGN KEY (`creatorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Need_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Need`
--

LOCK TABLES `Need` WRITE;
/*!40000 ALTER TABLE `Need` DISABLE KEYS */;
/*!40000 ALTER TABLE `Need` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NeedFunding`
--

DROP TABLE IF EXISTS `NeedFunding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NeedFunding` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `NeedFunding_needId_fkey` (`needId`),
  CONSTRAINT `NeedFunding_needId_fkey` FOREIGN KEY (`needId`) REFERENCES `Need` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NeedFunding`
--

LOCK TABLES `NeedFunding` WRITE;
/*!40000 ALTER TABLE `NeedFunding` DISABLE KEYS */;
/*!40000 ALTER TABLE `NeedFunding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NeedIdea`
--

DROP TABLE IF EXISTS `NeedIdea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NeedIdea` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ideaId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchedBy` enum('USER','AI') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'AI',
  `matchScore` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `NeedIdea_needId_ideaId_key` (`needId`,`ideaId`),
  KEY `NeedIdea_ideaId_fkey` (`ideaId`),
  CONSTRAINT `NeedIdea_ideaId_fkey` FOREIGN KEY (`ideaId`) REFERENCES `Idea` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `NeedIdea_needId_fkey` FOREIGN KEY (`needId`) REFERENCES `Need` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NeedIdea`
--

LOCK TABLES `NeedIdea` WRITE;
/*!40000 ALTER TABLE `NeedIdea` DISABLE KEYS */;
/*!40000 ALTER TABLE `NeedIdea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NeedTree`
--

DROP TABLE IF EXISTS `NeedTree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NeedTree` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `NeedTree_needId_treeId_key` (`needId`,`treeId`),
  KEY `NeedTree_treeId_fkey` (`treeId`),
  CONSTRAINT `NeedTree_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NeedTree`
--

LOCK TABLES `NeedTree` WRITE;
/*!40000 ALTER TABLE `NeedTree` DISABLE KEYS */;
/*!40000 ALTER TABLE `NeedTree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('TASK_AUDIT','BUDGET_COMPLETE','LEVEL_UP','XP_GAIN','SKILL_UNLOCK','AVAL_RISK','TASK_ASSIGNED','TASK_COMPLETED','BRANCH_VOTE','GENERAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'GENERAL',
  `category` enum('URGENTE','FLUJO','MERITO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FLUJO',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityAction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Notification_userId_isRead_idx` (`userId`,`isRead`),
  KEY `Notification_userId_createdAt_idx` (`userId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PaymentSplit`
--

DROP TABLE IF EXISTS `PaymentSplit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PaymentSplit` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memberId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` double NOT NULL,
  `reason` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `PaymentSplit_needId_idx` (`needId`),
  KEY `PaymentSplit_memberId_idx` (`memberId`),
  CONSTRAINT `PaymentSplit_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `TreeMember` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `PaymentSplit_needId_fkey` FOREIGN KEY (`needId`) REFERENCES `Need` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PaymentSplit`
--

LOCK TABLES `PaymentSplit` WRITE;
/*!40000 ALTER TABLE `PaymentSplit` DISABLE KEYS */;
/*!40000 ALTER TABLE `PaymentSplit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PhaseDeliverable`
--

DROP TABLE IF EXISTS `PhaseDeliverable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PhaseDeliverable` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branchId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` enum('INVESTIGATION','DEVELOPMENT','PRODUCTION','DISTRIBUTION','MAINTENANCE','RECYCLING') COLLATE utf8mb4_unicode_ci NOT NULL,
  `deliverableUrl` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDING_REVIEW','COMPLETED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING_REVIEW',
  `initialXpAwarded` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PhaseDeliverable`
--

LOCK TABLES `PhaseDeliverable` WRITE;
/*!40000 ALTER TABLE `PhaseDeliverable` DISABLE KEYS */;
/*!40000 ALTER TABLE `PhaseDeliverable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PlantillaArbol`
--

DROP TABLE IF EXISTS `PlantillaArbol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PlantillaArbol` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icono` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `esGlobal` tinyint(1) NOT NULL DEFAULT '0',
  `creadorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configuracion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PlantillaArbol`
--

LOCK TABLES `PlantillaArbol` WRITE;
/*!40000 ALTER TABLE `PlantillaArbol` DISABLE KEYS */;
/*!40000 ALTER TABLE `PlantillaArbol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PlatformConfig`
--

DROP TABLE IF EXISTS `PlatformConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PlatformConfig` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `updatedAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PlatformConfig_key_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PlatformConfig`
--

LOCK TABLES `PlatformConfig` WRITE;
/*!40000 ALTER TABLE `PlatformConfig` DISABLE KEYS */;
INSERT INTO `PlatformConfig` VALUES ('426e2cb4-4fe1-11f1-9ad5-843a4b23a26c','free_period_months','2','Meses gratis para nuevos usuarios','margin','2026-05-14 18:07:12.000','2026-05-14 18:07:12.000'),('77f4f9ae-4fda-11f1-9ad5-843a4b23a26c','cost_salaries','5000','Sueldos del equipo','fixed','2026-05-14 18:07:12.000','2026-05-14 17:18:35.000'),('77f78848-4fda-11f1-9ad5-843a4b23a26c','cost_infrastructure','1200','Servidores, APIs, hosting','fixed','2026-05-14 18:07:12.000','2026-05-14 17:18:35.000'),('77fb44ad-4fda-11f1-9ad5-843a4b23a26c','cost_fixed','800','Electricidad, internet, oficina','fixed','2026-05-14 18:07:12.000','2026-05-14 17:18:35.000'),('77fcd038-4fda-11f1-9ad5-843a4b23a26c','cost_api_input_1m','0.27','Costo API — input 1M tokens (DeepSeek)','api_cost','2026-05-14 18:07:12.000','2026-05-14 17:18:35.000'),('77ffa174-4fda-11f1-9ad5-843a4b23a26c','cost_api_output_1m','1.10','Costo API — output 1M tokens (DeepSeek)','api_cost','2026-05-14 18:07:12.000','2026-05-14 17:18:35.000'),('7801888a-4fda-11f1-9ad5-843a4b23a26c','cost_openai_input_1m','2.50','Costo OpenAI — input 1M tokens','api_cost','2026-05-14 18:07:12.000','2026-05-14 17:18:36.000'),('7802f65a-4fda-11f1-9ad5-843a4b23a26c','cost_openai_output_1m','10.00','Costo OpenAI — output 1M tokens','api_cost','2026-05-14 18:07:12.000','2026-05-14 17:18:36.000'),('780471d7-4fda-11f1-9ad5-843a4b23a26c','cost_anthropic_input_1m','3.00','Costo Anthropic — input 1M tokens','api_cost','2026-05-14 18:07:12.000','2026-05-14 17:18:36.000'),('78064644-4fda-11f1-9ad5-843a4b23a26c','cost_anthropic_output_1m','15.00','Costo Anthropic — output 1M tokens','api_cost','2026-05-14 18:07:12.000','2026-05-14 17:18:36.000'),('7807fc21-4fda-11f1-9ad5-843a4b23a26c','growth_margin_pct','20','Margen de crecimiento (%)','margin','2026-05-14 18:07:12.000','2026-05-14 17:18:36.000');
/*!40000 ALTER TABLE `PlatformConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PollMapping`
--

DROP TABLE IF EXISTS `PollMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PollMapping` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pollId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chatId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PollMapping_pollId_key` (`pollId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PollMapping`
--

LOCK TABLES `PollMapping` WRITE;
/*!40000 ALTER TABLE `PollMapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `PollMapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PrivacySettings`
--

DROP TABLE IF EXISTS `PrivacySettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PrivacySettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `traceProfileVisibility` enum('PRIVATE','TREE_ONLY','TRUST_NETWORK','PUBLIC') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TREE_ONLY',
  `taskHistoryVisibility` enum('PRIVATE','TREE_ONLY','TRUST_NETWORK','PUBLIC') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PRIVATE',
  `evidenceVisibility` enum('PRIVATE','TREE_ONLY','TRUST_NETWORK','PUBLIC') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PRIVATE',
  `showInTalentSearch` tinyint(1) NOT NULL DEFAULT '0',
  `allowAggregatedMetrics` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PrivacySettings_userId_key` (`userId`),
  KEY `PrivacySettings_traceProfileVisibility_idx` (`traceProfileVisibility`),
  KEY `PrivacySettings_showInTalentSearch_idx` (`showInTalentSearch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PrivacySettings`
--

LOCK TABLES `PrivacySettings` WRITE;
/*!40000 ALTER TABLE `PrivacySettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `PrivacySettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PromiseP2P`
--

DROP TABLE IF EXISTS `PromiseP2P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PromiseP2P` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `currencyType` enum('FIAT','BERRY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDING','PAYMENT_SENT','COMPLETED','DISPUTED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `comprobanteUrl` text COLLATE utf8mb4_unicode_ci,
  `motivoCancelacion` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `PromiseP2P_taskId_idx` (`taskId`),
  KEY `PromiseP2P_sponsorId_idx` (`sponsorId`),
  CONSTRAINT `PromiseP2P_sponsorId_fkey` FOREIGN KEY (`sponsorId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PromiseP2P`
--

LOCK TABLES `PromiseP2P` WRITE;
/*!40000 ALTER TABLE `PromiseP2P` DISABLE KEYS */;
/*!40000 ALTER TABLE `PromiseP2P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rating`
--

DROP TABLE IF EXISTS `Rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Rating` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agentId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stars` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `crossTreeContribution` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `Rating_agentId_treeId_idx` (`agentId`,`treeId`),
  KEY `Rating_taskId_idx` (`taskId`),
  KEY `Rating_treeId_fkey` (`treeId`),
  CONSTRAINT `Rating_agentId_fkey` FOREIGN KEY (`agentId`) REFERENCES `Agent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Rating_agentId_treeId_fkey` FOREIGN KEY (`agentId`, `treeId`) REFERENCES `AgentMembership` (`agentId`, `treeId`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Rating_taskId_fkey` FOREIGN KEY (`taskId`) REFERENCES `Task` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Rating_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rating`
--

LOCK TABLES `Rating` WRITE;
/*!40000 ALTER TABLE `Rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `Rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RefreshToken`
--

DROP TABLE IF EXISTS `RefreshToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RefreshToken` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenHash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `revokedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `RefreshToken_tokenHash_key` (`tokenHash`),
  KEY `RefreshToken_userId_idx` (`userId`),
  KEY `RefreshToken_tokenHash_idx` (`tokenHash`),
  CONSTRAINT `RefreshToken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RefreshToken`
--

LOCK TABLES `RefreshToken` WRITE;
/*!40000 ALTER TABLE `RefreshToken` DISABLE KEYS */;
INSERT INTO `RefreshToken` VALUES ('00f0b59d-9b59-4b2f-99b8-51951429d484','4470173cbe8469721c2f1738e60218ce589101c91f5f79835e3d636d2722ff9a','4ba12ced-0fad-4aeb-af79-490873802100','2026-05-24 17:14:07.492',NULL,'2026-05-17 17:14:07.493'),('04bb14b0-9f51-40c0-82e2-84efb49624ad','dd8730f3b7fd05aab4176f5d633b804866dd43ec327ff24c1383fd25b1fe6d71','6fe69220-33e9-4c86-8e5d-b8ba924c5962','2026-05-23 19:27:36.778',NULL,'2026-05-16 19:27:36.779'),('05c73d36-8c0e-47ab-98ae-6d548c076747','bf7efe7d8e82543a12c62e0cf385116b219c4a557344ccec2e4009707ce2565d','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-20 12:50:40.914',NULL,'2026-05-13 12:50:40.915'),('068f3b83-5f6f-48ae-b60e-cc688f62a4d9','9c93a68460ea0733da448b9e1a6adc49ee212baff7a63446cee25b091a3364a1','0a93ae63-b3ec-435e-9700-1324132b047c','2026-05-26 13:44:48.249',NULL,'2026-05-19 13:44:48.250'),('076dc04f-6c19-4c59-b86e-56768464a99f','3fd0d09e3dbfbcde8125f91fa5d29520c7ba469bc4a5036bec8423d167e6033a','6fe69220-33e9-4c86-8e5d-b8ba924c5962','2026-05-23 18:55:45.649',NULL,'2026-05-16 18:55:45.650'),('081299a4-d86c-4ca8-a75a-41fd4ff74854','d2a576f53b4734796400525f1fd4d9b2f6f3dd5cc8b79cd393a4581b96a791b4','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:39:46.786',NULL,'2026-05-18 15:39:46.787'),('0ef830a9-2d33-4e9f-8b8a-9fef058839f7','c4721bada28e7da4e3fb43b97a47bbb11c76ea15e179eae610de0330d4d4e562','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-25 15:31:11.058',NULL,'2026-05-18 15:31:11.059'),('1d8c21f2-1c36-4a65-a3d1-5ee5e710d2fc','1d44d7f2dfee9b2bc6805ce7145bc005e4d4f0d00abf073da176e331e190cbc7','14f24111-6c3d-4ddc-9669-73d0d3703cd0','2026-05-20 13:22:31.229',NULL,'2026-05-13 13:22:31.230'),('20ec6d15-11fc-41ad-a00e-f2b9f4f0de6a','a6f0cb387980214678d9c5c054478a41f723728e6e6577ee8705c90bf548b58b','66c04512-b98e-48ef-b5ac-14386e21f0b8','2026-05-21 18:50:30.659',NULL,'2026-05-14 18:50:30.661'),('221dfaaf-870f-46d8-b29a-c09708703c62','c7cf6b4c849f718ff22421a5d4d4b9fc0ff901d53f764b8784e625bf7c2034ce','ca933a62-0228-412c-be01-9cfe4262c2d6','2026-05-26 14:36:57.309',NULL,'2026-05-19 14:36:57.310'),('23e7bf0a-ade7-4ed3-835a-bdd24889ee04','d66fd0c224101c1a1fd08e3c12ffe2d05e6cf9ff39db3c29bb1f48be691a26a4','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:16:56.148',NULL,'2026-05-13 13:16:56.149'),('25501624-2fb8-445b-ae40-a4cb8c83eb0b','16ee2485bb2a0e31508b6371c11e6b2c6694a2b9b1d90e1cc262591691c59935','78f7d145-ab6f-48f5-a836-c93a2c02fd52','2026-05-23 18:47:26.781',NULL,'2026-05-16 18:47:26.783'),('259c9211-1911-49cd-a3a4-b5d85e6f1ec7','34a1b2806997f7db060ebc9208030b370426e2ece41602f3fb8e7d7a96485595','e7d16ca7-0f65-412c-9e35-0ddd44c3d218','2026-05-26 14:24:59.393',NULL,'2026-05-19 14:24:59.394'),('25dffcf6-66d3-4ede-9a48-36406a86d559','68a033d4d64bbf0a1c40a78e7f596805d2d038fb4407ecc89d0909ab21adbcab','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:20:11.028',NULL,'2026-05-13 13:20:11.029'),('2a41d116-59a2-42fa-98ac-c70ad25abeec','818d7a35333414163e7042dc5bf16cf05e7cfa9c1c8c7ba525c12b07f7d028e5','14f24111-6c3d-4ddc-9669-73d0d3703cd0','2026-05-20 13:26:42.680',NULL,'2026-05-13 13:26:42.681'),('2cc49c1f-364e-4c04-a94f-b4b13335ad63','989cafdd787b270b19608f2a3a6c7875b41354865acaa6294ac9f2f12c161427','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:35:43.140',NULL,'2026-05-18 15:35:43.141'),('31c6db07-d532-41f1-b4e6-16df88178b67','32f699bfffd471bc38ed62c1914e2d69bb20af7661ad8bd86fbdd427e262e9d0','14f24111-6c3d-4ddc-9669-73d0d3703cd0','2026-05-20 13:22:31.070',NULL,'2026-05-13 13:22:31.071'),('34d01930-636c-49fc-a88f-29d6fc636d8d','4c9fa596b1f48ccc61b6221101d9f2787eeaf90bd23dbb91d5f88eb9e1c137bd','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-20 13:02:00.333',NULL,'2026-05-13 13:02:00.334'),('350d94a0-bbd4-4840-b219-aedd2b030d01','eea475f88a977fc77c96049b785ca1816312b132ba48fc020a6d543d76f56963','8d93fc6c-f486-49a9-9849-b58bc9201167','2026-05-26 14:02:13.551',NULL,'2026-05-19 14:02:13.551'),('397c0787-2135-49d8-a77e-295416bb19fb','f79617ca2cc609d9b19b24fcaa14ee87d88dd86eec1dfe494f4a4981a657d6a7','4cc9f888-516f-4847-94af-41ce5a1635e4','2026-05-25 15:39:47.259',NULL,'2026-05-18 15:39:47.260'),('3de7fd7d-8b99-4213-b315-46e80ca50e3f','69b2ce7340b9610fc62e50c0eed6d1cc12cfb7b355b078f21d1c831e0fc4c589','926fb090-82c5-4774-89cc-038682fd8994','2026-05-20 16:47:17.899',NULL,'2026-05-13 16:47:17.900'),('46720593-6358-44b5-bfaf-ad88d35da1e9','7ab05d88368281f407cc170e9a148022073cc058cf25780596ec49bf149042b6','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:25:08.389',NULL,'2026-05-13 13:25:08.390'),('4b06309f-c644-4f3b-8d55-6b405c0df09b','bf05f10db42a1469e8841ee7948f1c137b236110796cdab6f743111d0dcd690b','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:27:41.082',NULL,'2026-05-13 13:27:41.082'),('4b08becf-254e-456b-87a7-87991648e48d','db57a60aaf67caf59b06e9a2ff5a54f9133ae8b02acf1c305a7626b703a7e697','df7de8fb-e02c-4726-b896-0122cc86037c','2026-05-22 00:33:18.517',NULL,'2026-05-15 00:33:18.518'),('4c418c4c-4c48-4339-a431-00211b189dda','e3df4622daa2d5a3e5f7399409fd5410111b6b6752dfeb696fd9710dd7ac662e','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:42:36.079',NULL,'2026-05-18 15:42:36.079'),('4d57998a-f2aa-48bb-b6f7-5c1d838a1eec','cf8e815ed0015c1217cf502e695b2afc0da2505ef9fbcd03245518819931853b','e695c7d3-daf8-4643-a3bb-0881b5dceedd','2026-05-20 15:28:38.399',NULL,'2026-05-13 15:28:38.400'),('52224a17-d9f0-4ea6-b97e-90b6ee744f4e','ab5ac489db388e8503a51725a5e22d6edacadf77d88659203c863cf585153d05','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-20 13:19:25.495',NULL,'2026-05-13 13:19:25.496'),('57a0c84b-13b7-48a1-a02e-56be39380fb3','43974406cadd8139066aabd0cfe7b46d4961d6b2d2b0ec93f8950d76752f9f29','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-25 15:30:12.919',NULL,'2026-05-18 15:30:12.920'),('581c05ae-e436-4b1c-bdba-888941038215','5398c4edb55ce67dbb348f65d87f01aa4064dce80f4fe33f9b00b4fe44ca8a56','1533fbac-698c-42d7-a161-75f3434020f9','2026-05-22 05:03:29.514',NULL,'2026-05-15 05:03:29.515'),('5999b385-1e88-4ba1-80f0-d8b19f8cb0c6','b00d9340cb7916ed21c5a283ed0dd61ae6550a373c6b31f94e1064b4e5955847','0876799c-fd21-4da0-8c6b-e1fa4eb22376','2026-05-26 14:25:34.271',NULL,'2026-05-19 14:25:34.272'),('5f5336cd-806b-451f-b015-6ab2b7e7e39e','93f26e8b250fa2b120003f6c5f8939709e83f2a2c0f5cb97d0f8c0b67c70b2c7','9e44ddf5-bb54-4697-be45-e1a8f92b219e','2026-05-26 14:25:34.040',NULL,'2026-05-19 14:25:34.041'),('659d2d8b-1c3a-4fd4-b1f5-db9f7e2e9c8c','32f0ac81c6a730d2cba3e4f36574c26458715ab97c97fbb1290a36f345ac1eb5','a02529a7-ff2f-4189-8651-16af77d6646b','2026-05-22 05:00:26.293',NULL,'2026-05-15 05:00:26.294'),('6b370870-292e-4b9b-b205-377c870b172a','cae190a0dda725b94d24417ce9e6ed5aa61a520b2b27a2dafd0ecfb58d9c0bd8','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:34:51.097',NULL,'2026-05-18 15:34:51.098'),('6ceb60c6-9a2b-4f90-853d-48f5d0c6c4cd','e2001fa96570a3120952946a25d78fbcb24261cbb1e5a94fd8c6a9344c3e7f9a','c5d7f4f1-afbe-4cc7-aa67-81c82485d2a2','2026-05-23 14:34:19.421',NULL,'2026-05-16 14:34:19.422'),('6d5aa4c1-6f59-4771-9275-369c0642788a','1fee703a23b87b09b885d79dd6dafad59ff0f571bda256b72a0b6fc34c889f60','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:19:05.001',NULL,'2026-05-13 13:19:05.002'),('6de5e9a2-97b0-480a-938f-41907fb787b2','b3e74d0ef605b9a04ad4849529ad71651b25ff8d8015ff83b8e6c2c6353a1f31','e0712bee-a5e5-4a4e-b8f3-41b115d8bda9','2026-05-26 14:24:59.108',NULL,'2026-05-19 14:24:59.109'),('720b23f0-867c-4852-bec7-b7922f60bada','985f65129181bc712661d179f144906706838e0af48a45b6ca6be7781bcf2729','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:36:36.674',NULL,'2026-05-18 15:36:36.675'),('770882d1-3f53-4643-bd78-24021b620482','9fe5747bd9aaeecfe41586bc265416a483f943688abc784d2394153aa69e1e58','3f174e8e-5d21-434b-9705-68413394d778','2026-05-22 13:25:16.093',NULL,'2026-05-15 13:25:16.094'),('77f9ac29-b1d8-4cfb-8f60-b6d166c4d28e','15e097937fc6ea95d77fead1dd956f7b72500ebbf0e9b01fb49bd1319324a356','cf27b711-0b6b-4bb5-a9e0-bf3aab44971c','2026-05-23 15:55:16.589',NULL,'2026-05-16 15:55:16.590'),('79845e81-8eb5-4642-a38e-65e4770f5a92','586dd37d426b86ce5de7a994cc4f0400b34fea2fe4f447fa3efccd0b56aabedd','6fe69220-33e9-4c86-8e5d-b8ba924c5962','2026-05-23 19:28:00.743',NULL,'2026-05-16 19:28:00.744'),('7bcd7c99-185d-4c7c-b7de-960dc2786838','93b154de6c617b85c493fb93ccc74c69ec5fcb72f7abc089c0d6caf5503ef58c','a103e261-4bbd-4dd9-a350-6cbad3f01a64','2026-05-26 14:25:34.497',NULL,'2026-05-19 14:25:34.498'),('7c5426c5-33a1-4d15-93ed-0feb168fe787','460dce603c85fd849096c6b4e9ca67b2b3ce2fe77bdb9521bbd18cffc40c298f','f31cf403-afa7-4b2f-917a-9692b50063cc','2026-05-21 00:28:44.553',NULL,'2026-05-14 00:28:44.555'),('80558e89-6ece-4b08-83f7-deb95646ad29','69949aabf6db5a5f493c7ffbc82b282778e92a2304fb8ec67fa92733790a3ca6','87809908-5136-4782-bb91-421b58281ad2','2026-05-20 16:46:56.351',NULL,'2026-05-13 16:46:56.352'),('83af7765-c953-4581-ae98-fd50781f225f','06e5c71dfb8f5b53c148cc0ca4f31a486f0dd5b6f5a7cad9b914ad8838ea0a31','698ca1b3-8f97-4156-bb79-88f0869781ca','2026-05-26 14:38:13.136',NULL,'2026-05-19 14:38:13.137'),('848c4a00-3f95-444f-b337-a0bda7d7d21c','66151fd5cac94cc3d9302a19970d9acad35b2900d07ab803dab6174a5b052dcf','14f24111-6c3d-4ddc-9669-73d0d3703cd0','2026-05-20 13:20:11.340',NULL,'2026-05-13 13:20:11.341'),('855f1d08-ee40-4374-bbee-9a113b93740b','4b8baf3abc8a868114c47e26708c49317e03abdcab52843c0586facea1d84eed','1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','2026-05-26 11:22:35.124',NULL,'2026-05-19 11:22:35.125'),('86ef3245-825f-43a3-a6f6-28ad734d4665','12d96fbf370625eddb6ad6d21f18fa68daca32c7a655fac87d88517053050443','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:42:59.125',NULL,'2026-05-18 15:42:59.126'),('883072f8-278f-4927-ab35-01775ab68093','747e68b6cf2ae4df022d73a3bafbf28eb9c0d9e359bde2581643110fe4040911','e8ea827e-1378-4ed1-85ce-4850ddc7221f','2026-05-26 14:39:59.465',NULL,'2026-05-19 14:39:59.466'),('8c0dc121-40a6-46fd-a67f-27554c249480','91a6810b54f527a8ad458e8acea6f1864210285c8ecc4b023a52bde1dc8e7da9','c94d5e30-c52e-453c-b80d-8ff3f329cbf9','2026-05-23 18:47:39.012',NULL,'2026-05-16 18:47:39.012'),('8de1bec3-fbe6-485d-90d7-50517a5182f6','c9555142cd10f346edd4fb473c4d807eba837d5aac47bc825834cc12553f8e0f','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-20 13:21:53.107',NULL,'2026-05-13 13:21:53.108'),('903ac717-2d46-4cd6-a9a2-ef822fafd72d','b7de37b969e1acb7725b8c42c1b45b89941268c51aa485378e019a35a921d8ba','8d93fc6c-f486-49a9-9849-b58bc9201167','2026-05-26 14:02:13.080',NULL,'2026-05-19 14:02:13.081'),('9570dfeb-66c4-4a0e-aef0-f7699aacfec0','d85c496d714c928afbde1fa1b3d0a3a08f4530d3d6fbb9b98527a6405c1ad3e4','6fe69220-33e9-4c86-8e5d-b8ba924c5962','2026-05-23 19:29:07.541',NULL,'2026-05-16 19:29:07.542'),('976ad6b7-030d-41c7-b8fe-7bcf14214559','2fe3d19dd6e386ba15373701bbe9b885fc38a854045e5cf7abd04574838d88e1','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:16:26.994',NULL,'2026-05-13 13:16:26.995'),('98314968-3886-46ae-9f06-d2a5b71553de','54c97f5714566ebb8fa7cc7c9df1cbb53cf55a02bfb0ea1a04c6fd4488cd0708','14f24111-6c3d-4ddc-9669-73d0d3703cd0','2026-05-20 13:16:56.475',NULL,'2026-05-13 13:16:56.476'),('98f783c7-b564-406f-9b9b-027ff9874317','6511236409a9ef29d24ef2ced962431a641d4554a260fddd50ef5f06b2ae22d7','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-20 15:12:29.150',NULL,'2026-05-13 15:12:29.151'),('9aa01131-7aae-40ac-84e1-a99f6125ec59','62213671bc510af52397315ec607bb8557d1035d989e9707f6bbc80169a837d4','68907da8-6eca-41aa-affa-e4710435daff','2026-05-21 18:42:41.935',NULL,'2026-05-14 18:42:41.936'),('9c426537-77b4-4c79-9c12-e95a77155011','98f7182fb98ea945506a2b8755082eb3bcd88423f3aaa558027d4905f3efd2bb','892980d6-a579-4912-9763-f058203bc362','2026-05-25 15:35:19.000',NULL,'2026-05-18 15:35:19.001'),('9cc1c565-478d-4729-a754-f4aac1ce2732','c6a04a63cd35e3123f3065335cb31dad3499954cf1625fee25d8eb4fc7061ee2','4cc9f888-516f-4847-94af-41ce5a1635e4','2026-05-25 15:42:36.435',NULL,'2026-05-18 15:42:36.435'),('9d0db795-0748-4d37-8191-50431939e862','c5b7bded85d276f9ef3d0bf91bd2a872574454c801336384b60b58070ac6e0df','71564219-1f09-457e-8b41-ef328da7fd80','2026-05-23 19:08:34.413',NULL,'2026-05-16 19:08:34.414'),('a0050da5-30e2-47ae-b8ee-1fa73ac0bed5','771d6b7c12902ac37dbb773b09d01a82f741c418ecc370d939a129889a6158ac','723d908a-75b6-40ff-89c0-e7272f514afb','2026-05-26 14:24:59.602',NULL,'2026-05-19 14:24:59.603'),('a6aed254-e28e-4362-84bb-f25d513995a4','f002a88bec21dff00a5d644b21c7099215d0abdfa0693c89e2706ee60d2011f5','22972369-0833-45d6-a5c6-37d7157061d0','2026-05-21 00:28:30.532',NULL,'2026-05-14 00:28:30.533'),('a7680489-bf75-424d-a71b-3ffda49c17f5','bc43a1cd319031fb9b69d5ef3132cb14c8c17e825902cfd506cc5406e02cb721','f8be3975-34fb-422f-8746-2ebb436330b4','2026-05-26 09:44:12.816',NULL,'2026-05-19 09:44:12.817'),('aafe7c9e-d947-4d45-9864-8e3e823ed476','5b25e1670756804351bc94783a1421c2582af55e6c50e6cbfe1d085e16683581','14f24111-6c3d-4ddc-9669-73d0d3703cd0','2026-05-20 13:16:55.850',NULL,'2026-05-13 13:16:55.851'),('aba3df4b-bb36-4008-ad7a-d484084e6a43','4a82b28ae4a129d2754f3ffbf40ce2a4e142ba6eda13757e06c2f7f5eb2fd9ce','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','2026-05-20 22:46:22.483',NULL,'2026-05-13 22:46:22.483'),('ad942b8d-36b4-4cca-ae86-617b92df1311','a7df260b4c7259e7a12ff5ff3789f00bc2a1ba7787e07042cc55bf7a4a81ab91','4cc9f888-516f-4847-94af-41ce5a1635e4','2026-05-25 15:42:59.480',NULL,'2026-05-18 15:42:59.481'),('ae553526-d103-4e1f-9203-797f2719f3f4','80639cf9297d2d6ae81b32a20fa8f36a498d384241a3678de4ff6055b80534d3','118bcfdb-bd89-42ce-a95b-83020a97dc5f','2026-05-22 04:57:19.260',NULL,'2026-05-15 04:57:19.262'),('ae837885-27c4-4985-b13c-dfe6887d134c','d0e7a7143e0b051d61fb6d8ab0783ae248afab66776a417f171d9155553fe8d3','6835f00a-c875-4a23-bf8d-5273a381c21f','2026-05-22 05:01:27.270',NULL,'2026-05-15 05:01:27.270'),('b4fd7806-2b5a-4222-b925-cf6421f76b7a','e427b9c53003979ca64dcaee01c7223f129e581cf4484f9537dfb5f0f779de76','abead984-c09c-4fba-8460-0f0537b2dea1','2026-05-26 14:24:59.786',NULL,'2026-05-19 14:24:59.787'),('b56f5709-7907-4ba8-b110-ad19eb6e3ec7','742746a9810ae59438ba1cc0fe4591d65b2eab4ff8bdd0a3cdc58d14c5f41f9d','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:37:02.441',NULL,'2026-05-18 15:37:02.442'),('b67e60db-cba9-4c6d-919b-2ca1e5d82abd','9fb17fdd4e96a2fb7b1bacd74ffc420b8744eaf534ba23ee29d6e6e5b9096237','cf27b711-0b6b-4bb5-a9e0-bf3aab44971c','2026-05-23 15:48:21.277',NULL,'2026-05-16 15:48:21.278'),('b864689a-03a2-4d83-add2-5f1a66b31137','91baebf360d9687fcb4387a55a0680bdc14e62196ab7ad8649116792f1294692','471a81d1-2a9b-4fdf-8f30-116178eaf85b','2026-05-25 15:31:44.500',NULL,'2026-05-18 15:31:44.501'),('bd02b685-d0e9-47d3-8d3d-bc4e12bda39a','6c5c08cf517b90ddcdec9fbe1f345e244efbf12628502263dcdb8a7aeb39a907','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','2026-05-20 19:10:50.080',NULL,'2026-05-13 19:10:50.081'),('bd08f4af-9874-461d-a159-4e638f7946f4','a4d743f334d577c45036e0f4fc9928d66853c728b8d30d0fa96f699ad0a8c927','942125f0-2e1c-4c4c-a382-ebfb63f17f3d','2026-05-22 11:41:57.280',NULL,'2026-05-15 11:41:57.281'),('c1d17880-2896-4923-b07b-3f22bed5f48c','2d24fddcaf52d7f0ed0ecd9a9701fb890ca424edd68476e34035614d5d1aa3fe','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','2026-05-20 22:18:46.143','2026-05-13 22:39:29.338','2026-05-13 22:18:46.144'),('c2bb7daf-d873-4648-b996-83fdc14f2167','a7c984594626d2fcb3e962ec3d2391fe1903dbea3724d4958c28bea213d3caf9','18c35f7a-ac4d-4939-bc31-688b95eabf3c','2026-05-22 00:16:08.739',NULL,'2026-05-15 00:16:08.740'),('c4795535-f452-4de7-b40b-ee74fbf96c41','a8280bff485f6ce15ebc29931b8c3680f7280ebf2c15dc4da8c48345e5161117','4c3108db-7d9e-4443-8f3a-6dac1d17be9b','2026-05-21 00:28:14.641',NULL,'2026-05-14 00:28:14.641'),('c6996b1a-db4d-4c12-9439-ad3a19c29af2','66686e79470350d4de5efc616a258f4d84516ffda3c507a28dedad5aa6abb4ba','3d4cf853-e23d-43da-b661-e30f09f2b680','2026-05-26 14:25:34.693',NULL,'2026-05-19 14:25:34.693'),('c7303291-675c-4efd-938c-e04bddca36b3','83eafa62a8cb2bd5d5ead582bdcc6459e996d65fddaf86b9fb6bdb26cc0f3359','4cc9f888-516f-4847-94af-41ce5a1635e4','2026-05-25 15:35:43.819',NULL,'2026-05-18 15:35:43.820'),('c859c3c1-e150-4918-9107-b16828e487f6','ec1a923285a07ae1f8d1ef8afd9560a74036b8ecd740650dec7b6fc7081a6e36','cea7d32a-a582-4ecc-9988-72fa0d0e6e6c','2026-05-23 15:57:53.866',NULL,'2026-05-16 15:57:53.867'),('d11cfad3-b0de-414f-abb3-229682573b8b','7c3827ea02326f835ddbf3fd8b5896f7cb019c4f795cfc1df3f3d66f3f40a2c6','0a08c64a-3126-4492-8e00-9c4f44f43086','2026-05-26 14:31:37.471',NULL,'2026-05-19 14:31:37.472'),('d6f088e5-0d9c-45c8-8ad3-138c21e2e9fb','2fe0ed3676e262b4667462f2166dfdf7fee01e03869808713299161b61c88c10','3ab38cbb-8bbb-4515-a3ef-198cb6abfa23','2026-05-22 05:02:23.285',NULL,'2026-05-15 05:02:23.286'),('dc44d930-e8f2-45d0-b363-5d6012d4aea4','a2a9aae3df566d705fa3beea222fc9315c9214aaff334ba8b42363fe45abcfa6','457bd5da-9edc-4217-90f9-93e7a320f455','2026-05-23 19:08:19.581',NULL,'2026-05-16 19:08:19.582'),('de78135c-dec4-40fe-bc14-0f8e8dbf2ff0','78d66cf7236779773757b5a54561107a52d904736837cc86882f343e8c4ff069','14f24111-6c3d-4ddc-9669-73d0d3703cd0','2026-05-20 13:20:11.189',NULL,'2026-05-13 13:20:11.190'),('df38a242-dd95-45f0-b866-cdea79cceace','7a94a6360a723ce2569302a3ec5dda4a73cdb2ab8a00e482f68a68bf1362972d','caf27a62-1a0f-4615-9e18-c07d43813883','2026-05-25 15:36:01.617',NULL,'2026-05-18 15:36:01.618'),('dfdf795b-bf95-479d-8911-b51d154329b0','03993f375959b66929235ac46a47a1c6e6624272be16bd450d88372c5036f3ef','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','2026-05-20 22:03:36.689','2026-05-13 22:18:46.128','2026-05-13 22:03:36.690'),('e171f376-642c-4864-9f05-d5b04fe7cc57','75c2a7194e98014e772191598d3c4fb8aa9873ede100587a4efaf87ae4cbf1cc','752a5c35-8903-4fd4-95bf-f790b8ddb292','2026-05-21 00:29:02.528',NULL,'2026-05-14 00:29:02.529'),('e41a0c54-091f-4c1b-8cbd-4eaa6e38e897','85368e1edd0064bc88285bfa9592eba9e374434e13c25aad800198f36a320409','ebf76fd4-281d-4ca6-ac52-0035556c259e','2026-05-22 13:26:27.017',NULL,'2026-05-15 13:26:27.018'),('e7b6f7a1-041c-420c-86b5-4674d0bafe07','b4cdfb14ffde60dfad75a2f70b6fa3c6a775d768472863c087ea05d0c479b97d','87dad90d-cc5f-44df-8efa-9e76bfbfce0f','2026-05-20 12:52:10.672',NULL,'2026-05-13 12:52:10.674'),('e92a617f-1cc5-4839-9472-b06434cf6813','d6d8526439024c153f714fb75e16837abb9c5fad568e4fa73d19bf2c3030779e','7ec54910-cfc2-41b7-96e8-beea4f1017f9','2026-05-26 13:48:08.024',NULL,'2026-05-19 13:48:08.025'),('ea6516d8-cfe6-4d5e-889e-69cfb5f81fbd','8aeec4e5b0070cccc5816cdf3ce503a345a05f0424c9f995605b2c86e73f8a81','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','2026-05-20 18:55:13.205','2026-05-13 19:10:50.050','2026-05-13 18:55:13.206'),('ef6e0f1e-2d09-455f-b8cd-3edf865dd22b','0f98ffd66be671609ab17f52b4af524f876946901a7b30c2b0b91b0b09087528','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:26:42.535',NULL,'2026-05-13 13:26:42.536'),('efc9bc87-8671-4ec2-b605-c869d4dc9c46','c72b156bc1f1c61fe77f613f1437b770319ccb62aa38ac3e3e7e83463720b3bd','5d47ff7a-b727-4fef-88bc-a04469384b5c','2026-05-26 14:42:16.287',NULL,'2026-05-19 14:42:16.288'),('f32a2f65-53d7-4bf6-9c3f-6388599b6963','5a618aadd5496b3684675b4d8a62491b7443b7c2f16eb22d9db485f94d78db33','379a2d98-460e-4c0c-a3d5-fc70bb541ca1','2026-05-20 13:22:30.921',NULL,'2026-05-13 13:22:30.922'),('f3b4ef93-628c-4eb7-84a7-b1a3d05eb2bc','899c218d54219a2623874b65a5b25d1df488a85166ebe116cb6e6a21c4daaf7d','6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','2026-05-20 22:39:29.368',NULL,'2026-05-13 22:39:29.369'),('f4c7e910-17a1-406a-a84c-e901ac6e8960','35723de09eaacd47e7a607bfee01b497bc020e1811112448660f9950927f7e5e','7a3a01ae-7dcb-445d-942f-9996de05ddad','2026-05-22 14:25:02.185',NULL,'2026-05-15 14:25:02.186'),('f7180063-4142-4f9c-994a-39cfba6659c8','4e1cb7bd70aa539850023481f038ffed91a62b533bf8f3a378e2f67c00c45730','86ab07ff-5932-46ea-ad89-a742815d4e8d','2026-05-22 13:21:17.160',NULL,'2026-05-15 13:21:17.161'),('fb760ea8-3ea5-4eb3-bf98-e840f84b0f23','91e57e4aa5bd99e1c3ed81dfc102f6936298e6862e11c437fc4eab134df33c74','ae90dc20-de65-4e66-95aa-376767826016','2026-05-21 18:41:39.037',NULL,'2026-05-14 18:41:39.038');
/*!40000 ALTER TABLE `RefreshToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Result`
--

DROP TABLE IF EXISTS `Result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Result` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ideaId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `evaluation` int DEFAULT NULL,
  `createdBy` enum('USER','AI') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'AI',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `evaluatedAt` datetime(3) DEFAULT NULL,
  `evaluatedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedAt` datetime(3) NOT NULL,
  `judgeAnalysis` text COLLATE utf8mb4_unicode_ci,
  `judgeComment` text COLLATE utf8mb4_unicode_ci,
  `satisfactionCount` int NOT NULL DEFAULT '0',
  `satisfactionScore` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Result_needId_fkey` (`needId`),
  KEY `Result_ideaId_fkey` (`ideaId`),
  KEY `Result_evaluatedById_fkey` (`evaluatedById`),
  CONSTRAINT `Result_evaluatedById_fkey` FOREIGN KEY (`evaluatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Result_ideaId_fkey` FOREIGN KEY (`ideaId`) REFERENCES `Idea` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Result_needId_fkey` FOREIGN KEY (`needId`) REFERENCES `Need` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Result`
--

LOCK TABLES `Result` WRITE;
/*!40000 ALTER TABLE `Result` DISABLE KEYS */;
/*!40000 ALTER TABLE `Result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SatisfaccionEvaluador`
--

DROP TABLE IF EXISTS `SatisfaccionEvaluador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SatisfaccionEvaluador` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deliverableId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hasEvaluated` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SatisfaccionEvaluador_deliverableId_userId_key` (`deliverableId`,`userId`),
  KEY `SatisfaccionEvaluador_userId_fkey` (`userId`),
  CONSTRAINT `SatisfaccionEvaluador_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SatisfaccionEvaluador`
--

LOCK TABLES `SatisfaccionEvaluador` WRITE;
/*!40000 ALTER TABLE `SatisfaccionEvaluador` DISABLE KEYS */;
/*!40000 ALTER TABLE `SatisfaccionEvaluador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SatisfactionPoll`
--

DROP TABLE IF EXISTS `SatisfactionPoll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SatisfactionPoll` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pollId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resultId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chatId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SatisfactionPoll_pollId_key` (`pollId`),
  KEY `SatisfactionPoll_resultId_fkey` (`resultId`),
  CONSTRAINT `SatisfactionPoll_resultId_fkey` FOREIGN KEY (`resultId`) REFERENCES `Result` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SatisfactionPoll`
--

LOCK TABLES `SatisfactionPoll` WRITE;
/*!40000 ALTER TABLE `SatisfactionPoll` DISABLE KEYS */;
/*!40000 ALTER TABLE `SatisfactionPoll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SatisfactionRating`
--

DROP TABLE IF EXISTS `SatisfactionRating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SatisfactionRating` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deliverableId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SatisfactionRating_deliverableId_userId_key` (`deliverableId`,`userId`),
  KEY `SatisfactionRating_userId_fkey` (`userId`),
  CONSTRAINT `SatisfactionRating_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SatisfactionRating`
--

LOCK TABLES `SatisfactionRating` WRITE;
/*!40000 ALTER TABLE `SatisfactionRating` DISABLE KEYS */;
/*!40000 ALTER TABLE `SatisfactionRating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SatisfactionScore`
--

DROP TABLE IF EXISTS `SatisfactionScore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SatisfactionScore` (
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avgScore` double NOT NULL DEFAULT '0',
  `totalSurveys` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`userId`,`skill`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SatisfactionScore`
--

LOCK TABLES `SatisfactionScore` WRITE;
/*!40000 ALTER TABLE `SatisfactionScore` DISABLE KEYS */;
INSERT INTO `SatisfactionScore` VALUES ('a03911c9-b29e-4d58-ab1a-794473d788d5','python',4.5,10);
/*!40000 ALTER TABLE `SatisfactionScore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SatisfactionSurvey`
--

DROP TABLE IF EXISTS `SatisfactionSurvey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SatisfactionSurvey` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `announcedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `closesAt` datetime(3) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `reminderSent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `SatisfactionSurvey_treeId_idx` (`treeId`),
  KEY `SatisfactionSurvey_closesAt_idx` (`closesAt`),
  CONSTRAINT `SatisfactionSurvey_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SatisfactionSurvey`
--

LOCK TABLES `SatisfactionSurvey` WRITE;
/*!40000 ALTER TABLE `SatisfactionSurvey` DISABLE KEYS */;
/*!40000 ALTER TABLE `SatisfactionSurvey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScopePreference`
--

DROP TABLE IF EXISTS `ScopePreference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ScopePreference` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `externalNeedId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `labelKey` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `score` int NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `normalizedWeight` double DEFAULT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `ScopePreference_externalNeedId_idx` (`externalNeedId`),
  KEY `ScopePreference_agentId_idx` (`agentId`),
  KEY `ScopePreference_label_idx` (`label`),
  KEY `ScopePreference_labelKey_idx` (`labelKey`),
  KEY `ScopePreference_createdById_idx` (`createdById`),
  CONSTRAINT `ScopePreference_agentId_fkey` FOREIGN KEY (`agentId`) REFERENCES `ExternalAgent` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ScopePreference_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScopePreference`
--

LOCK TABLES `ScopePreference` WRITE;
/*!40000 ALTER TABLE `ScopePreference` DISABLE KEYS */;
/*!40000 ALTER TABLE `ScopePreference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SearchPass`
--

DROP TABLE IF EXISTS `SearchPass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SearchPass` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `SearchPass_userId_expiresAt_idx` (`userId`,`expiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SearchPass`
--

LOCK TABLES `SearchPass` WRITE;
/*!40000 ALTER TABLE `SearchPass` DISABLE KEYS */;
/*!40000 ALTER TABLE `SearchPass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SkillEndorsement`
--

DROP TABLE IF EXISTS `SkillEndorsement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SkillEndorsement` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proposalId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endorserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SkillEndorsement_proposalId_endorserId_key` (`proposalId`,`endorserId`),
  KEY `SkillEndorsement_endorserId_fkey` (`endorserId`),
  CONSTRAINT `SkillEndorsement_endorserId_fkey` FOREIGN KEY (`endorserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SkillEndorsement`
--

LOCK TABLES `SkillEndorsement` WRITE;
/*!40000 ALTER TABLE `SkillEndorsement` DISABLE KEYS */;
/*!40000 ALTER TABLE `SkillEndorsement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SkillMigration`
--

DROP TABLE IF EXISTS `SkillMigration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SkillMigration` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashtag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('EN_PRUEBA','APROBADO','REPROBADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EN_PRUEBA',
  `tasksCompleted` int NOT NULL DEFAULT '0',
  `tasksFailed` int NOT NULL DEFAULT '0',
  `autoApproved` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SkillMigration_userId_hashtag_src_tgt_key` (`userId`,`hashtag`,`sourceTreeId`,`targetTreeId`),
  KEY `SkillMigration_targetTreeId_hashtag_idx` (`targetTreeId`,`hashtag`),
  KEY `SkillMigration_userId_status_idx` (`userId`,`status`),
  KEY `SkillMigration_sourceTreeId_fkey` (`sourceTreeId`),
  CONSTRAINT `SkillMigration_sourceTreeId_fkey` FOREIGN KEY (`sourceTreeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `SkillMigration_targetTreeId_fkey` FOREIGN KEY (`targetTreeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SkillMigration`
--

LOCK TABLES `SkillMigration` WRITE;
/*!40000 ALTER TABLE `SkillMigration` DISABLE KEYS */;
/*!40000 ALTER TABLE `SkillMigration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SkillPricing`
--

DROP TABLE IF EXISTS `SkillPricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SkillPricing` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skillTag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ratePerHour` double NOT NULL,
  `demandLevel` int NOT NULL DEFAULT '1',
  `supplyCount` int NOT NULL DEFAULT '0',
  `updatedAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SkillPricing_treeId_skillTag_key` (`treeId`,`skillTag`),
  KEY `SkillPricing_treeId_idx` (`treeId`),
  CONSTRAINT `SkillPricing_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SkillPricing`
--

LOCK TABLES `SkillPricing` WRITE;
/*!40000 ALTER TABLE `SkillPricing` DISABLE KEYS */;
/*!40000 ALTER TABLE `SkillPricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SkillProposal`
--

DROP TABLE IF EXISTS `SkillProposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SkillProposal` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashtag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDIENTE_AVALES','EN_PRUEBA','APROBADO','RECHAZADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDIENTE_AVALES',
  `tasksCompleted` int NOT NULL DEFAULT '0',
  `tasksFailed` int NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SkillProposal_userId_treeId_hashtag_key` (`userId`,`treeId`,`hashtag`),
  KEY `SkillProposal_treeId_hashtag_status_idx` (`treeId`,`hashtag`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SkillProposal`
--

LOCK TABLES `SkillProposal` WRITE;
/*!40000 ALTER TABLE `SkillProposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `SkillProposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SolutionCatalog`
--

DROP TABLE IF EXISTS `SolutionCatalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SolutionCatalog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolutionLevel` int NOT NULL,
  `repoUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publishedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `SolutionCatalog_treeId_idx` (`treeId`),
  KEY `SolutionCatalog_needId_fkey` (`needId`),
  CONSTRAINT `SolutionCatalog_needId_fkey` FOREIGN KEY (`needId`) REFERENCES `Need` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `SolutionCatalog_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SolutionCatalog`
--

LOCK TABLES `SolutionCatalog` WRITE;
/*!40000 ALTER TABLE `SolutionCatalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `SolutionCatalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SolutionProposal`
--

DROP TABLE IF EXISTS `SolutionProposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SolutionProposal` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `externalNeedId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('DRAFT','SUBMITTED','UNDER_REVIEW','APPROVED_BY_TREE','APPROVED_BY_CLIENT','REJECTED','SELECTED','ARCHIVED','CONVERTED_TO_TASKS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `estimatedFiatMin` double DEFAULT NULL,
  `estimatedFiatExpected` double DEFAULT NULL,
  `estimatedFiatMax` double DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'CLP',
  `estimatedBerries` int DEFAULT NULL,
  `estimatedDurationDays` int DEFAULT NULL,
  `riskLevel` enum('LOW','MEDIUM','HIGH','CRITICAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MEDIUM',
  `assumptions` text COLLATE utf8mb4_unicode_ci,
  `included` text COLLATE utf8mb4_unicode_ci,
  `excluded` text COLLATE utf8mb4_unicode_ci,
  `deliverables` text COLLATE utf8mb4_unicode_ci,
  `acceptanceCriteria` text COLLATE utf8mb4_unicode_ci,
  `maintenanceNotes` text COLLATE utf8mb4_unicode_ci,
  `scopeAlignmentJson` json DEFAULT NULL,
  `metadataJson` json DEFAULT NULL,
  `selectedAt` datetime(3) DEFAULT NULL,
  `selectedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approvedByClientAt` datetime(3) DEFAULT NULL,
  `approvedByTreeAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `SolutionProposal_externalNeedId_idx` (`externalNeedId`),
  KEY `SolutionProposal_createdById_idx` (`createdById`),
  KEY `SolutionProposal_status_idx` (`status`),
  KEY `SolutionProposal_riskLevel_idx` (`riskLevel`),
  KEY `SolutionProposal_selectedById_idx` (`selectedById`),
  CONSTRAINT `SolutionProposal_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `SolutionProposal_selectedById_fkey` FOREIGN KEY (`selectedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SolutionProposal`
--

LOCK TABLES `SolutionProposal` WRITE;
/*!40000 ALTER TABLE `SolutionProposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `SolutionProposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StripeConnectAccount`
--

DROP TABLE IF EXISTS `StripeConnectAccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StripeConnectAccount` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stripeAccountId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chargesEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `payoutsEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `StripeConnectAccount_userId_key` (`userId`),
  UNIQUE KEY `StripeConnectAccount_stripeAccountId_key` (`stripeAccountId`),
  KEY `StripeConnectAccount_userId_idx` (`userId`),
  KEY `StripeConnectAccount_stripeAccountId_idx` (`stripeAccountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StripeConnectAccount`
--

LOCK TABLES `StripeConnectAccount` WRITE;
/*!40000 ALTER TABLE `StripeConnectAccount` DISABLE KEYS */;
/*!40000 ALTER TABLE `StripeConnectAccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subscription`
--

DROP TABLE IF EXISTS `Subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Subscription` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','CANCELED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `paddleSubscriptionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentPeriodStart` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `currentPeriodEnd` datetime(3) NOT NULL,
  `monthlyCost` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Subscription_paddleSubscriptionId_key` (`paddleSubscriptionId`),
  KEY `Subscription_userId_idx` (`userId`),
  KEY `Subscription_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subscription`
--

LOCK TABLES `Subscription` WRITE;
/*!40000 ALTER TABLE `Subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `Subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SubscriptionPlan`
--

DROP TABLE IF EXISTS `SubscriptionPlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SubscriptionPlan` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentMonthlyCost` double NOT NULL DEFAULT '0',
  `costBreakdown` json NOT NULL,
  `calculatedAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubscriptionPlan`
--

LOCK TABLES `SubscriptionPlan` WRITE;
/*!40000 ALTER TABLE `SubscriptionPlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `SubscriptionPlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SurveyVote`
--

DROP TABLE IF EXISTS `SurveyVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SurveyVote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surveyId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `voterId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SurveyVote_surveyId_voterId_key` (`surveyId`,`voterId`),
  CONSTRAINT `SurveyVote_surveyId_fkey` FOREIGN KEY (`surveyId`) REFERENCES `SatisfactionSurvey` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SurveyVote`
--

LOCK TABLES `SurveyVote` WRITE;
/*!40000 ALTER TABLE `SurveyVote` DISABLE KEYS */;
/*!40000 ALTER TABLE `SurveyVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SustainabilitySplit`
--

DROP TABLE IF EXISTS `SustainabilitySplit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SustainabilitySplit` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `materialsPct` double NOT NULL DEFAULT '0',
  `laborPct` double NOT NULL DEFAULT '0',
  `operationsPct` double NOT NULL DEFAULT '0',
  `taxPct` double NOT NULL DEFAULT '0',
  `reservePct` double NOT NULL DEFAULT '0',
  `maintenancePct` double NOT NULL DEFAULT '0',
  `treeFundPct` double NOT NULL DEFAULT '0',
  `otherPct` double NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SustainabilitySplit_configId_key` (`configId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SustainabilitySplit`
--

LOCK TABLES `SustainabilitySplit` WRITE;
/*!40000 ALTER TABLE `SustainabilitySplit` DISABLE KEYS */;
/*!40000 ALTER TABLE `SustainabilitySplit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TalentMigrationSuggestion`
--

DROP TABLE IF EXISTS `TalentMigrationSuggestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TalentMigrationSuggestion` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memberId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `toTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skillTag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentRate` double NOT NULL,
  `betterRate` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `TalentMigrationSuggestion_memberId_idx` (`memberId`),
  KEY `TalentMigrationSuggestion_fromTreeId_toTreeId_idx` (`fromTreeId`,`toTreeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TalentMigrationSuggestion`
--

LOCK TABLES `TalentMigrationSuggestion` WRITE;
/*!40000 ALTER TABLE `TalentMigrationSuggestion` DISABLE KEYS */;
/*!40000 ALTER TABLE `TalentMigrationSuggestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Task`
--

DROP TABLE IF EXISTS `Task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Task` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('PENDING','ASSIGNED','IN_PROGRESS','EVIDENCE_SUBMITTED','VERIFIED','PAID','DISPUTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `assigneeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updatedAt` datetime(3) NOT NULL,
  `budget` int NOT NULL,
  `creatorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skills` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `evidenceUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `evidenceType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disputedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disputeReason` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disputeEvidenceUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complexity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xpAwarded` int DEFAULT NULL,
  `disputeExpiresAt` datetime(3) DEFAULT NULL,
  `disputedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Task_treeId_idx` (`treeId`),
  KEY `Task_status_idx` (`status`),
  KEY `Task_assigneeId_idx` (`assigneeId`),
  KEY `Task_needId_idx` (`needId`),
  KEY `Task_creatorId_fkey` (`creatorId`),
  KEY `Task_disputedById_fkey` (`disputedById`),
  CONSTRAINT `Task_assigneeId_fkey` FOREIGN KEY (`assigneeId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Task_creatorId_fkey` FOREIGN KEY (`creatorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Task_disputedById_fkey` FOREIGN KEY (`disputedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Task_needId_fkey` FOREIGN KEY (`needId`) REFERENCES `Need` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Task_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Task`
--

LOCK TABLES `Task` WRITE;
/*!40000 ALTER TABLE `Task` DISABLE KEYS */;
/*!40000 ALTER TABLE `Task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TaskQuestion`
--

DROP TABLE IF EXISTS `TaskQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TaskQuestion` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `TaskQuestion_taskId_userId_key` (`taskId`,`userId`),
  KEY `TaskQuestion_userId_fkey` (`userId`),
  CONSTRAINT `TaskQuestion_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TaskQuestion`
--

LOCK TABLES `TaskQuestion` WRITE;
/*!40000 ALTER TABLE `TaskQuestion` DISABLE KEYS */;
/*!40000 ALTER TABLE `TaskQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TaskTag`
--

DROP TABLE IF EXISTS `TaskTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TaskTag` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skillName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TaskTag_taskId_skillName_key` (`taskId`,`skillName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TaskTag`
--

LOCK TABLES `TaskTag` WRITE;
/*!40000 ALTER TABLE `TaskTag` DISABLE KEYS */;
/*!40000 ALTER TABLE `TaskTag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TaskVote`
--

DROP TABLE IF EXISTS `TaskVote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TaskVote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `effortValue` double DEFAULT NULL,
  `requiredHours` double DEFAULT NULL,
  `difficulty` double DEFAULT NULL,
  `isRandomAssignee` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `TaskVote_taskId_userId_key` (`taskId`,`userId`),
  KEY `TaskVote_userId_fkey` (`userId`),
  CONSTRAINT `TaskVote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TaskVote`
--

LOCK TABLES `TaskVote` WRITE;
/*!40000 ALTER TABLE `TaskVote` DISABLE KEYS */;
/*!40000 ALTER TABLE `TaskVote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TechStackItem`
--

DROP TABLE IF EXISTS `TechStackItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TechStackItem` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `repoUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `websiteUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addedBy` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `TechStackItem_category_idx` (`category`),
  KEY `TechStackItem_tags_idx` (`tags`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TechStackItem`
--

LOCK TABLES `TechStackItem` WRITE;
/*!40000 ALTER TABLE `TechStackItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `TechStackItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Todo`
--

DROP TABLE IF EXISTS `Todo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Todo` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chatId` bigint NOT NULL,
  `messageId` bigint NOT NULL,
  `createdBy` bigint NOT NULL,
  `createdByName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `likeCount` int NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `deadline` datetime(3) DEFAULT NULL,
  `reminderSent` tinyint(1) NOT NULL DEFAULT '0',
  `reminderSentAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL ON UPDATE CURRENT_TIMESTAMP(3),
  `assignedTo` bigint DEFAULT NULL,
  `assignedToName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Todo_treeId_chatId_idx` (`treeId`,`chatId`),
  KEY `Todo_messageId_chatId_idx` (`messageId`,`chatId`),
  CONSTRAINT `Todo_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Todo`
--

LOCK TABLES `Todo` WRITE;
/*!40000 ALTER TABLE `Todo` DISABLE KEYS */;
/*!40000 ALTER TABLE `Todo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TokenInvitacion`
--

DROP TABLE IF EXISTS `TokenInvitacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TokenInvitacion` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `arbolId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creadorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expiresAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `TokenInvitacion_arbolId_fkey` (`arbolId`),
  KEY `TokenInvitacion_creadorId_fkey` (`creadorId`),
  CONSTRAINT `TokenInvitacion_arbolId_fkey` FOREIGN KEY (`arbolId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TokenInvitacion_creadorId_fkey` FOREIGN KEY (`creadorId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TokenInvitacion`
--

LOCK TABLES `TokenInvitacion` WRITE;
/*!40000 ALTER TABLE `TokenInvitacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `TokenInvitacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TransactionLedger`
--

DROP TABLE IF EXISTS `TransactionLedger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TransactionLedger` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memberId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripeReference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadataJson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `TransactionLedger_treeId_idx` (`treeId`),
  KEY `TransactionLedger_memberId_idx` (`memberId`),
  KEY `TransactionLedger_treeId_createdAt_idx` (`treeId`,`createdAt`),
  CONSTRAINT `TransactionLedger_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `TreeMember` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `TransactionLedger_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TransactionLedger`
--

LOCK TABLES `TransactionLedger` WRITE;
/*!40000 ALTER TABLE `TransactionLedger` DISABLE KEYS */;
INSERT INTO `TransactionLedger` VALUES ('4d935f05-e37c-4ece-b36e-4943c7298e5a','d48bd81b-3172-4687-8327-f6f743dac72d','367c23db-7007-4889-9c5c-2247db0185ce','EXTERNAL_TASK_PAYOUT',5000,'Pago por tarea: TEST-E2E: human-worker webhook verify',NULL,'{\"taskId\":\"e8d16596-2069-4d64-877f-58a132317b49\",\"externalTaskId\":\"e8d16596-2069-4d64-877f-58a132317b49\",\"approvedBy\":\"ari\"}','2026-05-20 15:44:55.316'),('cab48a9b-105d-4ba2-ac7e-94d92304a1e9','d48bd81b-3172-4687-8327-f6f743dac72d','367c23db-7007-4889-9c5c-2247db0185ce','EXTERNAL_TASK_PAYOUT',5000,'Pago por tarea: TEST-E2E-v2',NULL,'{\"taskId\":\"6edd860d-8ef8-442f-bcd3-65c62fc23edb\",\"externalTaskId\":\"6edd860d-8ef8-442f-bcd3-65c62fc23edb\",\"approvedBy\":\"ari\"}','2026-05-20 15:48:26.310');
/*!40000 ALTER TABLE `TransactionLedger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tree`
--

DROP TABLE IF EXISTS `Tree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Tree` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icono` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 0xF09F8CB3,
  `creatorId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admissionPolicy` enum('OPEN','INVITE_ONLY') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INVITE_ONLY',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `telegramChatId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentTreeId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalBudget` double DEFAULT NULL,
  `objectives` text COLLATE utf8mb4_unicode_ci,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsappGroupId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'es',
  `paymentMode` enum('INDIVIDUAL','CENTRALIZED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INDIVIDUAL',
  `sponsorId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `introMessageId` bigint DEFAULT NULL,
  `onboardingInviterId` bigint DEFAULT NULL,
  `blockedUntil` datetime(3) DEFAULT NULL,
  `pendingDeletionAt` datetime(3) DEFAULT NULL,
  `leaveAttempts` int NOT NULL DEFAULT '0',
  `maxMembers` int NOT NULL DEFAULT '200',
  `standby` tinyint(1) NOT NULL DEFAULT '0',
  `paused` tinyint(1) NOT NULL DEFAULT '0',
  `voteThreshold` int NOT NULL DEFAULT '20',
  `interactionMode` enum('MAXIMUM','MEDIUM','MINIMUM') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MAXIMUM',
  `classification` json DEFAULT NULL,
  `classificationUpdatedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Tree_telegramChatId_key` (`telegramChatId`),
  UNIQUE KEY `Tree_code_key` (`code`),
  KEY `Tree_parentTreeId_fkey` (`parentTreeId`),
  CONSTRAINT `Tree_parentTreeId_fkey` FOREIGN KEY (`parentTreeId`) REFERENCES `Tree` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tree`
--

LOCK TABLES `Tree` WRITE;
/*!40000 ALTER TABLE `Tree` DISABLE KEYS */;
INSERT INTO `Tree` VALUES ('05f248e9-0849-4e7b-b43c-4e2a0a80d863','Integration Test Tree N6','Tree for NotebookLM integration test','🌳','telegram-bot','INVITE_ONLY','2026-05-19 11:20:49.679',NULL,NULL,NULL,NULL,'DC2G8X',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('0e730775-15f9-4493-98db-c9d3dbccf5f4','Integration Test N6','Testing NotebookLM integration flow','🌳','telegram-bot','INVITE_ONLY','2026-05-19 11:55:00.718',NULL,NULL,NULL,NULL,'3CGUPH',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('181c7258-1ac9-41b1-bfeb-df0081972c37','N6 Integration Test Tree','Tree para testing de integracion NotebookLM','🌳','telegram-bot','INVITE_ONLY','2026-05-19 09:43:45.767',NULL,NULL,NULL,NULL,'LGGWKL',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('18caeb4d-13d9-45a1-a061-5e0a2481637a','Primatest','Árbol automático para el grupo de Telegram \"Primatest\"','💬',NULL,'INVITE_ONLY','2026-05-17 12:24:54.268','-1003979499123',NULL,NULL,NULL,NULL,NULL,'es','INDIVIDUAL',NULL,5,7516190425,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('23eddf18-7f49-4c96-bcee-658f324446f2','Test de seguridad','Soy el creador de Trust Maker, éste es un árbol para hacer pruebas de seguridad','💬',NULL,'INVITE_ONLY','2026-05-19 19:20:47.056','-5161895974',NULL,NULL,'Soy el creador de Trust Maker, éste es un árbol para hacer pruebas de seguridad',NULL,NULL,'es','CENTRALIZED','a03911c9-b29e-4d58-ab1a-794473d788d5',NULL,7516190425,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6','Trabajando con Ari','Somos padre e hijo trabajando en una empresa de capacitaciones en ventas y negocios, queremos desarrollar varios proyectos y hacer clases mejores','💬',NULL,'INVITE_ONLY','2026-05-20 11:09:10.879','-5154581921',NULL,NULL,'Somos padre e hijo trabajando en una empresa de capacitaciones en ventas y negocios, queremos desarrollar varios proyectos y hacer clases mejores',NULL,NULL,'es','CENTRALIZED','a03911c9-b29e-4d58-ab1a-794473d788d5',NULL,7516190425,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('29e56913-53e3-11f1-9ad5-843a4b23a26c','Test creación de árbol','Árbol automático para el grupo de Telegram','💬',NULL,'INVITE_ONLY','2026-05-19 20:30:55.077','-5176361635',NULL,NULL,NULL,NULL,NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('56de7a18-ca06-4c79-8efa-bfcb50d2f623','Trust Maker','Soy un inventor solitario, éste es un árbol para desarrollar Trust Maker, una rama de Trust Suite.','💬',NULL,'INVITE_ONLY','2026-05-19 07:19:12.705','-5213850833','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'Soy un inventor solitario, éste es un árbol para desarrollar Trust Maker, una rama de Trust Suite.',NULL,NULL,'es','INDIVIDUAL',NULL,NULL,7516190425,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('677544eb-4a02-457b-b0fe-933f37277158','N6 Final Test','Full E2E','🌳','1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','INVITE_ONLY','2026-05-19 11:37:22.522',NULL,NULL,NULL,NULL,'X2LNH2',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('6bcaffbe-601d-4f8e-bc03-8004c2ceec42','test-tree',NULL,'🌳','telegram-bot','INVITE_ONLY','2026-05-19 09:52:17.218',NULL,NULL,NULL,NULL,'HEM9EA',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('6d148176-d9f3-4495-b0fd-78192421c1fe','Trust Suite','Soy un inventor solitario, ésto es un árbol para desarrollar Trust Suite, una rama derivada de Trust, el árbol padre','💬',NULL,'INVITE_ONLY','2026-05-19 07:16:46.429','-5274848173',NULL,NULL,'Soy un inventor solitario, ésto es un árbol para desarrollar Trust Suite, una rama derivada de Trust, el árbol padre',NULL,NULL,'es','CENTRALIZED','a03911c9-b29e-4d58-ab1a-794473d788d5',NULL,7516190425,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('71e3319c-a60b-45bd-afb9-d2b767977dfe','N6 Verify Delete',NULL,'🌳','f8be3975-34fb-422f-8746-2ebb436330b4','INVITE_ONLY','2026-05-19 09:51:32.817',NULL,NULL,NULL,NULL,'7YPXN5',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('7c02aba7-ef75-43dc-be8e-92f652b1ed68','Test de conexión','Soy el creador de Trust Maker, éste es un árbol para testear conexiones','💬',NULL,'INVITE_ONLY','2026-05-19 20:47:13.904','-5270961131',NULL,NULL,'Soy el creador de Trust Maker, éste es un árbol para testear conexiones',NULL,NULL,'es','CENTRALIZED','a03911c9-b29e-4d58-ab1a-794473d788d5',NULL,7516190425,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('8743a109-9287-45a9-ac86-1e48a0875a4d','kanban-scratch','Scratch tree for Kanban human-worker tasks','🌳','telegram-bot','INVITE_ONLY','2026-05-19 09:48:13.322',NULL,NULL,NULL,NULL,'6VKYG5',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('9c658a99-9b32-49c8-999f-30558c93ba3d','test-integration','Integration test tree','🌳','telegram-bot','INVITE_ONLY','2026-05-19 09:38:40.544',NULL,NULL,NULL,NULL,'5L322G',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('a47a575a-3216-4436-b9b0-3995d0b6e0e1','N6-TEST-NBLM','Integration test for NotebookLM','🌳','telegram-bot','INVITE_ONLY','2026-05-19 09:04:44.639',NULL,NULL,NULL,NULL,'3A9DJL',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('a6568a38-9e21-4310-98ce-83e1a9e180f4','CrossTree Test A 1779198288276','Tree A for crossTreeSkills integration test','🌳','0a93ae63-b3ec-435e-9700-1324132b047c','INVITE_ONLY','2026-05-19 13:44:48.288',NULL,NULL,NULL,NULL,'PSRVF8',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('c0c67870-7659-49df-b663-59b53c838123','CrossTree Test B 1779198288350','Tree B for crossTreeSkills integration test','🌳','0a93ae63-b3ec-435e-9700-1324132b047c','INVITE_ONLY','2026-05-19 13:44:48.376',NULL,NULL,NULL,NULL,'K4QPYG',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM',NULL,NULL),('d48bd81b-3172-4687-8327-f6f743dac72d','Academia de IA Test','academia de IA — investigacion en inteligencia artificial, machine learning y deep learning. Formacion de investigadores y publicacion de papers.','🤖','8d93fc6c-f486-49a9-9849-b58bc9201167','OPEN','2026-05-19 14:03:01.416',NULL,NULL,NULL,NULL,'B2MLDE',NULL,'es','INDIVIDUAL',NULL,NULL,NULL,NULL,NULL,0,200,0,0,20,'MAXIMUM','{\"type\": \"academia\", \"skills\": [\"machine-learning\", \"deep-learning\", \"investigación\", \"python\", \"escritura-científica\", \"matemáticas\"], \"classifiedAt\": \"2026-05-19T14:03:12.894Z\"}','2026-05-19 14:24:59.091'),('e44db31f-b41f-4ac1-9d99-6f429ed2a47e','Sofi y Leo','Árbol automático para el grupo de Telegram \"Sofi y Leo\"','💬',NULL,'INVITE_ONLY','2026-05-17 02:21:19.321','-5066010052',NULL,NULL,NULL,NULL,NULL,'es','INDIVIDUAL',NULL,562,NULL,NULL,NULL,0,200,0,0,20,'MEDIUM',NULL,NULL);
/*!40000 ALTER TABLE `Tree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeExpense`
--

DROP TABLE IF EXISTS `TreeExpense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeExpense` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subTreeName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double NOT NULL,
  `isActual` tinyint(1) NOT NULL DEFAULT '0',
  `incurredAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `TreeExpense_treeId_idx` (`treeId`),
  KEY `TreeExpense_treeId_subTreeName_idx` (`treeId`,`subTreeName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeExpense`
--

LOCK TABLES `TreeExpense` WRITE;
/*!40000 ALTER TABLE `TreeExpense` DISABLE KEYS */;
/*!40000 ALTER TABLE `TreeExpense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeInvestmentProfile`
--

DROP TABLE IF EXISTS `TreeInvestmentProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeInvestmentProfile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isInvestor` tinyint(1) NOT NULL DEFAULT '0',
  `seekingInvestment` tinyint(1) NOT NULL DEFAULT '0',
  `capitalAvailable` double DEFAULT NULL,
  `amountSeeking` double DEFAULT NULL,
  `industries` json NOT NULL,
  `investmentTypes` json NOT NULL,
  `maxRevenueShare` double DEFAULT NULL,
  `maxTermMonths` int DEFAULT NULL,
  `confidenceScore` double NOT NULL DEFAULT '0',
  `purpose` text COLLATE utf8mb4_unicode_ci,
  `portfolioSummary` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `TreeInvestmentProfile_treeId_key` (`treeId`),
  KEY `TreeInvestmentProfile_isInvestor_idx` (`isInvestor`),
  KEY `TreeInvestmentProfile_seekingInvestment_idx` (`seekingInvestment`),
  CONSTRAINT `TreeInvestmentProfile_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeInvestmentProfile`
--

LOCK TABLES `TreeInvestmentProfile` WRITE;
/*!40000 ALTER TABLE `TreeInvestmentProfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `TreeInvestmentProfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeMember`
--

DROP TABLE IF EXISTS `TreeMember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeMember` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invitedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `role` enum('ADMIN','MEMBER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MEMBER',
  `level` int NOT NULL DEFAULT '1',
  `xp` double NOT NULL DEFAULT '0',
  `joinedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `aiModel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aiProfile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aiProvider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aiStatus` enum('IDLE','WORKING','RATE_LIMITED','SUSPENDED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IDLE',
  `isAI` tinyint(1) NOT NULL DEFAULT '0',
  `dailyPoints` int NOT NULL DEFAULT '100',
  `graceUntil` datetime(3) DEFAULT NULL,
  `lastPaymentAt` datetime(3) DEFAULT NULL,
  `monthlyFee` int DEFAULT NULL,
  `paymentStatus` enum('GRACE','ACTIVE','DELINQUENT','BLOCKED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'GRACE',
  `lastDmAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TreeMember_userId_treeId_key` (`userId`,`treeId`),
  KEY `TreeMember_treeId_fkey` (`treeId`),
  KEY `TreeMember_invitedById_fkey` (`invitedById`),
  CONSTRAINT `TreeMember_invitedById_fkey` FOREIGN KEY (`invitedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `TreeMember_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TreeMember_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeMember`
--

LOCK TABLES `TreeMember` WRITE;
/*!40000 ALTER TABLE `TreeMember` DISABLE KEYS */;
INSERT INTO `TreeMember` VALUES ('','a03911c9-b29e-4d58-ab1a-794473d788d5','29e56913-53e3-11f1-9ad5-843a4b23a26c',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 20:31:12.964',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE','2026-05-20 01:47:12.039'),('0685baba-8a34-4c1d-b52d-13fc5cf348dc','5ffd2e2c-0c72-4f5c-adb9-090187ee41cb','18caeb4d-13d9-45a1-a061-5e0a2481637a',NULL,'ACTIVE','MEMBER',1,0,'2026-05-17 14:01:17.978',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('367c23db-7007-4889-9c5c-2247db0185ce','8d93fc6c-f486-49a9-9849-b58bc9201167','d48bd81b-3172-4687-8327-f6f743dac72d',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 14:03:01.425',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('39da7a5d-a94d-438b-9e43-7e7e2756e967','f8be3975-34fb-422f-8746-2ebb436330b4','71e3319c-a60b-45bd-afb9-d2b767977dfe',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 09:51:32.832',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('42155a12-b116-4258-8a69-a14fbe1e8917','a03911c9-b29e-4d58-ab1a-794473d788d5','7c02aba7-ef75-43dc-be8e-92f652b1ed68',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 20:47:13.939',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('4415b393-2b62-4c22-8f9a-20c71fe85e39','60df36c1-9195-4d9b-8a00-b519845a3330','18caeb4d-13d9-45a1-a061-5e0a2481637a',NULL,'ACTIVE','MEMBER',1,0,'2026-05-17 14:01:17.945',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('57a3c748-da5f-4f41-b95a-a4ee89cfc1de','a03911c9-b29e-4d58-ab1a-794473d788d5','56de7a18-ca06-4c79-8efa-bfcb50d2f623',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 07:19:12.726',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('5f272bbf-43e8-4376-a136-b97f74b8ab5b','c20b30fd-13d4-4a44-8bc7-d8b466ec6966','18caeb4d-13d9-45a1-a061-5e0a2481637a',NULL,'ACTIVE','MEMBER',1,0,'2026-05-17 14:01:18.005',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('7d578381-c6fa-48bf-9acb-49063c96772f','1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','677544eb-4a02-457b-b0fe-933f37277158',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 11:37:22.538',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('9aa0f58c-c3b4-4264-860e-d3961857a175','0b80711e-a131-45fb-ae41-eeaa0fc8a876','18caeb4d-13d9-45a1-a061-5e0a2481637a',NULL,'ACTIVE','MEMBER',1,0,'2026-05-17 14:01:18.082',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('a0186719-bdeb-4c49-853b-4fc405dcbe1e','a03911c9-b29e-4d58-ab1a-794473d788d5','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',NULL,'ACTIVE','ADMIN',1,0,'2026-05-20 11:09:10.909',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('a3570649-855f-4d17-a236-b21d85743ca2','a03911c9-b29e-4d58-ab1a-794473d788d5','6d148176-d9f3-4495-b0fd-78192421c1fe',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 07:16:46.462',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('a9cfed56-51ec-11f1-9ad5-843a4b23a26c','a03911c9-b29e-4d58-ab1a-794473d788d5','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',NULL,'ACTIVE','ADMIN',1,0,'2026-05-17 08:33:52.000',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('bd51b286-efd7-4e52-bccc-c4a676107cd4','a03911c9-b29e-4d58-ab1a-794473d788d5','23eddf18-7f49-4c96-bcee-658f324446f2',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 19:20:47.085',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('c1df2c55-5d93-44eb-97b1-02ec08dc7b9b','0a93ae63-b3ec-435e-9700-1324132b047c','a6568a38-9e21-4310-98ce-83e1a9e180f4',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 13:44:48.300',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('c56d94dd-f374-4038-9323-bf267e1c27be','f7c90fd9-63dd-4f1f-946d-d73417c53681','18caeb4d-13d9-45a1-a061-5e0a2481637a',NULL,'ACTIVE','MEMBER',1,0,'2026-05-17 14:01:18.043',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('c61384a6-7f58-4c4f-93ef-337c028706ae','0a93ae63-b3ec-435e-9700-1324132b047c','c0c67870-7659-49df-b663-59b53c838123',NULL,'ACTIVE','ADMIN',1,0,'2026-05-19 13:44:48.408',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL),('ceaad474-018a-4dad-987f-b2c23a6705fe','3ffa83d7-3cb1-4c5a-8f48-bca11671ec6b','18caeb4d-13d9-45a1-a061-5e0a2481637a',NULL,'ACTIVE','MEMBER',1,0,'2026-05-17 14:01:17.916',NULL,NULL,NULL,'IDLE',0,100,NULL,NULL,NULL,'GRACE',NULL);
/*!40000 ALTER TABLE `TreeMember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeMilestone`
--

DROP TABLE IF EXISTS `TreeMilestone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeMilestone` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subTreeName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `milestonePhase` int NOT NULL,
  `milestoneName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetDate` datetime(3) NOT NULL,
  `targetKPIs` json DEFAULT NULL,
  `currentKPIs` json DEFAULT NULL,
  `status` enum('PENDING','IN_PROGRESS','COMPLETED','OVERDUE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `completedAt` datetime(3) DEFAULT NULL,
  `needId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `TreeMilestone_treeId_idx` (`treeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeMilestone`
--

LOCK TABLES `TreeMilestone` WRITE;
/*!40000 ALTER TABLE `TreeMilestone` DISABLE KEYS */;
INSERT INTO `TreeMilestone` VALUES ('01aa90c6-fe7f-42bc-9287-783bc9d594ed','05d82975-85f5-489c-b9ba-f61e1198bb81','General',4,'Autonomía','2027-05-11 00:00:00.000','{\"replicationCount\": 1, \"financialAutonomy\": true}','{\"votingRate\": 0, \"tasksCreated\": 0, \"totalMembers\": 1, \"activeMembers\": 0, \"tasksCompleted\": 0, \"membersOnboarded\": 0, \"revenueGenerated\": 0, \"validatedResults\": 0, \"financialAutonomy\": false}','IN_PROGRESS','2026-05-16 19:08:48.207',NULL,NULL,'2026-05-16 19:08:34.831','2026-05-16 19:11:18.538'),('56591766-96af-4386-b484-a192264edbb4','05d82975-85f5-489c-b9ba-f61e1198bb81','General',1,'Constitución','2026-07-15 00:00:00.000','{\"tasksCreated\": 3, \"membersOnboarded\": 1}','{\"votingRate\": 0, \"tasksCreated\": 0, \"totalMembers\": 1, \"activeMembers\": 0, \"tasksCompleted\": 0, \"membersOnboarded\": 0, \"revenueGenerated\": 0, \"validatedResults\": 0, \"financialAutonomy\": false}','IN_PROGRESS','2026-05-16 19:08:48.122',NULL,NULL,'2026-05-16 19:08:34.831','2026-05-16 19:11:18.425'),('6c277de2-721c-4bc6-9dae-3811cfcf6be6','05d82975-85f5-489c-b9ba-f61e1198bb81','General',2,'Operación inicial','2026-09-13 00:00:00.000','{\"votingRate\": 80, \"tasksCompleted\": 5, \"revenueGenerated\": 0}','{\"votingRate\": 0, \"tasksCreated\": 0, \"totalMembers\": 1, \"activeMembers\": 0, \"tasksCompleted\": 0, \"membersOnboarded\": 0, \"revenueGenerated\": 0, \"validatedResults\": 0, \"financialAutonomy\": false}','IN_PROGRESS',NULL,NULL,NULL,'2026-05-16 19:08:34.831','2026-05-16 19:11:18.462'),('937baa7c-366b-4040-ba38-354bf934737e','05d82975-85f5-489c-b9ba-f61e1198bb81','General',3,'Validación','2026-11-12 00:00:00.000','{\"budgetAccuracy\": 70, \"validatedResults\": 1}','{\"votingRate\": 0, \"tasksCreated\": 0, \"totalMembers\": 1, \"activeMembers\": 0, \"tasksCompleted\": 0, \"membersOnboarded\": 0, \"revenueGenerated\": 0, \"validatedResults\": 0, \"financialAutonomy\": false}','IN_PROGRESS','2026-05-16 19:08:48.172',NULL,NULL,'2026-05-16 19:08:34.831','2026-05-16 19:11:18.504');
/*!40000 ALTER TABLE `TreeMilestone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeRelation`
--

DROP TABLE IF EXISTS `TreeRelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeRelation` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relationType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `socialDistanceCategory` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `TreeRelation_src_tgt_type_key` (`sourceTreeId`,`targetTreeId`,`relationType`),
  KEY `TreeRelation_targetTreeId_fkey` (`targetTreeId`),
  CONSTRAINT `TreeRelation_targetTreeId_fkey` FOREIGN KEY (`targetTreeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeRelation`
--

LOCK TABLES `TreeRelation` WRITE;
/*!40000 ALTER TABLE `TreeRelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `TreeRelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeSandbox`
--

DROP TABLE IF EXISTS `TreeSandbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeSandbox` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` int NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IDLE',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TreeSandbox_treeId_key` (`treeId`),
  UNIQUE KEY `TreeSandbox_port_key` (`port`),
  CONSTRAINT `TreeSandbox_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeSandbox`
--

LOCK TABLES `TreeSandbox` WRITE;
/*!40000 ALTER TABLE `TreeSandbox` DISABLE KEYS */;
INSERT INTO `TreeSandbox` VALUES ('0b70c910-78aa-4f41-bdf6-587acd703625','6d148176-d9f3-4495-b0fd-78192421c1fe',4102,'IDLE','2026-05-19 07:16:46.468','2026-05-19 07:16:46.468'),('10f63c60-a690-4695-9e6f-0d936e285505','d48bd81b-3172-4687-8327-f6f743dac72d',4107,'IDLE','2026-05-19 14:03:01.465','2026-05-19 14:03:01.465'),('15d46be0-0eb8-4c4c-a471-155a86c5125a','a6568a38-9e21-4310-98ce-83e1a9e180f4',4105,'IDLE','2026-05-19 13:44:48.364','2026-05-19 13:44:48.364'),('2fe3ddd4-1573-4028-93ec-ef387009b0e4','18caeb4d-13d9-45a1-a061-5e0a2481637a',4118,'IDLE','2026-05-17 12:24:54.330','2026-05-17 12:24:54.330'),('3247a097-af14-4509-af34-023fd0af07b3','e44db31f-b41f-4ac1-9d99-6f429ed2a47e',4117,'IDLE','2026-05-17 02:21:19.361','2026-05-17 02:21:19.361'),('421a7665-6e3a-4cee-b719-2c963d795773','23eddf18-7f49-4c96-bcee-658f324446f2',4109,'IDLE','2026-05-19 19:20:47.092','2026-05-19 19:20:47.092'),('4f48b431-3a32-4c32-a24d-36d6a7f80f01','56de7a18-ca06-4c79-8efa-bfcb50d2f623',4103,'IDLE','2026-05-19 07:19:12.729','2026-05-19 07:19:12.729'),('50a8dbe5-32dd-4a77-85e3-0694d18d3c8d','7c02aba7-ef75-43dc-be8e-92f652b1ed68',4101,'IDLE','2026-05-19 20:47:13.945','2026-05-19 20:47:13.945'),('81f1e2b5-2107-4bd1-81d2-4fa1cbf425ac','24b1a33c-e3ee-4188-9ca1-417e0f4c2ca6',4108,'IDLE','2026-05-20 11:09:10.914','2026-05-20 11:09:10.914'),('8b66c930-ceec-4cbd-9337-0239b026bc7b','c0c67870-7659-49df-b663-59b53c838123',4106,'IDLE','2026-05-19 13:44:48.469','2026-05-19 13:44:48.469'),('b182a860-b2f6-42d7-a41c-ca4e2b63ad4b','677544eb-4a02-457b-b0fe-933f37277158',4104,'IDLE','2026-05-19 11:37:22.578','2026-05-19 11:37:22.578'),('bd835a54-969d-429a-8a20-a0560a34beff','71e3319c-a60b-45bd-afb9-d2b767977dfe',4100,'IDLE','2026-05-19 09:51:32.862','2026-05-19 09:51:32.862');
/*!40000 ALTER TABLE `TreeSandbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeSkill`
--

DROP TABLE IF EXISTS `TreeSkill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeSkill` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xp` int NOT NULL DEFAULT '0',
  `level` int NOT NULL DEFAULT '1',
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TreeSkill_userId_treeId_skill_key` (`userId`,`treeId`,`skill`),
  KEY `TreeSkill_userId_idx` (`userId`),
  KEY `TreeSkill_userId_skill_idx` (`userId`,`skill`),
  KEY `TreeSkill_treeId_fkey` (`treeId`),
  CONSTRAINT `TreeSkill_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TreeSkill_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeSkill`
--

LOCK TABLES `TreeSkill` WRITE;
/*!40000 ALTER TABLE `TreeSkill` DISABLE KEYS */;
/*!40000 ALTER TABLE `TreeSkill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeStructure`
--

DROP TABLE IF EXISTS `TreeStructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeStructure` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `structureJson` json NOT NULL,
  `acceptedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modifiedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TreeStructure_treeId_key` (`treeId`),
  KEY `TreeStructure_treeId_idx` (`treeId`),
  CONSTRAINT `TreeStructure_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeStructure`
--

LOCK TABLES `TreeStructure` WRITE;
/*!40000 ALTER TABLE `TreeStructure` DISABLE KEYS */;
/*!40000 ALTER TABLE `TreeStructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TreeTechStack`
--

DROP TABLE IF EXISTS `TreeTechStack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TreeTechStack` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stackItemId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `installedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `config` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TreeTechStack_treeId_stackItemId_key` (`treeId`,`stackItemId`),
  KEY `TreeTechStack_treeId_idx` (`treeId`),
  KEY `TreeTechStack_stackItemId_fkey` (`stackItemId`),
  CONSTRAINT `TreeTechStack_stackItemId_fkey` FOREIGN KEY (`stackItemId`) REFERENCES `TechStackItem` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TreeTechStack_treeId_fkey` FOREIGN KEY (`treeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TreeTechStack`
--

LOCK TABLES `TreeTechStack` WRITE;
/*!40000 ALTER TABLE `TreeTechStack` DISABLE KEYS */;
/*!40000 ALTER TABLE `TreeTechStack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TrustTreaty`
--

DROP TABLE IF EXISTS `TrustTreaty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TrustTreaty` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetTreeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashtag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exitosos` int NOT NULL DEFAULT '0',
  `totalIntentos` int NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '0',
  `revocadoPorCorrupcion` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TrustTreaty_src_tgt_hashtag_key` (`sourceTreeId`,`targetTreeId`,`hashtag`),
  KEY `TrustTreaty_targetTreeId_hashtag_activo_idx` (`targetTreeId`,`hashtag`,`activo`),
  CONSTRAINT `TrustTreaty_targetTreeId_fkey` FOREIGN KEY (`targetTreeId`) REFERENCES `Tree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TrustTreaty`
--

LOCK TABLES `TrustTreaty` WRITE;
/*!40000 ALTER TABLE `TrustTreaty` DISABLE KEYS */;
/*!40000 ALTER TABLE `TrustTreaty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('USER','ADMIN') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USER',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `telegramUserId` bigint DEFAULT NULL,
  `skills` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalXp` int NOT NULL DEFAULT '0',
  `isPlatformAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `availableForHire` tinyint(1) NOT NULL DEFAULT '0',
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'CLP',
  `hourlyRate` int DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegramUsername` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_username_key` (`username`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_telegramUserId_key` (`telegramUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('0876799c-fd21-4da0-8c6b-e1fa4eb22376','surveyvoter_1_1779200734132','surveyvoter_1_1779200734132@test.com','$2b$10$xMoaEZuh3LmdYarHvqhJs.WCX0Mod5aWX66gpK2NdjoruYsAiWeV6','USER','2026-05-19 14:25:34.240',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('08e75fbf-4a4b-4b80-8362-b96c60bacad7','Hermes-Nestor','nestor@trustmaker.ai','$2b$10$P7KwJcPPCyL63YKfdh3gm.5LjmgIpSfptjG3fEH8u/T0Vhoz5uT26','USER','2026-05-16 18:55:03.754',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('09667281-c65a-464c-b895-6e21116964bb','biginttester','bigint@test.com','$2b$10$cldvNWBh.f2G2pv4sEnZQO2ijPXUFFl6mSr76inumRJtMUVvpP4/2','USER','2026-05-16 14:49:26.764',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('0a08c64a-3126-4492-8e00-9c4f44f43086','sqliso_1779201097161','sqliso_1779201097161@test.com','$2b$10$BWx/EFBhhuqs2iNJaonQDuwRQAOX83N8HhtS3h6p1TRBuCkk5UKfG','USER','2026-05-19 14:31:37.449',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('0a258c6d-5917-4ed6-9555-a8dbd5706720','Diego Morales','diego@demo.com','$2b$10$wOwM4qRnpDCVnf7uRHbnOe1OS9hhtRNO8jb1f/.KhCrl.wxwAOvkq','USER','2026-05-16 18:55:02.933',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('0a93ae63-b3ec-435e-9700-1324132b047c','crosstree_1779198287839','crosstree_1779198287839@test.com','$2b$10$8xtuTMQVmRbFT1kQIk41.eiwmdzSoPVoDLwKrYePjzJNMQQg2TmA6','USER','2026-05-19 13:44:48.207',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('0b121a5e-9b0f-4ed7-9cef-95200af8ec44','tooltester2','tooltester2@test.com','$2b$10$OGYI.6h3RmCaUGyjje8.WeUTnGI0w93wnJagG1F2A07okEDqiD0zW','USER','2026-05-16 16:38:43.928',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('0b2cd09b-01b3-49b6-9a6f-6f64409a98a8','Elena Vargas','elena@demo.com','$2b$10$8Z.2hlErs7ZuPxYQTB1k/eEnrm1PJPzRzdfjdRRWl5Up.A5MrLx4i','USER','2026-05-16 18:55:02.821',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('0b80711e-a131-45fb-ae41-eeaa0fc8a876','tg1334066643',NULL,NULL,'USER','2026-05-17 14:01:18.063',1334066643,NULL,0,0,NULL,'GRM',0,'CLP',NULL,NULL,NULL),('0f760741-02be-4c8d-a33f-99d6f7fc19bc','Tomás Núñez','tomas@demo.com','$2b$10$3XvaM9xQhJAelhnaHdItwegLC0/SIVDa32vEfYcI5JHPPuaY0ZinS','USER','2026-05-16 18:55:03.644',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('118bcfdb-bd89-42ce-a95b-83020a97dc5f','test_admin',NULL,'$2b$10$Ufl6QafLnE0kc85PT3YFl.5iEpANMx16Qi5UWxrMbOlc/06vQMoxO','USER','2026-05-15 04:57:19.234',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('134b2149-eadc-4e83-ade4-a1b1c4af9cce','dev_back_1','dev1@test.com','x','USER','2026-05-15 00:35:48.264',NULL,'{\"backend\":80,\"python\":70}',0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('14f24111-6c3d-4ddc-9669-73d0d3703cd0','tester2','tester2@test.com','$2b$10$.w7Dm3y57TKVXh/cvgMZW.McYeHxSlFkGeuiRqqdcAj8p/JBH7VWC','USER','2026-05-13 13:16:55.839',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('1533fbac-698c-42d7-a161-75f3434020f9','concierge_58696',NULL,'$2b$10$QOwrfSyTwcBk0cqgNei4IOgd5hcnrKmBfVoFmDd97EdJ1UWZey2gC','USER','2026-05-15 05:03:29.495',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('1811eed2-9e22-46e1-b5bd-791a3cb2263b','tg8958735655',NULL,NULL,'USER','2026-05-17 14:23:37.775',8958735655,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('18c35f7a-ac4d-4939-bc31-688b95eabf3c','test_hierarchy','test_h@test.com','$2b$10$HAElObyF/CgKXV2a0lAAlubpbdR1uce3ZfWL./bzM8VDYSDeKtpf2','USER','2026-05-15 00:16:08.709',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('193f5b52-1c15-4def-83bc-d3bdd760c992','Roberto Fuentes','roberto@demo.com','$2b$10$0uvUZaURMiiopsYPphQ6b.RTv7HsPT9HcsXU0/4BeQXNIsjNh.h7.','USER','2026-05-16 18:55:03.535',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('1d776ba8-614e-4222-b1f5-c8e1f7e0c66e','n6integration','n6-integration-test@trustmaker.dev','$2b$10$nTh32fGFOdohVDpxvYJW4OjJGKMNtromAkj6/AKzZZDYFE4Jlv/.i','USER','2026-05-19 11:22:35.105',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('22972369-0833-45d6-a5c6-37d7157061d0','testhist2','testhist2@test.com','$2b$10$c8ock4uzHh.jus9F50m9NO7CTe5.hxqC3nl4fX36fQ/W6TjWr6mH6','USER','2026-05-14 00:28:30.518',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('2621936f-70cb-43f6-8ef0-5a8244383d5a','finaltest9','finaltest9@test.com','$2b$10$o/LtsiFJCpSD7ijbA4HeYe7GdYUfb5yEQ0eWy1MbiPg0E2p6Dn6NO','USER','2026-05-16 16:55:20.008',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('2b39885b-7421-4e3a-848b-58c4c9372279','invtest2','invtest2@test.com','$2b$10$ygcNzMM/5LNEuB8NXMz5o.LOlfBozft4tbYuGOEjXjBkOsz/MVhvW','USER','2026-05-16 17:21:22.438',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('2cce65d3-4489-40fc-9689-760f97e29a32','Pedro Rodríguez','pedro@demo.com','$2b$10$RQNzi0A9uCdd.d5WSvA8gO4qa4e7y9slIhVJtLIbclcHlBjcqVWZq','USER','2026-05-16 18:55:02.485',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('3218c868-514d-4327-87fc-e1afaec8ce72','treetestX','treetestx@test.com','$2b$10$QaLQoa0SjXIrPwgtBV86a.4pTi5bDX.di9eioM.jgjF/T2I916eMm','USER','2026-05-16 16:55:32.799',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('379a2d98-460e-4c0c-a3d5-fc70bb541ca1','tester1','tester1@test.com','$2b$10$JdSqnqX1O6O3lDs77idLfO9FrZYOR9At5ZSg1.hNpDkZ7D7xo63OK','USER','2026-05-13 13:16:26.973',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('39ccf25c-fdbc-4bc2-9a22-5faf51c8fd9c','María García','maria@demo.com','$2b$10$Krjrd15tSJN5A972npVnBOAyX5NWJPjJmhOx0dCc0a2Oub8ysfYce','USER','2026-05-16 18:55:02.372',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('3ab38cbb-8bbb-4515-a3ef-198cb6abfa23','e2e_70757',NULL,'$2b$10$GLJc329hDHocfjmHZlmVIOd8nX3pjs97pczgK8Y6eUHqE4cHODEoa','USER','2026-05-15 05:02:23.265',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('3d4cf853-e23d-43da-b661-e30f09f2b680','surveyvoter_3_1779200734549','surveyvoter_3_1779200734549@test.com','$2b$10$JJIE5xsdI3kjIhtphtHOMeE2nXprrlHPa1Pi07WB/mDuJhkOWyNuO','USER','2026-05-19 14:25:34.667',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('3f174e8e-5d21-434b-9705-68413394d778','sandboxtest_1778851515793','sandboxtest_1778851515793@test.com','$2b$10$wP7BSU8i0ybbj2mKP2bydehKESgjDT.kW3bx7nHwRu2f0/g8eT2pu','USER','2026-05-15 13:25:16.071',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('3ffa83d7-3cb1-4c5a-8f48-bca11671ec6b','tg8735952932',NULL,NULL,'USER','2026-05-17 14:01:17.892',8735952932,NULL,0,0,NULL,'Marialy',0,'CLP',NULL,NULL,NULL),('457bd5da-9edc-4217-90f9-93e7a320f455','structuretest','structure@test.com','$2b$10$8oYHD2FliLtnrdNUp3ZOMuDqkTgxHqmSKrWAQfL4rUqBOH62vGa7G','USER','2026-05-16 19:08:19.564',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('471a81d1-2a9b-4fdf-8f30-116178eaf85b','test','test@test.com','$2b$10$kmR7ZwCQ1lx0aX48QqaBPeXfUUDgeUTwh6WARuYmZ4yM6tx/RsMny','ADMIN','2026-05-13 12:50:40.896',NULL,NULL,0,0,'es',NULL,1,'CLP',NULL,NULL,NULL),('4ba12ced-0fad-4aeb-af79-490873802100','sandboxtest_1779038047208','sandboxtest_1779038047208@test.com','$2b$10$S5Ao4Bi0a1yZR4QJoeL9.uUrsz7CGm/uL90KI3IZrqEkU42UYKPAK','USER','2026-05-17 17:14:07.471',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('4c3108db-7d9e-4443-8f3a-6dac1d17be9b','testhist','testhist@test.com','$2b$10$7MpG3RWD4D03rPImurezrOuG7vYfQ7d5SiXZKQ1IzYde81NFEpuaW','USER','2026-05-14 00:28:14.629',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('4ca8ac1f-11dd-44e7-a323-42184a0e7a25','dev_front_1','front1@test.com','x','USER','2026-05-15 00:35:48.291',NULL,'{\"frontend\":90,\"design\":40}',0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('4cc9f888-516f-4847-94af-41ce5a1635e4','worker_person','worker@test.dev','$2b$10$He3bNQEMNOIDUGoN1pcXSO/XITKkybmcNFyz9ek/DjZwysWWlXtV.','USER','2026-05-18 15:35:43.797',NULL,NULL,0,0,NULL,NULL,1,'CLP',50000,'Santiago',NULL),('4e230f5d-4b16-4082-b504-309106a90d34','roletester3','roletester3@test.com','$2b$10$jVuB.Odpa63n5FHQlKgB2.NyuGX9vf9CkBVaBtBIMH7BakcqIq65u','USER','2026-05-16 17:28:30.031',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('5d47ff7a-b727-4fef-88bc-a04469384b5c','sqliso_1779201735972','sqliso_1779201735972@test.com','$2b$10$k1aPjpMKTkaXeyM/VZe4veP6aXwUMpNfMblzJLHe062KKE1/psXtG','USER','2026-05-19 14:42:16.260',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('5ffd2e2c-0c72-4f5c-adb9-090187ee41cb','tg8080038481',NULL,NULL,'USER','2026-05-17 14:01:17.960',8080038481,NULL,0,0,NULL,'Pablo',0,'CLP',NULL,NULL,NULL),('60536cb2-53c9-11f1-9ad5-843a4b23a26c','tg8745013028',NULL,NULL,'USER','2026-05-19 17:26:19.479',8745013028,NULL,0,0,NULL,'Sofia',0,'CLP',NULL,NULL,NULL),('60c0e19e-75d8-4dd8-898a-02e7b6253610','Alpha','alpha@trustmaker.demo','$2b$10$ANup4F3u13p1CPDOua3M8O30Emub3Wj1eEutVyh0Zzo5jp95Hqxqm','USER','2026-05-16 18:55:04.443',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('60df36c1-9195-4d9b-8a00-b519845a3330','tg8547740563',NULL,NULL,'USER','2026-05-17 14:01:17.934',8547740563,NULL,0,0,NULL,'Natalia',0,'CLP',NULL,NULL,NULL),('614b8f42-4e90-4331-9cf9-2a0bb6589e16','infratest3','infratest3@test.com','$2b$10$NjfO3yQ/2f4.mLQMQFhNG.4E4e3NmHap8cc09DpczKbMnILTV.NfS','USER','2026-05-16 16:47:28.707',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('63ec21f5-9282-4f15-9f34-d5286d2ad0c5','dev_design_1','design1@test.com','x','USER','2026-05-15 00:35:48.349',NULL,'{\"design\":95,\"figma\":85}',0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('66c04512-b98e-48ef-b5ac-14386e21f0b8','sandboxtest_1778784630464','sandboxtest_1778784630464@test.com','$2b$10$LG8B3IPcoogtVwdhLFk/p.G1Tiik5i/HKGw.6CemmYOAvQzVM3hka','USER','2026-05-14 18:50:30.640',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('6835f00a-c875-4a23-bf8d-5273a381c21f','ssh_test_4172',NULL,'$2b$10$UPfRwmIhen7RpEJohHA.XOoWlsylDVaCwGI3VLSzz8/ugrRM2iMp2','USER','2026-05-15 05:01:27.252',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('68907da8-6eca-41aa-affa-e4710435daff','sandboxtest_1778784161666','sandboxtest_1778784161666@test.com','$2b$10$H3UyYgGgZ5ALfzSmBBhOW.HsJGukUBfBg3KcAX5DP0q7h2ogex.ue','USER','2026-05-14 18:42:41.836',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('698ca1b3-8f97-4156-bb79-88f0869781ca','sqliso_1779201492838','sqliso_1779201492838@test.com','$2b$10$LByIHPgbeHypjfWy9G4IvOPhSLV87kq2/jvwZJdpVNAwHX9SSSHLa','USER','2026-05-19 14:38:13.114',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('6dbb9524-8a50-4361-b3f4-d728f5f6f1c2','admin','admin@admin','$2b$10$2fB8SsjdL6TNOFpfMjaBhOmqFisdyQJx7rEPmDDjVTRDmppMUxu9a','ADMIN','2026-05-13 18:50:06.609',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('6fb42ad9-11d5-443a-8ab9-4915ea5da9c3','verifyZ','verifyz@test.com','$2b$10$cT53eDuIkvWE4Va94aFi8.2zNuGJzpFI02dxZ8zZZnEuR/ymAsnG.','USER','2026-05-16 16:56:00.885',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('6fe69220-33e9-4c86-8e5d-b8ba924c5962','Leo','leo@demo.com','$2b$10$t67KAAEz6VP7fRj1hlZqJ.6nWSDpOilO5Kf3ZZTEBDUjYNcz4pR4u','ADMIN','2026-05-16 18:55:02.265',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('705ea231-a674-446d-bc21-b4691320b409','Carlos López','carlos@demo.com','$2b$10$9Pfbu4KrsVYo2Q9UGoWId.sxOO9FH46eyKxaMGIV.hNMRnF0rjeue','USER','2026-05-16 18:55:02.706',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('71564219-1f09-457e-8b41-ef328da7fd80','structadm','structadm@test.com','$2b$10$NPQHsLY4B968IlT05EjRDel860L38KUDoR4Ff7UaWm7VSFyE65vS.','USER','2026-05-16 19:08:34.382',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('723d908a-75b6-40ff-89c0-e7272f514afb','surveyvoter_2_1779200699441','surveyvoter_2_1779200699441@test.com','$2b$10$X4i4vkkpZ5lF4dv2ZVTFLeX4lCsSMvnbpSJ7Ss6ocrMCFuY0jLIEy','USER','2026-05-19 14:24:59.579',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('752a5c35-8903-4fd4-95bf-f790b8ddb292','testhist4','testhist4@test.com','$2b$10$.K5IWvcNg1MOe0M9L50doO2GNA.QPK7AP4II/Z6iSxRPflXNOvFqW','USER','2026-05-14 00:29:02.501',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('78f7d145-ab6f-48f5-a836-c93a2c02fd52','schematest','schema@test.com','$2b$10$aTWVgLsjNRS.hAAc0nAv9eG2ZMMCKP3e5B8I0XnsUttEduQtjm8nu','USER','2026-05-16 18:47:26.766',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('79afe021-3f5a-4fb3-b6d4-4638b921d63f','dev_back_2','dev2@test.com','x','USER','2026-05-15 00:35:48.280',NULL,'{\"backend\":60,\"java\":55}',0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('7a3a01ae-7dcb-445d-942f-9996de05ddad','sandboxtest_1778855101922','sandboxtest_1778855101922@test.com','$2b$10$sO8BF8S8mLQW422qJlo3x.i2Gxjt9Tn4WIfGY.bDsaGFNLAW8omKa','USER','2026-05-15 14:25:02.172',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('7d7465e7-e3b8-4f85-8e01-40b2d958392a','roletest','roletest@trust.com','$2b$10$4Zq1AnDSZS/ku3cHP/CJr.FtyU.aeTK0KxBUrCswtcjxsKh5jw/mG','USER','2026-05-16 16:40:11.224',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('7ec54910-cfc2-41b7-96e8-beea4f1017f9','crosstree_1779198487658','crosstree_1779198487658@test.com','$2b$10$b1tNZ6vfZROxHiGZ/NTaZuPaSikvXqrzBcUmFLGJT0M.pGdFKlLHC','USER','2026-05-19 13:48:08.004',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('821731f9-06bc-47e8-ad1e-d6c95427ef14','Camila Torres','camila@demo.com','$2b$10$9v.ccldJ4CadHyQKDXg50OOxXvhhAjHM1.5.BW6JV.ox7CHdPVs9i','USER','2026-05-16 18:55:03.298',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('835ec2b6-c416-4218-bced-ead9433c32c1','Javier Herrera','javier@demo.com','$2b$10$pxFqmpyxIK/KDmNyW90aSeXck/dIrnJgmwJ0o6Nqw9P/hIryW3nRS','USER','2026-05-16 18:55:03.169',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('86a75cdd-221c-4ce0-8f07-7da08e21fdfb','cloudtest5','cloudtest5@test.com','$2b$10$n5S/71X6ZcfplSXSGMGbv.qzVDsc2QVzrQNkbAUzMG4V9W7yJ41lq','USER','2026-05-16 16:48:04.725',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('86ab07ff-5932-46ea-ad89-a742815d4e8d','sandboxtest_1778851276872','sandboxtest_1778851276872@test.com','$2b$10$GnHFZOAI4gG8HnLPi9nJ/.HsT2QDfd1PjEovkp2J3mWQPY6l6o0KW','USER','2026-05-15 13:21:17.127',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('87809908-5136-4782-bb91-421b58281ad2','byotest','byo@test.com','$2b$10$soySW8UT77.Sb5LGUD3JZOsC8s2TzLY5mkqb2xvP4h2czznXXTu86','USER','2026-05-13 16:46:56.336',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('87dad90d-cc5f-44df-8efa-9e76bfbfce0f','testv3','testv3@test.com','$2b$10$DKz9xiiVid25OrhfnPGvve3L/LjgDl/1Oie4Dkp1/jkyhOIvcHQ6a','USER','2026-05-13 12:52:10.656',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('892980d6-a579-4912-9763-f058203bc362','exttask2','exttask2@test.dev','$2b$10$s9gBUPXxsoOLupgmtMBdxOI4MAobySz5ip/Z.evRjDeMVn5dSLMym','USER','2026-05-18 15:35:18.976',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('8d93fc6c-f486-49a9-9849-b58bc9201167','integration_test','integration@test.com','$2b$10$0BBaoGrJl.ucqtIikvAQDeXN4pLdq4lJqw7gCWxAHq/tDZ2UJkbve','USER','2026-05-19 14:02:13.060',NULL,NULL,0,0,NULL,NULL,1,'CLP',NULL,NULL,NULL),('8f9a3896-671e-4a44-826c-253829bbebd9','roletest2','roletest2@trust.com','$2b$10$ZMK69xfo4UOGklaXhR4aAuPzENDIK7uBBNkpGQf6wb/XWQtgwlngG','USER','2026-05-16 16:41:13.122',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('926fb090-82c5-4774-89cc-038682fd8994','byotest2','byo2@test.com','$2b$10$V/dflYIs2R2SDa6fZETmkufo.zGOqYNe6htzg81iwNj45fBXgtROW','USER','2026-05-13 16:47:17.868',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('92a06db9-bd98-425b-bbd4-0002af7bbc09','Hermes-Mnemosyne','mnemosyne@trustmaker.ai','$2b$10$ISvgJzNiivXc719DQIR6s.73sTBs9kx/czkpfMHb.2sR./Q2E8jES','USER','2026-05-16 18:55:04.324',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('942125f0-2e1c-4c4c-a382-ebfb63f17f3d','sandboxtest_1778845317109','sandboxtest_1778845317109@test.com','$2b$10$FXP2qvRGu3N6S5dRA97ha.nWmRMXxR0vAU2rWIZ34LvlQxa4n.vBC','USER','2026-05-15 11:41:57.268',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('9e44ddf5-bb54-4697-be45-e1a8f92b219e','surveytest_admin_1779200733734','surveytest_admin_1779200733734@test.com','$2b$10$B37b1Iik8E64ji4HLiJRyuJc7Ul2l0/MW1906DLMtvOaVFUKhF6Mi','USER','2026-05-19 14:25:34.011',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('9e4c07a8-0780-44de-bc68-0cb821539d00','Gamma','gamma@trustmaker.demo','$2b$10$q9YHhyreTMM.jd6RDpfRJegLvdM40PSKeKHarLL1WnjBqQZKXbuuq','USER','2026-05-16 18:55:04.663',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('a017be03-4b21-4477-992d-0da855531b8e','investest','investest@test.com','$2b$10$Uw/P6evBlBQAaqgOYWOP0e7UF83MFTdU80nXY1Z6TjG.Fm0yZMctS','USER','2026-05-16 17:21:04.559',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('a02529a7-ff2f-4189-8651-16af77d6646b','test_ssh_admin2',NULL,'$2b$10$UKghAByifyibUFrm6.EfY./1siJWP19p.MtjysBvcEzJbrUg2COmu','USER','2026-05-15 05:00:26.269',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('a03911c9-b29e-4d58-ab1a-794473d788d5','tg_7516190425',NULL,NULL,'USER','2026-05-14 09:52:19.757',7516190425,'test,backend,frontend',0,1,'es','Leo',1,'CLP',NULL,NULL,NULL),('a103e261-4bbd-4dd9-a350-6cbad3f01a64','surveyvoter_2_1779200734364','surveyvoter_2_1779200734364@test.com','$2b$10$T/d9YgCUM7JfuYKN3YJNO.PhTDX1WGBj54VxSU2pbrnColRcfajWu','USER','2026-05-19 14:25:34.488',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('a77f4b7f-12f3-4ab2-9860-1b3acbedb622','Hermes-Asclepius','asclepius@trustmaker.ai','$2b$10$s6XpkI3eGS5FVpgqZonoXOd0nAevLTkyReMVSH0Gndio4ZuMhxk5W','USER','2026-05-16 18:55:04.199',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('a8f9dba7-2d27-404c-87a7-23916748ba03','Ana Martínez','ana@demo.com','$2b$10$/jCTa65bTikgGrgRafATNuF4oAcu4Ji/mRVwBzZPjyRq/Y6RWEBWq','USER','2026-05-16 18:55:02.593',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('ab91f76e-2028-4f2b-9ed0-235e851e95d8','dev_front_3','front3@test.com','x','USER','2026-05-15 00:35:48.329',NULL,'{\"frontend\":60,\"css\":90}',0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('abead984-c09c-4fba-8460-0f0537b2dea1','surveyvoter_3_1779200699636','surveyvoter_3_1779200699636@test.com','$2b$10$S6Ba5bcgn9fMP1NF7zeJkOQc1r3Im1Gs/aU8QGfYMaR3Tu/QgfdRu','USER','2026-05-19 14:24:59.774',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('ae90dc20-de65-4e66-95aa-376767826016','sandboxtest_1778784098837','sandboxtest_1778784098837@test.com','$2b$10$IY2xPXxsKlJkw41cChenqepXJCjP8k2vwkbL/bNGlAP0QJ.mgMKNS','USER','2026-05-14 18:41:39.016',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('ari','ari_system',NULL,NULL,'USER','2026-05-18 13:05:31.303',NULL,NULL,0,1,NULL,NULL,0,'CLP',NULL,NULL,NULL),('b41fd507-3706-422d-bbd1-206f3a3805f7','hermestest','hermes@test.com','$2b$10$44lc.yJT7q2.JByWHyITlOSHmqYwglrO/vRMXim76g8EgIM5kRxz6','USER','2026-05-16 16:32:53.718',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('b71a1f60-81c4-4d7a-af4a-a822b7826e1e','Sofía Paredes','sofia@demo.com','$2b$10$78jUkXC76/5m1ZtFHNygWeDgAIK5xg43SQCYky3R4fgsXnxNJ6bni','USER','2026-05-16 18:55:03.408',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('befd8a78-6838-4401-8fec-8c387188c4b2','test5028','test5028@test.com','$2b$10$vG2Ut5TLRvME01OtubPNCuXtkMkyEhywoW..VivOYzaQnPT/8QeZi','USER','2026-05-16 16:38:29.208',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('c20b30fd-13d4-4a44-8bc7-d8b466ec6966','tg7447548487',NULL,NULL,'USER','2026-05-17 14:01:17.992',7447548487,NULL,0,0,NULL,'Ricardo',0,'CLP',NULL,NULL,NULL),('c3888834-11ca-4e59-a693-1a557aea49fa','Hermes-Prometheus','prometheus@trustmaker.ai','$2b$10$ToHzo89Um4EeZq9i4HSj/.g9ZdXDoufOzOEqQFAUKcWXSbzC6VKJS','USER','2026-05-16 18:55:03.973',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('c5d7f4f1-afbe-4cc7-aa67-81c82485d2a2','testhermes','testhermes@demo.local','$2b$10$1LnQSnUoR5Sw4EHrlmIE7OJpTLI9gnNF8a601j/SueqtA6e5jgB4O','USER','2026-05-16 14:34:19.403',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('c94d5e30-c52e-453c-b80d-8ff3f329cbf9','schematest2','schema2@test.com','$2b$10$tdwL3Xdxi4BxF2.k5oaAYe/cwqsIN9RDeRSNPBPzhvOMYamyHfzZq','USER','2026-05-16 18:47:39.000',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('ca933a62-0228-412c-be01-9cfe4262c2d6','sqliso_1779201416931','sqliso_1779201416931@test.com','$2b$10$R4c657x/M31jerJBoNsFAeMsHJH1buq2f9r3CfWxFnBdAV8JYjdxS','USER','2026-05-19 14:36:57.257',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('caf27a62-1a0f-4615-9e18-c07d43813883','exttask_tester','test@exttask.dev','$2b$10$8OeNgT8EcnmkP.FrME4fre9ZnuQc.pavbrE5j4weTuEtqS1bZ2LA6','USER','2026-05-18 15:34:51.076',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('cdb2ed1b-e73f-4994-8600-738cbd515f5e','Hermes-Artemis','artemis@trustmaker.ai','$2b$10$/iDKx8Lzw8SAHWYIzxNY1OmWyCN9XMGAy6fx6Xdx4QaviO9OsVKgi','USER','2026-05-16 18:55:03.865',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('cea7d32a-a582-4ecc-9988-72fa0d0e6e6c','testsocial','testsocial@test.com','$2b$10$zMTlXedDQGEdRcsMBTSH3.Jth4nuQE3X11n1tOFd9CzEGWbh7IcNS','USER','2026-05-16 15:57:53.832',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('cf27b711-0b6b-4bb5-a9e0-bf3aab44971c','testuser_social','test_social@test.com','$2b$10$7KbuLr3.hXlfI.yTkp65hO8YODXFDK3kCUo9eHqeSzBk01eWsXVT6','ADMIN','2026-05-16 15:48:21.253',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('d1a2989d-903a-4667-91cd-408cc462648f','Hermes-Demeter','demeter@trustmaker.ai','$2b$10$KLH7qGZp5Vr.7c8s3RxdLug0F6xO6y1.wlGfqiRVRinAcpamxp/O2','USER','2026-05-16 18:55:04.081',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('df7de8fb-e02c-4726-b896-0122cc86037c','pricingtest','pricing@test.com','$2b$10$EsXazrOI44WBguVjLAVUP.mfZULM1CVNTuoz5T/B/PqXen47FUOA6','USER','2026-05-15 00:33:18.502',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('e0712bee-a5e5-4a4e-b8f3-41b115d8bda9','surveytest_admin_1779200698796','surveytest_admin_1779200698796@test.com','$2b$10$VXthLhkpsLtUVl6FQlUf0utVV3PovMVI/tiAt0TNY1F5I5RTPB7oq','USER','2026-05-19 14:24:59.089',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('e695c7d3-daf8-4643-a3bb-0881b5dceedd','TestAgent42','test42@local','$2b$10$Sk21exNLue4LF81S7Ch2S.tkY33W.Rf75OjUA9.UmoYk/rRfafQlC','USER','2026-05-13 15:28:38.377',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('e7d16ca7-0f65-412c-9e35-0ddd44c3d218','surveyvoter_1_1779200699209','surveyvoter_1_1779200699209@test.com','$2b$10$NfPGwH76krsvkdY4XM84quzl92TiWnqkYMDSpl37JcK7fqG2Q8via','USER','2026-05-19 14:24:59.331',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('e8ea827e-1378-4ed1-85ce-4850ddc7221f','sqliso_1779201599160','sqliso_1779201599160@test.com','$2b$10$JeUEbLCsxO7isZ.KVJ5bo.5VopzEnaujnYmC/FxaGSHfuZCbCzUjS','USER','2026-05-19 14:39:59.436',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('ebf76fd4-281d-4ca6-ac52-0035556c259e','sandboxtest_1778851586754','sandboxtest_1778851586754@test.com','$2b$10$tCbylAQ9wsHaI7CHUMaiOe8dcdzuxTAmjcuHiAr.Ulg6si2dc3F8e','USER','2026-05-15 13:26:27.002',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('edad98a4-7db3-4318-98ce-55eabab586ed','Valentina Ruiz','vale@demo.com','$2b$10$3W.I9LB/0GzWH3mXIdLEIeC/D5a5Z4mQ8QTw5EJqBDUgzAsnvojb6','USER','2026-05-16 18:55:03.055',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('f31cf403-afa7-4b2f-917a-9692b50063cc','testhist3','testhist3@test.com','$2b$10$ZLvw/LI6MpIiEGRIbpMHBuAYYWabS9KBRSI2cO8jKCxlzYqVbQd8W','USER','2026-05-14 00:28:44.532',NULL,NULL,0,0,'es',NULL,0,'CLP',NULL,NULL,NULL),('f73b8593-2d52-4a8a-8201-58545e5371fb','Beta','beta@trustmaker.demo','$2b$10$FTW25ayWp0TuxLcWmqDijup8MZWAOrI6/CjANxJpu95S.af8mS5UK','USER','2026-05-16 18:55:04.555',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('f7c90fd9-63dd-4f1f-946d-d73417c53681','amandarivasm',NULL,NULL,'USER','2026-05-17 14:01:18.025',7418546839,NULL,0,0,NULL,'Mandy',0,'CLP',NULL,NULL,NULL),('f8be3975-34fb-422f-8746-2ebb436330b4','n6test','n6test@integration.test','$2b$10$IFkQ7AQk.dzGMShkYI2EKe2eHhK/Xjca2H.AkLYZHTOzKxzCJaudK','USER','2026-05-19 09:44:12.792',NULL,NULL,0,0,NULL,NULL,0,'CLP',NULL,NULL,NULL),('f936b726-ca07-42c6-a31c-d9c37fd25438','dev_front_2','front2@test.com','x','USER','2026-05-15 00:35:48.303',NULL,'{\"frontend\":75,\"react\":80}',0,0,'es',NULL,0,'CLP',NULL,NULL,NULL);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserAI`
--

DROP TABLE IF EXISTS `UserAI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserAI` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` enum('OPENAI','DEEPSEEK','ANTHROPIC','CUSTOM') COLLATE utf8mb4_unicode_ci NOT NULL,
  `apiKeyHash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monthlySavings` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `UserAI_userId_idx` (`userId`),
  KEY `UserAI_userId_provider_idx` (`userId`,`provider`),
  CONSTRAINT `UserAI_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserAI`
--

LOCK TABLES `UserAI` WRITE;
/*!40000 ALTER TABLE `UserAI` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserAI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserContact`
--

DROP TABLE IF EXISTS `UserContact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserContact` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserContact_userId_contactId_key` (`userId`,`contactId`),
  KEY `UserContact_contactId_fkey` (`contactId`),
  CONSTRAINT `UserContact_contactId_fkey` FOREIGN KEY (`contactId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserContact`
--

LOCK TABLES `UserContact` WRITE;
/*!40000 ALTER TABLE `UserContact` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserContact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserSkillXP`
--

DROP TABLE IF EXISTS `UserSkillXP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserSkillXP` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skillTag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accumulatedPoints` int NOT NULL DEFAULT '0',
  `completedTasks` int NOT NULL DEFAULT '0',
  `cachedPercentile` int DEFAULT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserSkillXP_userId_skillTag_treeId_key` (`userId`,`skillTag`,`treeId`),
  KEY `UserSkillXP_skillTag_treeId_accumulatedPoints_idx` (`skillTag`,`treeId`,`accumulatedPoints`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserSkillXP`
--

LOCK TABLES `UserSkillXP` WRITE;
/*!40000 ALTER TABLE `UserSkillXP` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserSkillXP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserSubscription`
--

DROP TABLE IF EXISTS `UserSubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserSubscription` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paddleSubscriptionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','PAST_DUE','CANCELED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `planId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentPeriodStart` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `currentPeriodEnd` datetime(3) NOT NULL,
  `canceledAt` datetime(3) DEFAULT NULL,
  `monthlyCost` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserSubscription_paddleSubscriptionId_key` (`paddleSubscriptionId`),
  KEY `UserSubscription_userId_idx` (`userId`),
  KEY `UserSubscription_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserSubscription`
--

LOCK TABLES `UserSubscription` WRITE;
/*!40000 ALTER TABLE `UserSubscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserSubscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Waitlist`
--

DROP TABLE IF EXISTS `Waitlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Waitlist` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treeName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telegramChatId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'WAITING',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `notifiedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Waitlist_status_idx` (`status`),
  KEY `Waitlist_contactUserId_idx` (`contactUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Waitlist`
--

LOCK TABLES `Waitlist` WRITE;
/*!40000 ALTER TABLE `Waitlist` DISABLE KEYS */;
INSERT INTO `Waitlist` VALUES ('0d1cb2b2-f889-4bee-aa31-120a61c93e4d','Nelly y Ari','-5237832689','8954064089','WAITING','2026-05-18 23:20:58.272',NULL);
/*!40000 ALTER TABLE `Waitlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkerLevelHistory`
--

DROP TABLE IF EXISTS `WorkerLevelHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WorkerLevelHistory` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xpDelta` int NOT NULL,
  `reason` enum('TASK_COMPLETED','XP_DECAY','ADMIN_ADJUST') COLLATE utf8mb4_unicode_ci NOT NULL,
  `taskId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `WorkerLevelHistory_userId_idx` (`userId`),
  KEY `WorkerLevelHistory_userId_skill_createdAt_idx` (`userId`,`skill`,`createdAt`),
  CONSTRAINT `WorkerLevelHistory_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkerLevelHistory`
--

LOCK TABLES `WorkerLevelHistory` WRITE;
/*!40000 ALTER TABLE `WorkerLevelHistory` DISABLE KEYS */;
INSERT INTO `WorkerLevelHistory` VALUES ('4bb7166b-5aa9-444a-b79a-ebad85017f93','a03911c9-b29e-4d58-ab1a-794473d788d5','python',-13,'XP_DECAY',NULL,'2026-05-20 07:00:00.116');
/*!40000 ALTER TABLE `WorkerLevelHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkerSkill`
--

DROP TABLE IF EXISTS `WorkerSkill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WorkerSkill` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xp` int NOT NULL DEFAULT '0',
  `level` int NOT NULL DEFAULT '1',
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `WorkerSkill_userId_skill_key` (`userId`,`skill`),
  KEY `WorkerSkill_userId_idx` (`userId`),
  CONSTRAINT `WorkerSkill_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkerSkill`
--

LOCK TABLES `WorkerSkill` WRITE;
/*!40000 ALTER TABLE `WorkerSkill` DISABLE KEYS */;
INSERT INTO `WorkerSkill` VALUES ('bf2e45ce-538d-11f1-9ad5-843a4b23a26c','a03911c9-b29e-4d58-ab1a-794473d788d5','python',487,10,'2026-05-20 07:00:00.094');
/*!40000 ALTER TABLE `WorkerSkill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('10b0e61d-4f87-11f1-9ad5-843a4b23a26c','4fe83829eab47c61b4f90329de995277a0be6c96c6ba825864ec45d829af602b','2026-05-14 07:21:34.000','20260514071500_add_payment_split_and_balance',NULL,NULL,'2026-05-14 07:21:34.000',1),('18e297d8-3aa9-48ef-bab7-23bb0e2a5679','8243eecd88b1b5861e624ece56691bd3b35ef7fe8446b4e70b9481a970c8210a','2026-05-16 15:35:05.907','20260516_agent_intervention_rating','',NULL,'2026-05-16 15:35:05.907',0),('35346c4f-78a4-4e4a-a8dc-f8fb4a8e5afc','ba4f28e9830fe892a8641a7be92c744836c43de0ce17ab56c49daae8253bed81','2026-05-16 18:47:30.627','20260516_add_group_structure','',NULL,'2026-05-16 18:47:30.627',0),('407d886a-34a6-4099-9b1d-6f59a1daf9a4','3c8a245c4492a5153d4a5c4c5769a333748fb6b0bf4728422c0132a9cc89ced0','2026-05-16 09:44:54.712','20260516094412_community_voting','',NULL,'2026-05-16 09:44:54.712',0),('40d4c667-e7d6-4286-ab87-9c82171fb52c','c2fcddb67300c1ce70f29b4ecf72aebe5295d5cac3c50e293fc1909255bd154e','2026-05-14 05:17:06.890','20260514011500_add_agent_profile','',NULL,'2026-05-14 05:17:06.890',0),('4d9d5024-eeb8-475f-adbb-4af0d3a16420','d91681b54b5c9272154d68236fbc5ad2de81db0f94b2c95f7cd4405efb0eca94','2026-05-16 16:24:59.437','20260516000000_group_tool_recommender','',NULL,'2026-05-16 16:24:59.437',0),('54bd7d8e-07d2-4968-8b35-f4a56fd5ad14','fec71bf94921ed5603d83bbc64045472f48c23ab782321318a1b783954c9973d','2026-05-14 12:19:01.121','20260514080000_add_dispute_voting','',NULL,'2026-05-14 12:19:01.121',0),('59addee8-6661-4439-9b23-41d1cae1a6d1','8aeec5099f590dbe581208748103b38ff920e658038999dec05baf058c98cbae',NULL,'20260327130514_add_branch_need_vote','A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260327130514_add_branch_need_vote\n\nDatabase error code: 1050\n\nDatabase error:\nTable \'User\' already exists\n\nPlease check the query number 1 from the migration file.\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name=\"20260327130514_add_branch_need_vote\"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name=\"20260327130514_add_branch_need_vote\"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:202',NULL,'2026-05-16 22:00:27.289',0),('71baf969-7d11-4f9a-ac4c-e167fbb4db4d','594cc2fbc76cfc448774736e9707bc0c5b1eedfdf34940e2efd902469167d529','2026-05-13 16:33:00.099','20260513130000_add_agent_role_and_timestamps','',NULL,'2026-05-13 16:33:00.099',0),('77b73238-c937-4c11-b31c-dd0c3844b66a','c1728cbc207d39d60ecc603039298db19129f846d187f11bb53f5ca229118b1c','2026-05-16 17:18:08.431','20260516_add_waitlist','',NULL,'2026-05-16 17:18:08.431',0),('79490b22-2bf6-4922-bce5-4fc5d39436d0','36923dabadaf47a9ac9286ad3a15de06ccc15b5920356482378841897ae1bed8','2026-05-16 21:35:21.588','20260516_add_todo_assignment','',NULL,'2026-05-16 21:35:21.588',0),('82450ed0-cab2-4d96-a946-713fa1b6ec3b','df22009cae56c41ec6cefa81d8b49849b11e9f3416204c7f096cfaddbea875a8','2026-05-16 17:17:45.102','20260516133000_add_tree_expense','',NULL,'2026-05-16 17:17:45.102',0),('8d43ff12-3cbd-4d0d-8959-852e058876e3','09dc3acdba1f4e79b3b2eb07763819e3af3a8ae6cb8b93922d6cbbcc269ff64b','2026-05-16 17:03:52.815','20260516130000_add_investment_matching','',NULL,'2026-05-16 17:03:52.815',0),('9a0e7965-e6cd-4438-8503-cfb9691afc35','ceaccc6ef2ba47f4273d674cd1a2ca843983a836457c96fa0535d1fa12a73fd5','2026-05-16 16:47:30.583','20260516124559_add_structure_models','',NULL,'2026-05-16 16:47:30.583',0),('b5b21df7-495c-4201-a5a8-bf4786f06207','d60cd673512d7e7f850cbf1fac8f39dbc957f8e73c75990813f4cfcef96d4d8b','2026-05-16 16:31:27.129','20260516_add_group_role','',NULL,'2026-05-16 16:31:27.129',0),('cd4182d8-4fc3-11f1-9ad5-843a4b23a26c','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855','2026-05-14 14:36:20.000','20260514170000_add_tree_sandbox',NULL,NULL,'2026-05-14 14:36:20.000',1),('dad4a678-7d6b-4dfc-ac55-cc6bad239816','9f78679a775a37a2dc015e6d2ed3a84a7d6b498a9119f5674633f7c99cb74f27','2026-05-14 11:01:49.811','20260514063623_add_task_model','',NULL,'2026-05-14 11:01:49.811',0),('dbd2d100-2df8-47ad-a785-23e3cc9d531d','c4f37b3c333b64f98a12a38ca66438a6f99310332da1e3fc6b6c4aa9f1dd5892','2026-05-14 11:02:02.756','20260514070000_add_payment_status_to_tree_member','',NULL,'2026-05-14 11:02:02.756',0),('e8eb3d55-57d1-4545-8c7a-d5cf9ad734a3','b6ef927fae9ac6bff0a79d4b779023d9463ec8c63f47ddb0b47cde3106d679eb','2026-05-17 05:49:57.766','20260517010000_add_kanban_proposal_fields','',NULL,'2026-05-17 05:49:57.766',0),('eb5b209a-910b-472d-ad31-617601cbe5f5','40a0443b3628a2e9c0060fb2292687e1b059af0003f1ba32792b271640d4c105','2026-05-14 11:51:32.629','20260514070000_add_dispute_voting','',NULL,'2026-05-14 11:51:32.629',0),('ef081d28-48b5-4340-9164-857c41ac4e87','d874dd9a497aadaa629b71c9a06d8ded3357dbf128d442a0686bc451ff435804','2026-05-16 15:45:56.944','20260516113323_add_member_social_profile','',NULL,'2026-05-16 15:45:56.944',0),('f3feb7a8-b51a-4ad3-aceb-8a2796dc20d0','ab232109b046e64d1ecb32d235059ab2bccf805ef8f3bfcb90803e947b2328aa','2026-05-14 01:42:27.591','20260513220000_add_telegram_chat_id','',NULL,'2026-05-14 01:42:27.591',0),('f4230ed4-c093-4bf7-9f5d-0287dddba35c','3ca8574e366d00fcdc753845a75b96472451ea3eabb036e7cc72a4cadca53412','2026-05-16 20:58:58.627','20260516_add_todo','',NULL,'2026-05-16 20:58:58.627',0);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'trust_web'
--

--
-- Dumping routines for database 'trust_web'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-20 12:00:42
